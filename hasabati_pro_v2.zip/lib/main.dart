import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:share_plus/share_plus.dart';

import 'database.dart';
import 'models.dart';

const appBlue = Color(0xFF1565C0);
const appBlueDark = Color(0xFF0D47A1);
const appGold = Color(0xFFFFB300);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const HasabatiApp());
}

class HasabatiApp extends StatelessWidget {
  const HasabatiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'حساباتي',
      locale: const Locale('ar'),
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: appBlue),
        fontFamily: 'sans',
        scaffoldBackgroundColor: const Color(0xFFF5F7FB),
        appBarTheme: const AppBarTheme(
          backgroundColor: appBlue,
          foregroundColor: Colors.white,
          centerTitle: true,
          elevation: 0,
        ),
        cardTheme: const CardThemeData(
          elevation: 0,
          margin: EdgeInsets.symmetric(vertical: 6),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: Color(0xFFE3E8F0)),
          ),
        ),
      ),
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child ?? const SizedBox.shrink(),
      ),
      home: const HomePage(),
    );
  }
}

String money(double value) => NumberFormat('#,##0.##', 'en_US').format(value);
String nowText() => DateFormat('yyyy-MM-dd HH:mm').format(DateTime.now());

String currencyName(String code) {
  switch (code) {
    case 'SAR':
      return 'ريال سعودي';
    case 'USD':
      return 'دولار أمريكي';
    default:
      return 'ريال يمني';
  }
}

String currencySymbol(String code) {
  switch (code) {
    case 'SAR':
      return 'ر.س';
    case 'USD':
      return '\$';
    default:
      return 'ر.ي';
  }
}

Color currencyColor(String code) {
  switch (code) {
    case 'SAR':
      return const Color(0xFF16805B);
    case 'USD':
      return const Color(0xFF7B4BC4);
    default:
      return appBlue;
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;
  String search = '';

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardPage(onOpenCustomers: () => setState(() => index = 1)),
      CustomersPage(search: search),
      const ReportsPage(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Icon(Icons.account_balance_wallet_rounded),
            SizedBox(width: 8),
            Text('حساباتي', style: TextStyle(fontWeight: FontWeight.w800)),
          ],
        ),
        actions: [
          if (index == 1)
            IconButton(
              tooltip: 'بحث',
              onPressed: () async {
                final q = await showSearch<String?>(
                  context: context,
                  delegate: CustomerSearchDelegate(),
                );
                if (q != null) setState(() => search = q);
              },
              icon: const Icon(Icons.search_rounded),
            ),
        ],
      ),
      body: IndexedStack(index: index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'العملاء'),
          NavigationDestination(icon: Icon(Icons.analytics_outlined), selectedIcon: Icon(Icons.analytics), label: 'التقارير'),
        ],
      ),
      floatingActionButton: index == 1
          ? FloatingActionButton.extended(
              onPressed: () async {
                final saved = await showDialog<bool>(context: context, builder: (_) => const CustomerDialog());
                if (saved == true) setState(() {});
              },
              icon: const Icon(Icons.person_add_alt_1_rounded),
              label: const Text('عميل جديد'),
            )
          : null,
    );
  }
}

class DashboardPage extends StatefulWidget {
  final VoidCallback onOpenCustomers;
  const DashboardPage({super.key, required this.onOpenCustomers});
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  Future<void> refresh() async => setState(() {});

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: refresh,
      child: FutureBuilder<Map<String, double>>(
        future: AppDatabase.instance.currencyTotals(),
        builder: (context, totalsSnap) {
          final totals = totalsSnap.data ?? {};
          return FutureBuilder<List<Customer>>(
            future: AppDatabase.instance.customers(),
            builder: (context, customersSnap) {
              final customers = customersSnap.data ?? [];
              return ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
                children: [
                  _WelcomeCard(customersCount: customers.length),
                  const SizedBox(height: 12),
                  const _SectionTitle(title: 'الأرصدة حسب العملة', icon: Icons.account_balance_wallet_outlined),
                  if (totals.isEmpty)
                    const _EmptyCard(text: 'لا توجد عمليات مالية حتى الآن')
                  else
                    ...totals.entries.map((e) => _CurrencyBalanceCard(currency: e.key, balance: e.value)),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(child: _QuickButton(icon: Icons.person_add_alt_1_rounded, text: 'إضافة عميل', onTap: widget.onOpenCustomers)),
                      const SizedBox(width: 10),
                      Expanded(child: _QuickButton(icon: Icons.assessment_outlined, text: 'التقارير', onTap: () {})),
                    ],
                  ),
                  const SizedBox(height: 18),
                  const _SectionTitle(title: 'آخر العملاء', icon: Icons.people_alt_outlined),
                  if (customers.isEmpty)
                    const _EmptyCard(text: 'أضف أول عميل من زر «عميل جديد»')
                  else
                    ...customers.take(6).map((c) => _CustomerTile(customer: c)),
                ],
              );
            },
          );
        },
      ),
    );
  }
}

class _WelcomeCard extends StatelessWidget {
  final int customersCount;
  const _WelcomeCard({required this.customersCount});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [appBlue, appBlueDark]),
      ),
      padding: const EdgeInsets.all(20),
      child: Row(
        children: [
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: .15), borderRadius: BorderRadius.circular(18)),
            child: const Icon(Icons.menu_book_rounded, color: Colors.white, size: 32),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('دفتر حساباتك', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w800)),
              const SizedBox(height: 5),
              Text('$customersCount عميل مسجل', style: TextStyle(color: Colors.white.withValues(alpha: .85))),
            ]),
          ),
          const Icon(Icons.auto_graph_rounded, color: appGold, size: 36),
        ],
      ),
    );
  }
}

class _CurrencyBalanceCard extends StatelessWidget {
  final String currency;
  final double balance;
  const _CurrencyBalanceCard({required this.currency, required this.balance});

  @override
  Widget build(BuildContext context) {
    final color = currencyColor(currency);
    return Card(
      color: Colors.white,
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
        leading: CircleAvatar(backgroundColor: color.withValues(alpha: .12), foregroundColor: color, child: Text(currencySymbol(currency), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12))),
        title: Text(currencyName(currency), style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(currency),
        trailing: Text(money(balance), style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: balance >= 0 ? Colors.green.shade700 : Colors.red.shade700)),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final IconData icon;
  const _SectionTitle({required this.title, required this.icon});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(children: [Icon(icon, size: 21, color: appBlue), const SizedBox(width: 8), Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))]),
      );
}

class _EmptyCard extends StatelessWidget {
  final String text;
  const _EmptyCard({required this.text});
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(24), child: Center(child: Text(text, textAlign: TextAlign.center))));
}

class _QuickButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;
  const _QuickButton({required this.icon, required this.text, required this.onTap});
  @override
  Widget build(BuildContext context) => FilledButton.tonalIcon(onPressed: onTap, icon: Icon(icon), label: Text(text), style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 17), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))));
}

class _CustomerTile extends StatelessWidget {
  final Customer customer;
  const _CustomerTile({required this.customer});
  @override
  Widget build(BuildContext context) => Card(child: ListTile(leading: CircleAvatar(backgroundColor: appBlue.withValues(alpha: .1), foregroundColor: appBlue, child: Text(customer.name.isEmpty ? '?' : customer.name.characters.first)), title: Text(customer.name, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text(customer.phone.isEmpty ? 'بدون رقم هاتف' : customer.phone), trailing: const Icon(Icons.chevron_left_rounded)));
}

class CustomersPage extends StatefulWidget {
  final String search;
  const CustomersPage({super.key, this.search = ''});
  @override
  State<CustomersPage> createState() => _CustomersPageState();
}

class _CustomersPageState extends State<CustomersPage> {
  late String search;
  @override
  void initState() { super.initState(); search = widget.search; }
  @override
  void didUpdateWidget(covariant CustomersPage oldWidget) { super.didUpdateWidget(oldWidget); search = widget.search; }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Customer>>(
      future: AppDatabase.instance.customers(query: search),
      builder: (context, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final customers = snap.data!;
        if (customers.isEmpty) return const Center(child: Text('لا يوجد عملاء. أضف أول عميل من زر «عميل جديد»'));
        return ListView.builder(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 100),
          itemCount: customers.length,
          itemBuilder: (_, i) {
            final c = customers[i];
            return Card(
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                leading: CircleAvatar(backgroundColor: appBlue.withValues(alpha: .1), foregroundColor: appBlue, child: Text(c.name.isEmpty ? '?' : c.name.characters.first)),
                title: Text(c.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text([c.phone, c.address].where((x) => x.isNotEmpty).join(' • ')),
                trailing: const Icon(Icons.chevron_left_rounded),
                onTap: () async { await Navigator.push(context, MaterialPageRoute(builder: (_) => CustomerPage(customer: c))); if (mounted) setState(() {}); },
                onLongPress: () => _edit(c),
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _edit(Customer c) async {
    final saved = await showDialog<bool>(context: context, builder: (_) => CustomerDialog(customer: c));
    if (saved == true) setState(() {});
  }
}

class CustomerSearchDelegate extends SearchDelegate<String?> {
  CustomerSearchDelegate() : super(searchFieldLabel: 'ابحث باسم العميل أو الهاتف');
  @override List<Widget>? buildActions(BuildContext context) => [if (query.isNotEmpty) IconButton(onPressed: () => query = '', icon: const Icon(Icons.clear))];
  @override Widget? buildLeading(BuildContext context) => IconButton(onPressed: () => close(context, null), icon: const Icon(Icons.arrow_back));
  @override Widget buildResults(BuildContext context) => _result();
  @override Widget buildSuggestions(BuildContext context) => _result();
  Widget _result() => FutureBuilder<List<Customer>>(future: AppDatabase.instance.customers(query: query), builder: (context, snap) { final data = snap.data ?? []; return ListView(children: data.map((c) => ListTile(title: Text(c.name), subtitle: Text(c.phone), onTap: () => close(context, query))).toList()); });
}

class CustomerDialog extends StatefulWidget {
  final Customer? customer;
  const CustomerDialog({super.key, this.customer});
  @override State<CustomerDialog> createState() => _CustomerDialogState();
}

class _CustomerDialogState extends State<CustomerDialog> {
  final form = GlobalKey<FormState>();
  late final TextEditingController name, phone, address, note;
  @override void initState() { super.initState(); final c = widget.customer; name = TextEditingController(text: c?.name ?? ''); phone = TextEditingController(text: c?.phone ?? ''); address = TextEditingController(text: c?.address ?? ''); note = TextEditingController(text: c?.note ?? ''); }
  @override void dispose() { name.dispose(); phone.dispose(); address.dispose(); note.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => AlertDialog(
        title: Text(widget.customer == null ? 'إضافة عميل' : 'تعديل العميل'),
        content: Form(key: form, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextFormField(controller: name, decoration: const InputDecoration(labelText: 'اسم العميل'), validator: (v) => v!.trim().isEmpty ? 'أدخل اسم العميل' : null),
          const SizedBox(height: 10), TextFormField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'رقم الهاتف')),
          const SizedBox(height: 10), TextFormField(controller: address, decoration: const InputDecoration(labelText: 'العنوان')),
          const SizedBox(height: 10), TextFormField(controller: note, maxLines: 2, decoration: const InputDecoration(labelText: 'ملاحظة')),
        ]))),
        actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')), FilledButton(onPressed: _save, child: const Text('حفظ'))],
      );
  Future<void> _save() async { if (!form.currentState!.validate()) return; final old = widget.customer; final c = Customer(id: old?.id, name: name.text.trim(), phone: phone.text.trim(), address: address.text.trim(), note: note.text.trim(), createdAt: old?.createdAt ?? nowText()); if (old == null) { await AppDatabase.instance.insertCustomer(c); } else { await AppDatabase.instance.updateCustomer(c); } if (mounted) Navigator.pop(context, true); }
}

class CustomerPage extends StatefulWidget {
  final Customer customer;
  const CustomerPage({super.key, required this.customer});
  @override State<CustomerPage> createState() => _CustomerPageState();
}

class _CustomerPageState extends State<CustomerPage> {
  String? currencyFilter;
  Future<List<Entry>> _entries() => AppDatabase.instance.entriesForCustomer(widget.customer.id!, currency: currencyFilter);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.customer.name), actions: [IconButton(icon: const Icon(Icons.edit), onPressed: _edit), IconButton(icon: const Icon(Icons.delete_outline), onPressed: _delete)]),
      floatingActionButton: FloatingActionButton.extended(onPressed: _addEntry, icon: const Icon(Icons.add_rounded), label: const Text('إضافة عملية')),
      body: FutureBuilder<Map<String, double>>(
        future: AppDatabase.instance.balanceByCurrency(widget.customer.id!),
        builder: (context, balanceSnap) {
          final balances = balanceSnap.data ?? {};
          return ListView(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 100),
            children: [
              Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(widget.customer.name, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                if (widget.customer.phone.isNotEmpty) Text('الهاتف: ${widget.customer.phone}'),
                if (widget.customer.address.isNotEmpty) Text('العنوان: ${widget.customer.address}'),
                if (widget.customer.note.isNotEmpty) Text('ملاحظة: ${widget.customer.note}'),
              ]))),
              const SizedBox(height: 8),
              const _SectionTitle(title: 'الرصيد حسب العملة', icon: Icons.account_balance_wallet_outlined),
              if (balances.isEmpty) const _EmptyCard(text: 'لا توجد أرصدة لهذا العميل') else ...balances.entries.map((e) => _CurrencyBalanceCard(currency: e.key, balance: e.value)),
              const SizedBox(height: 8),
              _CurrencyFilter(selected: currencyFilter, currencies: balances.keys.toList(), onChanged: (v) => setState(() => currencyFilter = v)),
              const SizedBox(height: 8),
              FutureBuilder<List<Entry>>(future: _entries(), builder: (context, snap) {
                final entries = snap.data ?? [];
                if (entries.isEmpty) return const _EmptyCard(text: 'لا توجد عمليات لهذه العملة');
                return Column(children: entries.map(_entryCard).toList());
              }),
            ],
          );
        },
      ),
    );
  }

  Widget _entryCard(Entry e) {
    final positive = e.type == EntryType.credit;
    return Card(child: ListTile(
      leading: CircleAvatar(backgroundColor: (positive ? Colors.green : Colors.red).withValues(alpha: .1), foregroundColor: positive ? Colors.green : Colors.red, child: Icon(positive ? Icons.arrow_downward_rounded : Icons.arrow_upward_rounded)),
      title: Text('${e.type.label} • ${money(e.amount)} ${e.currency}', style: const TextStyle(fontWeight: FontWeight.w800)),
      subtitle: Text('${e.description.isEmpty ? 'بدون بيان' : e.description}\n${e.date}'), isThreeLine: true,
      trailing: PopupMenuButton<String>(onSelected: (v) async { if (v == 'share') await Share.share(_shareText(e)); if (v == 'delete') { await AppDatabase.instance.deleteEntry(e.id!); setState(() {}); } }, itemBuilder: (_) => const [PopupMenuItem(value: 'share', child: Text('مشاركة')), PopupMenuItem(value: 'delete', child: Text('حذف'))]),
    ));
  }

  String _shareText(Entry e) => 'حساباتي\nالعميل: ${widget.customer.name}\nالعملة: ${currencyName(e.currency)} (${e.currency})\nالعملية: ${e.type.label}\nالمبلغ: ${money(e.amount)} ${e.currency}\nالبيان: ${e.description.isEmpty ? 'بدون بيان' : e.description}\nالتاريخ: ${e.date}';
  Future<void> _addEntry() async { final saved = await showDialog<bool>(context: context, builder: (_) => EntryDialog(customerId: widget.customer.id!)); if (saved == true) setState(() {}); }
  Future<void> _edit() async { final saved = await showDialog<bool>(context: context, builder: (_) => CustomerDialog(customer: widget.customer)); if (saved == true && mounted) setState(() {}); }
  Future<void> _delete() async { final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: const Text('حذف العميل'), content: const Text('سيتم حذف العميل وجميع عملياته. هل تريد المتابعة؟'), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف'))])); if (ok == true) { await AppDatabase.instance.deleteCustomer(widget.customer.id!); if (mounted) Navigator.pop(context); } }
}

class _CurrencyFilter extends StatelessWidget {
  final String? selected;
  final List<String> currencies;
  final ValueChanged<String?> onChanged;
  const _CurrencyFilter({required this.selected, required this.currencies, required this.onChanged});
  @override
  Widget build(BuildContext context) {
    final options = ['ALL', ...currencies];
    return Card(child: Padding(padding: const EdgeInsets.all(8), child: Wrap(spacing: 8, runSpacing: 8, children: options.map((code) => ChoiceChip(label: Text(code == 'ALL' ? 'كل العملات' : '${currencyName(code)}  $code'), selected: code == 'ALL' ? selected == null : selected == code, onSelected: (_) => onChanged(code == 'ALL' ? null : code))).toList())));
  }
}

class EntryDialog extends StatefulWidget {
  final int customerId;
  const EntryDialog({super.key, required this.customerId});
  @override State<EntryDialog> createState() => _EntryDialogState();
}

class _EntryDialogState extends State<EntryDialog> {
  final form = GlobalKey<FormState>();
  final amount = TextEditingController();
  final description = TextEditingController();
  EntryType type = EntryType.credit;
  String currency = 'YER';
  @override void dispose() { amount.dispose(); description.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => AlertDialog(
        title: const Text('إضافة عملية'),
        content: Form(key: form, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          SegmentedButton<EntryType>(segments: const [ButtonSegment(value: EntryType.credit, label: Text('له'), icon: Icon(Icons.arrow_downward)), ButtonSegment(value: EntryType.debit, label: Text('عليه'), icon: Icon(Icons.arrow_upward))], selected: {type}, onSelectionChanged: (v) => setState(() => type = v.first)),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(initialValue: currency, decoration: const InputDecoration(labelText: 'العملة'), items: const [DropdownMenuItem(value: 'YER', child: Text('ريال يمني YER')), DropdownMenuItem(value: 'SAR', child: Text('ريال سعودي SAR')), DropdownMenuItem(value: 'USD', child: Text('دولار أمريكي USD'))], onChanged: (v) { if (v != null) setState(() => currency = v); }),
          const SizedBox(height: 10),
          TextFormField(controller: amount, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'المبلغ'), validator: (v) { final n = double.tryParse(v!.trim()); return n == null || n <= 0 ? 'أدخل مبلغاً صحيحاً' : null; }),
          const SizedBox(height: 10), TextFormField(controller: description, maxLines: 2, decoration: const InputDecoration(labelText: 'البيان / الملاحظة')),
        ]))),
        actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')), FilledButton(onPressed: _save, child: const Text('حفظ'))],
      );
  Future<void> _save() async { if (!form.currentState!.validate()) return; await AppDatabase.instance.insertEntry(Entry(customerId: widget.customerId, type: type, amount: double.parse(amount.text.trim()), currency: currency, description: description.text.trim(), date: nowText())); if (mounted) Navigator.pop(context, true); }
}

class ReportsPage extends StatefulWidget {
  const ReportsPage({super.key});
  @override State<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends State<ReportsPage> {
  String? currency;
  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Map<String, double>>(
      future: AppDatabase.instance.currencyTotals(),
      builder: (context, totalsSnap) {
        final totals = totalsSnap.data ?? {};
        final currencies = totals.keys.toList();
        final selected = currency != null && currencies.contains(currency) ? currency : null;
        return RefreshIndicator(
          onRefresh: () async => setState(() {}),
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(12, 16, 12, 100),
            children: [
              const Text('التقارير المالية', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              const Text('كل عملة لها رصيد وسجل مستقل عن العملات الأخرى.'),
              const SizedBox(height: 14),
              _ReportCurrencyTabs(currencies: currencies, selected: selected, onChanged: (v) => setState(() => currency = v)),
              const SizedBox(height: 12),
              if (currencies.isEmpty) const _EmptyCard(text: 'لا توجد بيانات مالية بعد') else ...currencies.where((c) => selected == null || c == selected).map((c) => _CurrencyReportCard(currency: c, balance: totals[c] ?? 0)),
              const SizedBox(height: 8),
              const _SectionTitle(title: 'أرصدة العملاء', icon: Icons.groups_outlined),
              FutureBuilder<List<Map<String, dynamic>>>(
                future: AppDatabase.instance.customerBalances(),
                builder: (context, snap) {
                  final rows = snap.data ?? [];
                  final filtered = rows.where((r) => selected == null || r['currency'] == selected).toList();
                  if (filtered.isEmpty) return const _EmptyCard(text: 'لا توجد أرصدة لهذه العملة');
                  return Column(children: filtered.map((r) => Card(child: ListTile(leading: CircleAvatar(backgroundColor: currencyColor(r['currency'] as String).withValues(alpha: .1), foregroundColor: currencyColor(r['currency'] as String), child: Text(currencySymbol(r['currency'] as String), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800))), title: Text(r['name'] as String, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text('${currencyName(r['currency'] as String)} • ${r['entry_count']} عملية'), trailing: Text(money((r['balance'] as num).toDouble()), style: TextStyle(fontWeight: FontWeight.w900, color: (r['balance'] as num).toDouble() >= 0 ? Colors.green.shade700 : Colors.red.shade700)))).toList());
                },
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ReportCurrencyTabs extends StatelessWidget {
  final List<String> currencies;
  final String? selected;
  final ValueChanged<String?> onChanged;
  const _ReportCurrencyTabs({required this.currencies, required this.selected, required this.onChanged});
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(8), child: Wrap(spacing: 8, runSpacing: 8, children: [ChoiceChip(label: const Text('كل العملات'), selected: selected == null, onSelected: (_) => onChanged(null)), ...currencies.map((c) => ChoiceChip(label: Text('${currencyName(c)}  $c'), selected: selected == c, onSelected: (_) => onChanged(c)))])));
}

class _CurrencyReportCard extends StatelessWidget {
  final String currency;
  final double balance;
  const _CurrencyReportCard({required this.currency, required this.balance});
  @override
  Widget build(BuildContext context) {
    final color = currencyColor(currency);
    return Card(child: Padding(padding: const EdgeInsets.all(18), child: Row(children: [CircleAvatar(radius: 27, backgroundColor: color.withValues(alpha: .12), foregroundColor: color, child: Text(currencySymbol(currency), style: const TextStyle(fontWeight: FontWeight.w900))), const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(currencyName(currency), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)), Text(currency)])), Text(money(balance), style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: balance >= 0 ? Colors.green.shade700 : Colors.red.shade700))])));
  }
}
