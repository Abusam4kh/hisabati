import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import 'models.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();

  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final dir = await getDatabasesPath();
    final path = p.join(dir, 'hasabati.db');
    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE customers(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT NOT NULL DEFAULT '',
            address TEXT NOT NULL DEFAULT '',
            note TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE entries(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER NOT NULL,
            type TEXT NOT NULL,
            amount REAL NOT NULL,
            currency TEXT NOT NULL DEFAULT 'YER',
            description TEXT NOT NULL DEFAULT '',
            date TEXT NOT NULL,
            FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE CASCADE
          )
        ''');
        await db.execute('CREATE INDEX idx_entries_customer ON entries(customer_id)');
        await db.execute('CREATE INDEX idx_entries_currency ON entries(currency)');
      },
    );
    return _db!;
  }

  Future<List<Customer>> customers({String query = ''}) async {
    final db = await database;
    final q = query.trim();
    final rows = await db.query(
      'customers',
      where: q.isEmpty ? null : 'name LIKE ? OR phone LIKE ?',
      whereArgs: q.isEmpty ? null : ['%$q%', '%$q%'],
      orderBy: 'id DESC',
    );
    return rows.map(Customer.fromMap).toList();
  }

  Future<int> insertCustomer(Customer customer) async {
    final db = await database;
    return db.insert('customers', customer.toMap());
  }

  Future<int> updateCustomer(Customer customer) async {
    final db = await database;
    return db.update(
      'customers',
      customer.toMap(),
      where: 'id = ?',
      whereArgs: [customer.id],
    );
  }

  Future<int> deleteCustomer(int id) async {
    final db = await database;
    await db.delete('entries', where: 'customer_id = ?', whereArgs: [id]);
    return db.delete('customers', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Entry>> entriesForCustomer(int customerId, {String? currency}) async {
    final db = await database;
    final hasCurrency = currency != null && currency.isNotEmpty;
    final rows = await db.query(
      'entries',
      where: hasCurrency ? 'customer_id = ? AND currency = ?' : 'customer_id = ?',
      whereArgs: hasCurrency ? [customerId, currency] : [customerId],
      orderBy: 'date DESC, id DESC',
    );
    return rows.map(Entry.fromMap).toList();
  }

  Future<int> insertEntry(Entry entry) async {
    final db = await database;
    return db.insert('entries', entry.toMap());
  }

  Future<int> deleteEntry(int id) async {
    final db = await database;
    return db.delete('entries', where: 'id = ?', whereArgs: [id]);
  }

  Future<Map<String, double>> balanceByCurrency(int customerId) async {
    final rows = await entriesForCustomer(customerId);
    return _balances(rows);
  }

  Map<String, double> _balances(List<Entry> rows) {
    final result = <String, double>{};
    for (final e in rows) {
      final sign = e.type == EntryType.credit ? 1 : -1;
      result[e.currency] = (result[e.currency] ?? 0) + sign * e.amount;
    }
    return result;
  }

  /// Returns one row per customer + currency. No currency is ever combined.
  Future<List<Map<String, dynamic>>> customerBalances() async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT c.id, c.name, c.phone, e.currency,
        SUM(CASE WHEN e.type='credit' THEN e.amount ELSE -e.amount END) AS balance,
        COUNT(e.id) AS entry_count
      FROM customers c
      INNER JOIN entries e ON e.customer_id = c.id
      GROUP BY c.id, e.currency
      ORDER BY c.name COLLATE NOCASE, e.currency
    ''');
    return rows;
  }

  Future<Map<String, double>> currencyTotals() async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT currency,
        COALESCE(SUM(CASE WHEN type='credit' THEN amount ELSE -amount END), 0) AS balance
      FROM entries
      GROUP BY currency
      ORDER BY currency
    ''');
    return {
      for (final row in rows)
        (row['currency'] ?? 'YER') as String: (row['balance'] as num).toDouble(),
    };
  }

  Future<Map<String, int>> currencyEntryCounts() async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT currency, COUNT(*) AS count
      FROM entries
      GROUP BY currency
      ORDER BY currency
    ''');
    return {
      for (final row in rows)
        (row['currency'] ?? 'YER') as String: (row['count'] as num).toInt(),
    };
  }

  Future<List<Entry>> allEntries({String? currency}) async {
    final db = await database;
    final hasCurrency = currency != null && currency.isNotEmpty;
    final rows = await db.query(
      'entries',
      where: hasCurrency ? 'currency = ?' : null,
      whereArgs: hasCurrency ? [currency] : null,
      orderBy: 'date DESC, id DESC',
    );
    return rows.map(Entry.fromMap).toList();
  }
}
