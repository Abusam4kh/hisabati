import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import 'models.dart';

class AppDatabase {
  AppDatabase._();

  static final AppDatabase instance = AppDatabase._();

  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final dir = await getDatabasesPath();
    final path = p.join(dir, 'hasabati.db');

    _db = await openDatabase(
      path,
      version: 2,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (db, version) async {
        await _createTables(db);
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await db.execute(
            'CREATE INDEX IF NOT EXISTS idx_entries_customer_currency '
            'ON entries(customer_id, currency)',
          );
          await db.execute(
            'CREATE INDEX IF NOT EXISTS idx_entries_date ON entries(date)',
          );
        }
      },
    );
    return _db!;
  }

  Future<void> _createTables(Database db) async {
    await db.execute('''
      CREATE TABLE customers(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT NOT NULL DEFAULT '',
        address TEXT NOT NULL DEFAULT '',
        note TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE entries(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        type TEXT NOT NULL,
        amount REAL NOT NULL,
        currency TEXT NOT NULL DEFAULT 'YER',
        description TEXT NOT NULL DEFAULT '',
        date TEXT NOT NULL,
        FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE CASCADE
      )
    ''');

    await db.execute(
      'CREATE INDEX idx_entries_customer_currency '
      'ON entries(customer_id, currency)',
    );
    await db.execute('CREATE INDEX idx_entries_date ON entries(date)');
  }

  Future<List<Customer>> customers({String query = ''}) async {
    final db = await database;
    final q = query.trim();
    final rows = await db.query(
      'customers',
      where: q.isEmpty ? null : 'name LIKE ? OR phone LIKE ?',
      whereArgs: q.isEmpty ? null : ['%$q%', '%$q%'],
      orderBy: 'id DESC',
    );
    return rows.map(Customer.fromMap).toList();
  }

  Future<int> insertCustomer(Customer customer) async {
    final db = await database;
    return db.insert('customers', customer.toMap());
  }

  Future<int> updateCustomer(Customer customer) async {
    final db = await database;
    return db.update(
      'customers',
      customer.toMap(),
      where: 'id = ?',
      whereArgs: [customer.id],
    );
  }

  Future<int> deleteCustomer(int id) async {
    final db = await database;
    return db.delete('customers', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Entry>> entriesForCustomer(
    int customerId, {
    String? currency,
  }) async {
    final db = await database;
    final hasCurrency = currency != null && currency.isNotEmpty;
    final rows = await db.query(
      'entries',
      where: hasCurrency
          ? 'customer_id = ? AND currency = ?'
          : 'customer_id = ?',
      whereArgs: hasCurrency ? [customerId, currency] : [customerId],
      orderBy: 'date DESC, id DESC',
    );
    return rows.map(Entry.fromMap).toList();
  }

  Future<int> insertEntry(Entry entry) async {
    final db = await database;
    return db.insert('entries', entry.toMap());
  }

  Future<int> deleteEntry(int id) async {
    final db = await database;
    return db.delete('entries', where: 'id = ?', whereArgs: [id]);
  }

  /// Returns balances for a single customer grouped by currency.
  /// No conversion and no cross-currency addition is performed.
  Future<List<CustomerCurrencyBalance>> customerCurrencyBalances(
    int customerId,
  ) async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT
        currency,
        SUM(CASE WHEN type = 'credit' THEN amount ELSE -amount END) AS balance,
        COUNT(*) AS transactions
      FROM entries
      WHERE customer_id = ?
      GROUP BY currency
      ORDER BY currency
    ''', [customerId]);

    return rows
        .map(
          (r) => CustomerCurrencyBalance(
            currency: (r['currency'] ?? 'YER') as String,
            balance: (r['balance'] as num?)?.toDouble() ?? 0,
            transactions: (r['transactions'] as num?)?.toInt() ?? 0,
          ),
        )
        .toList();
  }

  /// Returns global totals grouped by currency.
  /// This deliberately never sums YER + SAR + USD together.
  Future<List<CurrencyTotal>> currencyTotals() async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT
        currency,
        SUM(CASE WHEN type = 'credit' THEN amount ELSE -amount END) AS balance,
        COUNT(*) AS transactions,
        COUNT(DISTINCT customer_id) AS customers
      FROM entries
      GROUP BY currency
      ORDER BY currency
    ''');

    return rows
        .map(
          (r) => CurrencyTotal(
            currency: (r['currency'] ?? 'YER') as String,
            balance: (r['balance'] as num?)?.toDouble() ?? 0,
            transactions: (r['transactions'] as num?)?.toInt() ?? 0,
            customers: (r['customers'] as num?)?.toInt() ?? 0,
          ),
        )
        .toList();
  }

  /// Per-customer report for exactly one currency.
  Future<List<CustomerCurrencyReportRow>> customerCurrencyReport({
    required String currency,
  }) async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT
        c.id AS customer_id,
        c.name AS customer_name,
        c.phone AS phone,
        e.currency AS currency,
        SUM(CASE WHEN e.type = 'credit' THEN e.amount ELSE -e.amount END) AS balance,
        COUNT(e.id) AS transactions
      FROM customers c
      INNER JOIN entries e ON e.customer_id = c.id
      WHERE e.currency = ?
      GROUP BY c.id, e.currency
      ORDER BY c.name COLLATE NOCASE
    ''', [currency]);

    return rows
        .map(
          (r) => CustomerCurrencyReportRow(
            customerId: (r['customer_id'] as num).toInt(),
            customerName: (r['customer_name'] ?? '') as String,
            phone: (r['phone'] ?? '') as String,
            currency: (r['currency'] ?? currency) as String,
            balance: (r['balance'] as num?)?.toDouble() ?? 0,
            transactions: (r['transactions'] as num?)?.toInt() ?? 0,
          ),
        )
        .toList();
  }

  /// All transactions, always retaining their original currency.
  Future<List<EntryWithCustomer>> allEntriesWithCustomers({
    String? currency,
    String? type,
    String query = '',
    int? limit,
  }) async {
    final db = await database;
    final conditions = <String>[];
    final args = <Object?>[];

    if (currency != null && currency.isNotEmpty) {
      conditions.add('e.currency = ?');
      args.add(currency);
    }
    if (type != null && type.isNotEmpty) {
      conditions.add('e.type = ?');
      args.add(type);
    }

    final q = query.trim();
    if (q.isNotEmpty) {
      conditions.add(
        '(c.name LIKE ? OR c.phone LIKE ? OR e.description LIKE ?)',
      );
      args.add('%$q%');
      args.add('%$q%');
      args.add('%$q%');
    }

    final where = conditions.isEmpty ? '' : 'WHERE ${conditions.join(' AND ')}';
    final limitSql = limit == null ? '' : 'LIMIT $limit';

    final rows = await db.rawQuery('''
      SELECT
        e.id,
        e.customer_id,
        e.type,
        e.amount,
        e.currency,
        e.description,
        e.date,
        c.name AS customer_name
      FROM entries e
      INNER JOIN customers c ON c.id = e.customer_id
      $where
      ORDER BY e.date DESC, e.id DESC
      $limitSql
    ''', args);

    return rows.map(EntryWithCustomer.fromMap).toList();
  }

  Future<List<Entry>> allEntries() async {
    final db = await database;
    final rows = await db.query(
      'entries',
      orderBy: 'date DESC, id DESC',
    );
    return rows.map(Entry.fromMap).toList();
  }
}
