import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import 'models.dart';

class AppDatabase {
  AppDatabase._();

  static final AppDatabase instance = AppDatabase._();

  Database? _db;

  Future<String> databasePath() async {
    final dir = await getDatabasesPath();
    return p.join(dir, 'hasabati.db');
  }

  Future<void> close() async {
    final db = _db;
    _db = null;
    if (db != null && db.isOpen) {
      await db.close();
    }
  }

  Future<String> createBackup(String destinationPath) async {
    final db = await database;
    try {
      await db.rawQuery('PRAGMA wal_checkpoint(FULL)');
    } catch (_) {}
    await close();
    final source = File(await databasePath());
    await source.copy(destinationPath);
    return destinationPath;
  }

  Future<void> restoreBackup(String sourcePath) async {
    final source = File(sourcePath);
    if (!await source.exists()) {
      throw Exception('ملف النسخة الاحتياطية غير موجود');
    }
    await close();
    final target = File(await databasePath());
    await source.copy(target.path);
    await database;
  }

  Future<Database> get database async {
    if (_db != null) return _db!;
    final dir = await getDatabasesPath();
    final path = p.join(dir, 'hasabati.db');

    _db = await openDatabase(
      path,
      version: 5,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (db, version) async {
        await _createTables(db);
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await db.execute(
            'CREATE INDEX IF NOT EXISTS idx_entries_customer_currency '
            'ON entries(customer_id, currency)',
          );
          await db.execute(
            'CREATE INDEX IF NOT EXISTS idx_entries_date ON entries(date)',
          );
        }
        if (oldVersion < 3) {
          await _createInvoiceTables(db);
        }
        if (oldVersion < 4) {
          // Payment mode for invoices: cash or credit (آجل).
          await db.execute(
            "ALTER TABLE invoices ADD COLUMN payment_type TEXT NOT NULL DEFAULT 'cash'",
          );
        }
      },
    );
    return _db!;
  }

  Future<void> _createTables(Database db) async {
    await db.execute('''
      CREATE TABLE customers(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT NOT NULL DEFAULT '',
        address TEXT NOT NULL DEFAULT '',
        note TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE entries(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        type TEXT NOT NULL,
        amount REAL NOT NULL,
        currency TEXT NOT NULL DEFAULT 'YER',
        description TEXT NOT NULL DEFAULT '',
        date TEXT NOT NULL,
        FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE CASCADE
      )
    ''');

    await db.execute(
      'CREATE INDEX idx_entries_customer_currency '
      'ON entries(customer_id, currency)',
    );
    await db.execute('CREATE INDEX idx_entries_date ON entries(date)');
    await _createInvoiceTables(db);
  }

  Future<void> _createInvoiceTables(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS invoices(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_number TEXT NOT NULL UNIQUE,
        customer_id INTEGER NOT NULL,
        currency TEXT NOT NULL DEFAULT 'YER',
        total REAL NOT NULL,
        note TEXT NOT NULL DEFAULT '',
        date TEXT NOT NULL,
        payment_type TEXT NOT NULL DEFAULT 'cash',
        FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE CASCADE
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS invoice_items(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        quantity REAL NOT NULL DEFAULT 1,
        price REAL NOT NULL,
        total REAL NOT NULL,
        FOREIGN KEY(invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
      )
    ''');
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_invoices_customer_currency '
      'ON invoices(customer_id, currency)',
    );
    await db.execute(
      'CREATE INDEX IF NOT EXISTS idx_invoice_items_invoice '
      'ON invoice_items(invoice_id)',
    );
  }

  Future<List<Customer>> customers({String query = ''}) async {
    final db = await database;
    final q = query.trim();
    final rows = await db.query(
      'customers',
      where: q.isEmpty ? null : 'name LIKE ? OR phone LIKE ?',
      whereArgs: q.isEmpty ? null : ['%$q%', '%$q%'],
      orderBy: 'id DESC',
    );
    return rows.map(Customer.fromMap).toList();
  }

  Future<int> insertCustomer(Customer customer) async {
    final db = await database;
    return db.insert('customers', customer.toMap());
  }

  Future<int> updateCustomer(Customer customer) async {
    final db = await database;
    return db.update(
      'customers',
      customer.toMap(),
      where: 'id = ?',
      whereArgs: [customer.id],
    );
  }

  Future<int> deleteCustomer(int id) async {
    final db = await database;
    return db.delete('customers', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Entry>> entriesForCustomer(
    int customerId, {
    String? currency,
  }) async {
    final db = await database;
    final hasCurrency = currency != null && currency.isNotEmpty;
    final rows = await db.query(
      'entries',
      where: hasCurrency
          ? 'customer_id = ? AND currency = ?'
          : 'customer_id = ?',
      whereArgs: hasCurrency ? [customerId, currency] : [customerId],
      orderBy: 'date DESC, id DESC',
    );
    return rows.map(Entry.fromMap).toList();
  }

  Future<int> insertEntry(Entry entry) async {
    final db = await database;
    return db.insert('entries', entry.toMap());
  }

  Future<int> deleteEntry(int id) async {
    final db = await database;
    return db.delete('entries', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> updateEntry(Entry entry) async {
    final db = await database;
    return db.update(
      'entries',
      entry.toMap()..remove('id'),
      where: 'id = ?',
      whereArgs: [entry.id],
    );
  }

  /// Returns balances for a single customer grouped by currency.
  /// No conversion and no cross-currency addition is performed.
  Future<List<CustomerCurrencyBalance>> customerCurrencyBalances(
    int customerId,
  ) async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT
        currency,
        SUM(CASE WHEN type = 'credit' THEN amount ELSE -amount END) AS balance,
        COUNT(*) AS transactions
      FROM entries
      WHERE customer_id = ?
      GROUP BY currency
      ORDER BY currency
    ''', [customerId]);

    return rows
        .map(
          (r) => CustomerCurrencyBalance(
            currency: (r['currency'] ?? 'YER') as String,
            balance: (r['balance'] as num?)?.toDouble() ?? 0,
            transactions: (r['transactions'] as num?)?.toInt() ?? 0,
          ),
        )
        .toList();
  }

  /// Returns global totals grouped by currency.
  /// This deliberately never sums YER + SAR + USD together.
  Future<List<CurrencyBalanceSplit>> currencyBalancesSplit() async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT currency,
        SUM(credit_amount) AS credit_amount,
        SUM(debit_amount) AS debit_amount
      FROM (
        SELECT currency,
          CASE WHEN type = 'credit' THEN amount ELSE 0 END AS credit_amount,
          CASE WHEN type = 'debit' THEN amount ELSE 0 END AS debit_amount
        FROM entries
        UNION ALL
        SELECT currency, total AS credit_amount, 0 AS debit_amount
        FROM invoices
        WHERE payment_type = 'cash'
      )
      GROUP BY currency
      ORDER BY currency
    ''');
    return rows.map((r) => CurrencyBalanceSplit(
      currency: (r['currency'] ?? 'YER') as String,
      credit: (r['credit_amount'] as num?)?.toDouble() ?? 0,
      debit: (r['debit_amount'] as num?)?.toDouble() ?? 0,
    )).toList();
  }

  Future<List<CurrencyTotal>> currencyTotals() async {
    final db = await database;
    // Customer entries affect the ledger balance. Cash invoices are real cash
    // sales, so they also increase the currency balance, but they never change
    // the named customer's debt balance.
    final rows = await db.rawQuery('''
      SELECT
        currency,
        SUM(amount_signed) AS balance,
        COUNT(*) AS transactions,
        COUNT(DISTINCT customer_id) AS customers
      FROM (
        SELECT
          currency,
          CASE WHEN type = 'credit' THEN amount ELSE -amount END AS amount_signed,
          customer_id
        FROM entries
        UNION ALL
        SELECT
          currency,
          total AS amount_signed,
          customer_id
        FROM invoices
        WHERE payment_type = 'cash'
      )
      GROUP BY currency
      ORDER BY currency
    ''');

    return rows
        .map(
          (r) => CurrencyTotal(
            currency: (r['currency'] ?? 'YER') as String,
            balance: (r['balance'] as num?)?.toDouble() ?? 0,
            transactions: (r['transactions'] as num?)?.toInt() ?? 0,
            customers: (r['customers'] as num?)?.toInt() ?? 0,
          ),
        )
        .toList();
  }

  /// Per-customer report for exactly one currency.
  Future<List<CustomerCurrencyReportRow>> customerCurrencyReport({
    required String currency,
  }) async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT
        c.id AS customer_id,
        c.name AS customer_name,
        c.phone AS phone,
        e.currency AS currency,
        SUM(CASE WHEN e.type = 'credit' THEN e.amount ELSE -e.amount END) AS balance,
        COUNT(e.id) AS transactions
      FROM customers c
      INNER JOIN entries e ON e.customer_id = c.id
      WHERE e.currency = ?
      GROUP BY c.id, e.currency
      ORDER BY c.name COLLATE NOCASE
    ''', [currency]);

    return rows
        .map(
          (r) => CustomerCurrencyReportRow(
            customerId: (r['customer_id'] as num).toInt(),
            customerName: (r['customer_name'] ?? '') as String,
            phone: (r['phone'] ?? '') as String,
            currency: (r['currency'] ?? currency) as String,
            balance: (r['balance'] as num?)?.toDouble() ?? 0,
            transactions: (r['transactions'] as num?)?.toInt() ?? 0,
          ),
        )
        .toList();
  }

  /// All transactions, always retaining their original currency.
  Future<List<EntryWithCustomer>> allEntriesWithCustomers({
    String? currency,
    String? type,
    String query = '',
    int? limit,
  }) async {
    final db = await database;
    final conditions = <String>[];
    final args = <Object?>[];

    if (currency != null && currency.isNotEmpty) {
      conditions.add('e.currency = ?');
      args.add(currency);
    }
    if (type != null && type.isNotEmpty) {
      conditions.add('e.type = ?');
      args.add(type);
    }

    final q = query.trim();
    if (q.isNotEmpty) {
      conditions.add(
        '(c.name LIKE ? OR c.phone LIKE ? OR e.description LIKE ?)',
      );
      args.add('%$q%');
      args.add('%$q%');
      args.add('%$q%');
    }

    final where = conditions.isEmpty ? '' : 'WHERE ${conditions.join(' AND ')}';
    final limitSql = limit == null ? '' : 'LIMIT $limit';

    final rows = await db.rawQuery('''
      SELECT
        e.id,
        e.customer_id,
        e.type,
        e.amount,
        e.currency,
        e.description,
        e.date,
        c.name AS customer_name
      FROM entries e
      INNER JOIN customers c ON c.id = e.customer_id
      $where
      ORDER BY e.date DESC, e.id DESC
      $limitSql
    ''', args);

    return rows.map(EntryWithCustomer.fromMap).toList();
  }

  Future<int> ensureCashCustomer() async {
    final db = await database;
    final rows = await db.query(
      'customers',
      columns: ['id'],
      where: 'name = ?',
      whereArgs: ['نقد'],
      orderBy: 'id ASC',
      limit: 1,
    );
    if (rows.isNotEmpty) return (rows.first['id'] as num).toInt();
    return db.insert(
      'customers',
      Customer(name: 'نقد', createdAt: DateTime.now().toString().substring(0, 16)).toMap(),
    );
  }

  Future<String> nextInvoiceNumber() async {
    final db = await database;
    final rows = await db.rawQuery('SELECT MAX(id) AS max_id FROM invoices');
    final maxId = (rows.first['max_id'] as num?)?.toInt() ?? 0;
    return 'INV-${(maxId + 1).toString().padLeft(6, '0')}';
  }

  Future<int> insertInvoiceWithItems(
    Invoice invoice,
    List<InvoiceItem> items,
  ) async {
    final db = await database;
    return db.transaction((txn) async {
      final invoiceId = await txn.insert('invoices', invoice.toMap());
      for (final item in items) {
        await txn.insert(
          'invoice_items',
          InvoiceItem(
            invoiceId: invoiceId,
            name: item.name,
            quantity: item.quantity,
            price: item.price,
          ).toMap(),
        );
      }

      // A credit invoice (آجل) becomes an "عليه" entry for the named customer.
      // Cash invoices do not create a customer debt. The cash customer is also
      // intentionally excluded from debt entries.
      if (invoice.paymentType == 'credit') {
        final customerRows = await txn.query(
          'customers',
          columns: ['name'],
          where: 'id = ?',
          whereArgs: [invoice.customerId],
          limit: 1,
        );
        final customerName = customerRows.isNotEmpty
            ? (customerRows.first['name'] ?? '') as String
            : '';
        if (customerName.trim() != 'نقد') {
          await txn.insert('entries', {
            'customer_id': invoice.customerId,
            'type': 'debit',
            'amount': invoice.total,
            'currency': invoice.currency,
            'description': 'فاتورة ${invoice.invoiceNumber} - آجل',
            'date': invoice.date,
          });
        }
      }
      return invoiceId;
    });
  }

  /// Cash invoices are shown in the operations screen even though they do
  /// not create a customer debt entry. This keeps cash sales visible without
  /// changing the customer's balance.
  Future<List<InvoiceWithCustomer>> cashInvoicesWithCustomers({
    String? currency,
    String query = '',
  }) async {
    final db = await database;
    final conditions = <String>["i.payment_type = 'cash'"];
    final args = <Object?>[];

    if (currency != null && currency.isNotEmpty) {
      conditions.add('i.currency = ?');
      args.add(currency);
    }

    final q = query.trim();
    if (q.isNotEmpty) {
      conditions.add('(c.name LIKE ? OR i.invoice_number LIKE ? OR i.note LIKE ?)');
      args.add('%$q%');
      args.add('%$q%');
      args.add('%$q%');
    }

    final rows = await db.rawQuery('''
      SELECT i.*, c.name AS customer_name
      FROM invoices i
      INNER JOIN customers c ON c.id = i.customer_id
      WHERE ${conditions.join(' AND ')}
      ORDER BY i.date DESC, i.id DESC
    ''', args);

    return rows.map(InvoiceWithCustomer.fromMap).toList();
  }

  Future<int> deleteInvoice(int invoiceId) async {
    final db = await database;
    return db.transaction((txn) async {
      final rows = await txn.query(
        'invoices',
        columns: ['invoice_number', 'payment_type'],
        where: 'id = ?',
        whereArgs: [invoiceId],
        limit: 1,
      );
      if (rows.isEmpty) return 0;
      final invoiceNumber = rows.first['invoice_number'] as String;
      final paymentType = rows.first['payment_type'] as String? ?? 'cash';
      if (paymentType == 'credit') {
        await txn.delete(
          'entries',
          where: 'description = ?',
          whereArgs: ['فاتورة $invoiceNumber - آجل'],
        );
      }
      await txn.delete('invoice_items', where: 'invoice_id = ?', whereArgs: [invoiceId]);
      return txn.delete('invoices', where: 'id = ?', whereArgs: [invoiceId]);
    });
  }

  Future<List<Invoice>> invoices({String? currency}) async {
    final db = await database;
    final rows = await db.query(
      'invoices',
      where: currency == null ? null : 'currency = ?',
      whereArgs: currency == null ? null : [currency],
      orderBy: 'date DESC, id DESC',
    );
    return rows.map(Invoice.fromMap).toList();
  }

  Future<List<InvoiceItem>> invoiceItems(int invoiceId) async {
    final db = await database;
    final rows = await db.query(
      'invoice_items',
      where: 'invoice_id = ?',
      whereArgs: [invoiceId],
      orderBy: 'id ASC',
    );
    return rows.map(InvoiceItem.fromMap).toList();
  }

  Future<String?> customerNameById(int id) async {
    final db = await database;
    final rows = await db.query(
      'customers',
      columns: ['name'],
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return rows.first['name'] as String?;
  }

  Future<List<Entry>> allEntries() async {
    final db = await database;
    final rows = await db.query(
      'entries',
      orderBy: 'date DESC, id DESC',
    );
    return rows.map(Entry.fromMap).toList();
  }
}
