class Customer {
  final int? id;
  final String name;
  final String phone;
  final String address;
  final String note;
  final String createdAt;

  const Customer({
    this.id,
    required this.name,
    this.phone = '',
    this.address = '',
    this.note = '',
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'phone': phone,
        'address': address,
        'note': note,
        'created_at': createdAt,
      };

  factory Customer.fromMap(Map<String, dynamic> m) => Customer(
        id: m['id'] as int?,
        name: (m['name'] ?? '') as String,
        phone: (m['phone'] ?? '') as String,
        address: (m['address'] ?? '') as String,
        note: (m['note'] ?? '') as String,
        createdAt: (m['created_at'] ?? '') as String,
      );
}

enum EntryType { credit, debit }

extension EntryTypeX on EntryType {
  String get dbValue => this == EntryType.credit ? 'credit' : 'debit';

  String get label => this == EntryType.credit ? 'له' : 'عليه';

  static EntryType fromDb(String value) =>
      value == 'credit' ? EntryType.credit : EntryType.debit;
}

class Entry {
  final int? id;
  final int customerId;
  final EntryType type;
  final double amount;
  final String currency;
  final String description;
  final String date;

  const Entry({
    this.id,
    required this.customerId,
    required this.type,
    required this.amount,
    required this.currency,
    required this.description,
    required this.date,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'customer_id': customerId,
        'type': type.dbValue,
        'amount': amount,
        'currency': currency,
        'description': description,
        'date': date,
      };

  factory Entry.fromMap(Map<String, dynamic> m) => Entry(
        id: m['id'] as int?,
        customerId: (m['customer_id'] as num).toInt(),
        type: EntryTypeX.fromDb(m['type'] as String),
        amount: (m['amount'] as num).toDouble(),
        currency: (m['currency'] ?? 'YER') as String,
        description: (m['description'] ?? '') as String,
        date: (m['date'] ?? '') as String,
      );
}

class CustomerCurrencyBalance {
  final String currency;
  final double balance;
  final int transactions;

  const CustomerCurrencyBalance({
    required this.currency,
    required this.balance,
    required this.transactions,
  });
}

class CurrencyBalanceSplit {
  final String currency;
  final double credit;
  final double debit;

  const CurrencyBalanceSplit({
    required this.currency,
    required this.credit,
    required this.debit,
  });

  double get net => credit - debit;
}

class CurrencyTotal {
  final String currency;
  final double balance;
  final int transactions;
  final int customers;

  const CurrencyTotal({
    required this.currency,
    required this.balance,
    required this.transactions,
    required this.customers,
  });
}


class CustomerDebtAlert {
  final int customerId;
  final String customerName;
  final String phone;
  final String currency;
  final double balance;
  final double credit;
  final double debit;

  const CustomerDebtAlert({
    required this.customerId,
    required this.customerName,
    required this.phone,
    required this.currency,
    required this.balance,
    required this.credit,
    required this.debit,
  });

  double get debt => balance < 0 ? -balance : 0;
}

class CustomerCurrencyReportRow {
  final int customerId;
  final String customerName;
  final String phone;
  final String currency;
  final double balance;
  final int transactions;

  const CustomerCurrencyReportRow({
    required this.customerId,
    required this.customerName,
    required this.phone,
    required this.currency,
    required this.balance,
    required this.transactions,
  });
}

class EntryWithCustomer {
  final Entry entry;
  final String customerName;

  const EntryWithCustomer({
    required this.entry,
    required this.customerName,
  });

  factory EntryWithCustomer.fromEntry(Entry entry, String customerName) =>
      EntryWithCustomer(entry: entry, customerName: customerName);

  factory EntryWithCustomer.fromMap(Map<String, dynamic> m) {
    return EntryWithCustomer(
      entry: Entry.fromMap(m),
      customerName: (m['customer_name'] ?? '') as String,
    );
  }
}


class InvoiceWithCustomer {
  final Invoice invoice;
  final String customerName;

  const InvoiceWithCustomer({
    required this.invoice,
    required this.customerName,
  });

  factory InvoiceWithCustomer.fromMap(Map<String, dynamic> m) {
    return InvoiceWithCustomer(
      invoice: Invoice.fromMap(m),
      customerName: (m['customer_name'] ?? '') as String,
    );
  }
}


class Invoice {
  final int? id;
  final String invoiceNumber;
  final int customerId;
  final String currency;
  final double total;
  final String note;
  final String date;
  final String paymentType;

  const Invoice({
    this.id,
    required this.invoiceNumber,
    required this.customerId,
    required this.currency,
    required this.total,
    required this.note,
    required this.date,
    this.paymentType = 'cash',
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'invoice_number': invoiceNumber,
        'customer_id': customerId,
        'currency': currency,
        'total': total,
        'note': note,
        'date': date,
        'payment_type': paymentType,
      };

  factory Invoice.fromMap(Map<String, dynamic> m) => Invoice(
        id: (m['id'] as num?)?.toInt(),
        invoiceNumber: (m['invoice_number'] ?? '') as String,
        customerId: (m['customer_id'] as num).toInt(),
        currency: (m['currency'] ?? 'YER') as String,
        total: (m['total'] as num?)?.toDouble() ?? 0,
        note: (m['note'] ?? '') as String,
        date: (m['date'] ?? '') as String,
        paymentType: (m['payment_type'] ?? 'cash') as String,
      );
}

class InvoiceItem {
  final int? id;
  final int invoiceId;
  final String name;
  final double quantity;
  final double price;

  const InvoiceItem({
    this.id,
    required this.invoiceId,
    required this.name,
    required this.quantity,
    required this.price,
  });

  double get total => quantity * price;

  Map<String, dynamic> toMap() => {
        'id': id,
        'invoice_id': invoiceId,
        'name': name,
        'quantity': quantity,
        'price': price,
        'total': total,
      };

  factory InvoiceItem.fromMap(Map<String, dynamic> m) => InvoiceItem(
        id: (m['id'] as num?)?.toInt(),
        invoiceId: (m['invoice_id'] as num).toInt(),
        name: (m['name'] ?? '') as String,
        quantity: (m['quantity'] as num?)?.toDouble() ?? 1,
        price: (m['price'] as num?)?.toDouble() ?? 0,
      );
}
