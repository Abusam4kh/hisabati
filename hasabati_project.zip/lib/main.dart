import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:share_plus/share_plus.dart';

import 'database.dart';
import 'models.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const HasabatiApp());
}

class HasabatiApp extends StatelessWidget {
  const HasabatiApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF0D6EFD);
    final scheme = ColorScheme.fromSeed(
      seedColor: seed,
      brightness: Brightness.light,
    );
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'حساباتي',
      locale: const Locale('ar'),
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: scheme,
        scaffoldBackgroundColor: const Color(0xFFF5F7FB),
        fontFamily: 'sans-serif',
        appBarTheme: const AppBarTheme(
          centerTitle: false,
          elevation: 0,
          backgroundColor: Color(0xFFF5F7FB),
          surfaceTintColor: Colors.transparent,
        ),
        cardTheme: const CardThemeData(
          elevation: 0,
          margin: EdgeInsets.zero,
          surfaceTintColor: Colors.white,
          color: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(20)),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: Color(0xFFE6EAF0)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: seed, width: 1.5),
          ),
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 15,
          ),
        ),
        navigationBarTheme: const NavigationBarThemeData(
          height: 74,
          elevation: 0,
          backgroundColor: Colors.white,
        ),
        floatingActionButtonTheme: FloatingActionButtonThemeData(
          backgroundColor: scheme.primary,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
        ),
      ),
      home: const HomePage(),
    );
  }
}

String money(double value) =>
    NumberFormat('#,##0.##', 'en_US').format(value);

String nowText() => DateFormat('yyyy-MM-dd HH:mm').format(DateTime.now());

String dateOnly(String value) {
  if (value.length >= 10) return value.substring(0, 10);
  return value;
}

String currencyName(String code) {
  switch (code) {
    case 'SAR':
      return 'ريال سعودي';
    case 'USD':
      return 'دولار أمريكي';
    default:
      return 'ريال يمني';
  }
}

String currencySymbol(String code) {
  switch (code) {
    case 'SAR':
      return 'ر.س';
    case 'USD':
      return '\$';
    default:
      return 'ر.ي';
  }
}

Color currencyColor(String code) {
  switch (code) {
    case 'SAR':
      return const Color(0xFF138A5B);
    case 'USD':
      return const Color(0xFF7B57C2);
    default:
      return const Color(0xFF0D6EFD);
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;

  @override
  void initState() {
    super.initState();
    AppDatabase.instance.ensureCashCustomer();
  }

  void refresh() => setState(() {});

  void _selectPage(int value) {
    Navigator.of(context).pop();
    if (mounted) setState(() => index = value);
  }

  Future<void> _openAbout() async {
    Navigator.of(context).pop();
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const AboutAppPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardPage(
        onNavigate: (value) => setState(() => index = value),
        onNewInvoice: () async {
          final invoiceNumber = await Navigator.push<String>(
            context,
            MaterialPageRoute(builder: (_) => const InvoicePage()),
          );
          if (mounted && invoiceNumber != null) {
            setState(() {});
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('تم حفظ الفاتورة $invoiceNumber بنجاح')),
            );
          }
        },
      ),
      CustomersPage(onChanged: refresh),
      const TransactionsPage(),
      const InvoicesPage(),
    ];

    return Scaffold(
      drawer: Drawer(
        child: SafeArea(
          child: Column(
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF0D6EFD), Color(0xFF0755C8)],
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                  ),
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(26),
                    bottomRight: Radius.circular(26),
                  ),
                ),
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: Image.asset(
                        'assets/hasabati_logo.png',
                        width: 68,
                        height: 68,
                        fit: BoxFit.cover,
                      ),
                    ),
                    const SizedBox(width: 14),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'حساباتي',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 23,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            'دفتر حساباتك',
                            style: TextStyle(color: Colors.white70),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              _DrawerItem(
                icon: Icons.dashboard_rounded,
                title: 'الرئيسية',
                selected: index == 0,
                onTap: () => _selectPage(0),
              ),
              _DrawerItem(
                icon: Icons.people_rounded,
                title: 'العملاء',
                selected: index == 1,
                onTap: () => _selectPage(1),
              ),
              _DrawerItem(
                icon: Icons.receipt_long_rounded,
                title: 'العمليات',
                selected: index == 2,
                onTap: () => _selectPage(2),
              ),
              _DrawerItem(
                icon: Icons.receipt_rounded,
                title: 'الفواتير',
                selected: index == 3,
                onTap: () => _selectPage(3),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                child: Divider(),
              ),
              _DrawerItem(
                icon: Icons.info_outline_rounded,
                title: 'حول التطبيق',
                onTap: _openAbout,
              ),
              _DrawerItem(
                icon: Icons.code_rounded,
                title: 'عن مبرمج التطبيق',
                onTap: _openAbout,
              ),
              const Spacer(),
              const Padding(
                padding: EdgeInsets.all(18),
                child: Text(
                  'حساباتي • يعمل بدون إنترنت',
                  style: TextStyle(color: Colors.black45, fontSize: 12),
                ),
              ),
            ],
          ),
        ),
      ),
      appBar: AppBar(
        title: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.asset(
                'assets/hasabati_logo.png',
                width: 42,
                height: 42,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(width: 10),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'حساباتي',
                  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 20),
                ),
                Text(
                  'دفتر حساباتك',
                  style: TextStyle(fontSize: 11, color: Colors.black54),
                ),
              ],
            ),
          ],
        ),
        actions: [
          if (index == 1)
            IconButton(
              tooltip: 'بحث',
              onPressed: () async {
                final q = await showSearch<String?>(
                  context: context,
                  delegate: CustomerSearchDelegate(),
                );
                if (q != null && mounted) setState(() {});
              },
              icon: const Icon(Icons.search_rounded),
            ),
        ],
      ),
      body: IndexedStack(index: index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.dashboard_outlined),
            selectedIcon: Icon(Icons.dashboard_rounded),
            label: 'الرئيسية',
          ),
          NavigationDestination(
            icon: Icon(Icons.people_outline_rounded),
            selectedIcon: Icon(Icons.people_rounded),
            label: 'العملاء',
          ),
          NavigationDestination(
            icon: Icon(Icons.receipt_long_outlined),
            selectedIcon: Icon(Icons.receipt_long_rounded),
            label: 'العمليات',
          ),
          NavigationDestination(
            icon: Icon(Icons.receipt_outlined),
            selectedIcon: Icon(Icons.receipt_rounded),
            label: 'الفواتير',
          ),
        ],
      ),
      floatingActionButton: index == 1
          ? FloatingActionButton.extended(
              onPressed: () async {
                final saved = await showDialog<bool>(
                  context: context,
                  builder: (_) => const CustomerDialog(),
                );
                if (saved == true) refresh();
              },
              icon: const Icon(Icons.person_add_alt_1_rounded),
              label: const Text('عميل جديد'),
            )
          : null,
    );
  }
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final bool selected;
  final VoidCallback onTap;

  const _DrawerItem({
    required this.icon,
    required this.title,
    required this.onTap,
    this.selected = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
      child: ListTile(
        selected: selected,
        selectedColor: Theme.of(context).colorScheme.primary,
        selectedTileColor: Theme.of(context).colorScheme.primary.withAlpha(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        leading: Icon(icon),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        onTap: onTap,
      ),
    );
  }
}

class AboutAppPage extends StatelessWidget {
  const AboutAppPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('حول التطبيق')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 30),
        children: [
          Center(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(30),
              child: Image.asset(
                'assets/hasabati_logo.png',
                width: 150,
                height: 150,
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(height: 22),
          const Center(
            child: Text(
              'حساباتي',
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900),
            ),
          ),
          const SizedBox(height: 6),
          const Center(
            child: Text(
              'دفتر حساباتك',
              style: TextStyle(fontSize: 15, color: Colors.black54),
            ),
          ),
          const SizedBox(height: 22),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: const [
                  ListTile(
                    leading: Icon(Icons.apps_rounded),
                    title: Text('اسم التطبيق'),
                    subtitle: Text('حساباتي'),
                  ),
                  Divider(),
                  ListTile(
                    leading: Icon(Icons.verified_rounded),
                    title: Text('الإصدار'),
                    subtitle: Text('1.4.0'),
                  ),
                  Divider(),
                  ListTile(
                    leading: Icon(Icons.code_rounded),
                    title: Text('عن مبرمج التطبيق'),
                    subtitle: Text('تم تطوير التطبيق لإدارة العملاء والعمليات والفواتير محلياً وبواجهة عربية بسيطة.'),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Center(
            child: Text(
              'يعمل التطبيق محلياً بدون الحاجة إلى اتصال بالإنترنت.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black54),
            ),
          ),
        ],
      ),
    );
  }
}

class DashboardPage extends StatefulWidget {
  final ValueChanged<int> onNavigate;
  final VoidCallback onNewInvoice;

  const DashboardPage({
    super.key,
    required this.onNavigate,
    required this.onNewInvoice,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  Future<_DashboardData> _load() async {
    final customers = await AppDatabase.instance.customers();
    final totals = await AppDatabase.instance.currencyTotals();
    final entries = await AppDatabase.instance.allEntriesWithCustomers(limit: 8);
    return _DashboardData(
      customers: customers,
      totals: totals,
      entries: entries,
    );
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async => setState(() {}),
      child: FutureBuilder<_DashboardData>(
        future: _load(),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return _ErrorView(error: snap.error);
          }
          final data = snap.data!;
          return ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
            children: [
              _WelcomeCard(
                customerCount: data.customers.length,
                onAdd: () async {
                  final saved = await showDialog<bool>(
                    context: context,
                    builder: (_) => const CustomerDialog(),
                  );
                  if (saved == true) setState(() {});
                },
                onAddTransaction: () async {
                  final saved = await showDialog<bool>(
                    context: context,
                    builder: (_) => const QuickEntryDialog(),
                  );
                  if (saved == true) setState(() {});
                },
              ),
              const SizedBox(height: 16),
              const _SectionTitle(
                title: 'الأرصدة حسب العملة',
                subtitle: 'كل عملة مستقلة ولا يتم جمع العملات معاً',
              ),
              const SizedBox(height: 10),
              if (data.totals.isEmpty)
                const _EmptyCard(
                  icon: Icons.account_balance_wallet_outlined,
                  text: 'لا توجد عمليات مالية حتى الآن',
                )
              else
                ...data.totals.map(
                  (item) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: CurrencyBalanceCard(item: item),
                  ),
                ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: _ActionCard(
                      icon: Icons.people_alt_outlined,
                      title: 'العملاء',
                      subtitle: '${data.customers.length} عميل',
                      onTap: () => widget.onNavigate(1),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _ActionCard(
                      icon: Icons.receipt_long_outlined,
                      title: 'العمليات',
                      subtitle: 'عرض سجل العمليات',
                      onTap: () => widget.onNavigate(2),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              _ActionCard(
                icon: Icons.receipt_long_rounded,
                title: 'فاتورة جديدة',
                subtitle: 'إنشاء فاتورة وإضافة عدة أصناف وأسعار',
                onTap: widget.onNewInvoice,
              ),
              const SizedBox(height: 22),
              const _SectionTitle(
                title: 'آخر العمليات',
                subtitle: 'أحدث الحركات المسجلة',
              ),
              const SizedBox(height: 10),
              if (data.entries.isEmpty)
                const _EmptyCard(
                  icon: Icons.receipt_long_outlined,
                  text: 'لا توجد عمليات مسجلة',
                )
              else
                ...data.entries.map(
                  (entry) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: TransactionTile(
                      item: entry,
                      compact: true,
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class _DashboardData {
  final List<Customer> customers;
  final List<CurrencyTotal> totals;
  final List<EntryWithCustomer> entries;

  _DashboardData({
    required this.customers,
    required this.totals,
    required this.entries,
  });
}

class _WelcomeCard extends StatelessWidget {
  final int customerCount;
  final VoidCallback onAdd;
  final VoidCallback onAddTransaction;

  const _WelcomeCard({
    required this.customerCount,
    required this.onAdd,
    required this.onAddTransaction,
  });

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF0756C9), Color(0xFF1D86F8)],
          begin: Alignment.bottomRight,
          end: Alignment.topLeft,
        ),
        borderRadius: BorderRadius.circular(26),
        boxShadow: const [
          BoxShadow(
            color: Color(0x220D6EFD),
            blurRadius: 20,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'مرحباً بك 👋',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 23,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 7),
                Text(
                  'لديك $customerCount عميل${customerCount == 1 ? '' : 'اً'} في دفتر الحسابات',
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    FilledButton.icon(
                      onPressed: onAdd,
                      style: FilledButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: primary,
                        padding: const EdgeInsets.symmetric(horizontal: 13),
                      ),
                      icon: const Icon(Icons.person_add_alt_1_rounded, size: 19),
                      label: const Text('إضافة عميل'),
                    ),
                    OutlinedButton.icon(
                      onPressed: onAddTransaction,
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.white,
                        side: const BorderSide(color: Colors.white70),
                        padding: const EdgeInsets.symmetric(horizontal: 13),
                      ),
                      icon: const Icon(Icons.add_card_rounded, size: 19),
                      label: const Text('إضافة عملية'),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Image.asset(
              'assets/hasabati_logo.png',
              width: 82,
              height: 82,
              fit: BoxFit.cover,
            ),
          ),
        ],
      ),
    );
  }
}

class CurrencyBalanceCard extends StatelessWidget {
  final CurrencyTotal item;

  const CurrencyBalanceCard({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    final color = currencyColor(item.currency);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(17),
        child: Row(
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: color.withAlpha(22),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Icon(Icons.account_balance_wallet_rounded, color: color),
            ),
            const SizedBox(width: 13),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    currencyName(item.currency),
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${item.transactions} عملية • ${item.customers} عميل',
                    style: const TextStyle(
                      color: Colors.black54,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  money(item.balance),
                  style: TextStyle(
                    color: item.balance >= 0 ? color : Colors.red.shade700,
                    fontSize: 19,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                Text(
                  currencySymbol(item.currency),
                  style: const TextStyle(color: Colors.black54, fontSize: 11),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: Theme.of(context).colorScheme.primary),
              const SizedBox(height: 12),
              Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: const TextStyle(fontSize: 11, color: Colors.black54),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CustomersPage extends StatefulWidget {
  final VoidCallback? onChanged;

  const CustomersPage({super.key, this.onChanged});

  @override
  State<CustomersPage> createState() => _CustomersPageState();
}

class _CustomersPageState extends State<CustomersPage> {
  String search = '';

  Future<List<Customer>> _load() =>
      AppDatabase.instance.customers(query: search);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
          child: TextField(
            textInputAction: TextInputAction.search,
            decoration: const InputDecoration(
              hintText: 'ابحث باسم العميل أو رقم الهاتف',
              prefixIcon: Icon(Icons.search_rounded),
            ),
            onChanged: (value) => setState(() => search = value),
          ),
        ),
        Expanded(
          child: FutureBuilder<List<Customer>>(
            future: _load(),
            builder: (context, snap) {
              if (snap.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snap.hasError) return _ErrorView(error: snap.error);
              final customers = snap.data!;
              if (customers.isEmpty) {
                return const _EmptyCard(
                  icon: Icons.people_outline_rounded,
                  text: 'لا يوجد عملاء. أضف أول عميل من زر +',
                );
              }
              return RefreshIndicator(
                onRefresh: () async => setState(() {}),
                child: ListView.separated(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 100),
                  itemCount: customers.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (_, index) {
                    final customer = customers[index];
                    return CustomerTile(
                      customer: customer,
                      onTap: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => CustomerPage(customer: customer),
                          ),
                        );
                        setState(() {});
                        widget.onChanged?.call();
                      },
                    );
                  },
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class CustomerTile extends StatelessWidget {
  final Customer customer;
  final VoidCallback onTap;

  const CustomerTile({
    super.key,
    required this.customer,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<CustomerCurrencyBalance>>(
      future: AppDatabase.instance.customerCurrencyBalances(customer.id!),
      builder: (context, snap) {
        final balances = snap.data ?? [];
        return Card(
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(20),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 25,
                    backgroundColor:
                        Theme.of(context).colorScheme.primaryContainer,
                    child: Text(
                      customer.name.isEmpty
                          ? '?'
                          : customer.name.characters.first,
                      style: TextStyle(
                        fontWeight: FontWeight.w900,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                    ),
                  ),
                  const SizedBox(width: 13),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          customer.name,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        if (customer.phone.isNotEmpty) ...[
                          const SizedBox(height: 3),
                          Text(
                            customer.phone,
                            style: const TextStyle(
                              fontSize: 11,
                              color: Colors.black54,
                            ),
                          ),
                        ],
                        if (balances.isNotEmpty) ...[
                          const SizedBox(height: 8),
                          Wrap(
                            spacing: 6,
                            runSpacing: 5,
                            children: balances
                                .map(
                                  (b) => _BalanceChip(
                                    currency: b.currency,
                                    value: b.balance,
                                  ),
                                )
                                .toList(),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_left_rounded, color: Colors.black38),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _BalanceChip extends StatelessWidget {
  final String currency;
  final double value;

  const _BalanceChip({required this.currency, required this.value});

  @override
  Widget build(BuildContext context) {
    final color = currencyColor(currency);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
        color: color.withAlpha(18),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        '${money(value)} ${currencySymbol(currency)}',
        style: TextStyle(
          color: value >= 0 ? color : Colors.red.shade700,
          fontSize: 11,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class CustomerSearchDelegate extends SearchDelegate<String?> {
  CustomerSearchDelegate()
      : super(searchFieldLabel: 'اسم العميل أو الهاتف');

  @override
  List<Widget>? buildActions(BuildContext context) => [
        if (query.isNotEmpty)
          IconButton(
            onPressed: () => query = '',
            icon: const Icon(Icons.clear_rounded),
          ),
      ];

  @override
  Widget? buildLeading(BuildContext context) => IconButton(
        onPressed: () => close(context, null),
        icon: const Icon(Icons.arrow_back_rounded),
      );

  @override
  Widget buildResults(BuildContext context) => _result();

  @override
  Widget buildSuggestions(BuildContext context) => _result();

  Widget _result() {
    return FutureBuilder<List<Customer>>(
      future: AppDatabase.instance.customers(query: query),
      builder: (context, snap) {
        final data = snap.data ?? [];
        return ListView(
          children: data
              .map(
                (c) => ListTile(
                  leading: CircleAvatar(child: Text(c.name.characters.first)),
                  title: Text(c.name),
                  subtitle: Text(c.phone),
                  onTap: () => close(context, c.name),
                ),
              )
              .toList(),
        );
      },
    );
  }
}

class CustomerPage extends StatefulWidget {
  final Customer customer;

  const CustomerPage({super.key, required this.customer});

  @override
  State<CustomerPage> createState() => _CustomerPageState();
}

class _CustomerPageState extends State<CustomerPage> {
  String currencyFilter = 'ALL';

  Future<List<Entry>> _load() =>
      AppDatabase.instance.entriesForCustomer(
        widget.customer.id!,
        currency: currencyFilter == 'ALL' ? null : currencyFilter,
      );

  Future<void> _edit() async {
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => CustomerDialog(customer: widget.customer),
    );
    if (saved == true) setState(() {});
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('حذف العميل'),
        content: const Text(
          'سيتم حذف العميل وجميع عملياته المالية. هل تريد المتابعة؟',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (ok == true) {
      await AppDatabase.instance.deleteCustomer(widget.customer.id!);
      if (mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.customer.name,
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
        actions: [
          IconButton(
            tooltip: 'تعديل',
            onPressed: _edit,
            icon: const Icon(Icons.edit_outlined),
          ),
          IconButton(
            tooltip: 'حذف',
            onPressed: _delete,
            icon: const Icon(Icons.delete_outline_rounded),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final saved = await showDialog<bool>(
            context: context,
            builder: (_) => EntryDialog(customerId: widget.customer.id!),
          );
          if (saved == true) setState(() {});
        },
        icon: const Icon(Icons.add_rounded),
        label: const Text('إضافة عملية'),
      ),
      body: FutureBuilder<List<CustomerCurrencyBalance>>(
        future: AppDatabase.instance.customerCurrencyBalances(
          widget.customer.id!,
        ),
        builder: (context, balanceSnap) {
          final balances = balanceSnap.data ?? [];
          return FutureBuilder<List<Entry>>(
            future: _load(),
            builder: (context, snap) {
              if (snap.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snap.hasError) return _ErrorView(error: snap.error);
              final entries = snap.data!;
              return ListView(
                padding: const EdgeInsets.fromLTRB(16, 6, 16, 105),
                children: [
                  _CustomerHeader(customer: widget.customer),
                  const SizedBox(height: 12),
                  if (balances.isNotEmpty) ...[
                    const _SectionTitle(
                      title: 'أرصدة العميل',
                      subtitle: 'كل عملة في رصيد مستقل',
                    ),
                    const SizedBox(height: 9),
                    Wrap(
                      spacing: 9,
                      runSpacing: 9,
                      children: balances
                          .map(
                            (b) => SizedBox(
                              width: (MediaQuery.sizeOf(context).width - 41) / 2,
                              child: _MiniBalanceCard(item: b),
                            ),
                          )
                          .toList(),
                    ),
                    const SizedBox(height: 18),
                  ],
                  const _SectionTitle(
                    title: 'سجل العمليات',
                    subtitle: 'يمكنك تصفية السجل حسب العملة',
                  ),
                  const SizedBox(height: 9),
                  _CurrencyFilter(
                    selected: currencyFilter,
                    onChanged: (v) => setState(() => currencyFilter = v),
                  ),
                  const SizedBox(height: 10),
                  if (entries.isEmpty)
                    const _EmptyCard(
                      icon: Icons.receipt_long_outlined,
                      text: 'لا توجد عمليات بهذه العملة',
                    )
                  else
                    ...entries.map(
                      (e) => Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: TransactionTile(
                          item: EntryWithCustomer.fromEntry(
                            e,
                            widget.customer.name,
                          ),
                          onDeleted: () => setState(() {}),
                        ),
                      ),
                    ),
                ],
              );
            },
          );
        },
      ),
    );
  }
}

class _CustomerHeader extends StatelessWidget {
  final Customer customer;

  const _CustomerHeader({required this.customer});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(17),
        child: Row(
          children: [
            CircleAvatar(
              radius: 30,
              backgroundColor: Theme.of(context).colorScheme.primaryContainer,
              child: Text(
                customer.name.isEmpty ? '?' : customer.name.characters.first,
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  color: Theme.of(context).colorScheme.primary,
                ),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    customer.name,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  if (customer.phone.isNotEmpty)
                    Text(
                      customer.phone,
                      style: const TextStyle(
                        color: Colors.black54,
                        fontSize: 12,
                      ),
                    ),
                  if (customer.address.isNotEmpty)
                    Text(
                      customer.address,
                      style: const TextStyle(
                        color: Colors.black54,
                        fontSize: 12,
                      ),
                    ),
                  if (customer.note.isNotEmpty)
                    Text(
                      customer.note,
                      style: const TextStyle(
                        color: Colors.black54,
                        fontSize: 12,
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MiniBalanceCard extends StatelessWidget {
  final CustomerCurrencyBalance item;

  const _MiniBalanceCard({required this.item});

  @override
  Widget build(BuildContext context) {
    final color = currencyColor(item.currency);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.payments_outlined, color: color, size: 20),
                const SizedBox(width: 7),
                Expanded(
                  child: Text(
                    currencyName(item.currency),
                    style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              money(item.balance),
              style: TextStyle(
                color: item.balance >= 0 ? color : Colors.red.shade700,
                fontSize: 19,
                fontWeight: FontWeight.w900,
              ),
            ),
            Text(
              '${item.transactions} عملية',
              style: const TextStyle(fontSize: 10, color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }
}


class QuickEntryDialog extends StatefulWidget {
  const QuickEntryDialog({super.key});

  @override
  State<QuickEntryDialog> createState() => _QuickEntryDialogState();
}

class _QuickEntryDialogState extends State<QuickEntryDialog> {
  final form = GlobalKey<FormState>();
  final amount = TextEditingController();
  final description = TextEditingController();
  EntryType type = EntryType.credit;
  String currency = 'YER';
  int? customerId;
  List<Customer> customers = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _loadCustomers();
  }

  Future<void> _loadCustomers() async {
    final data = await AppDatabase.instance.customers();
    if (!mounted) return;
    setState(() {
      customers = data;
      customerId = data.isEmpty ? null : data.first.id;
      loading = false;
    });
  }

  @override
  void dispose() {
    amount.dispose();
    description.dispose();
    super.dispose();
  }

  Future<void> _addCustomer() async {
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => const CustomerDialog(),
    );
    if (saved == true) await _loadCustomers();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text(
        'إضافة عملية جديدة',
        style: TextStyle(fontWeight: FontWeight.w800),
      ),
      content: SizedBox(
        width: 430,
        child: loading
            ? const SizedBox(
                height: 120,
                child: Center(child: CircularProgressIndicator()),
              )
            : Form(
                key: form,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (customers.isEmpty)
                        Card(
                          color: Theme.of(context).colorScheme.primaryContainer,
                          child: ListTile(
                            leading: const Icon(Icons.person_add_alt_1_rounded),
                            title: const Text('لا يوجد عملاء'),
                            subtitle: const Text('أضف عميلاً أولاً لتسجيل العملية'),
                            trailing: TextButton(
                              onPressed: _addCustomer,
                              child: const Text('إضافة'),
                            ),
                          ),
                        )
                      else
                        Row(
                          children: [
                            Expanded(
                              child: DropdownButtonFormField<int>(
                                value: customerId,
                                isExpanded: true,
                                decoration: const InputDecoration(
                                  labelText: 'العميل',
                                  prefixIcon: Icon(Icons.person_outline_rounded),
                                ),
                                items: customers
                                    .map(
                                      (c) => DropdownMenuItem<int>(
                                        value: c.id,
                                        child: Text(c.name),
                                      ),
                                    )
                                    .toList(),
                                onChanged: (v) => setState(() => customerId = v),
                                validator: (v) => v == null ? 'اختر العميل' : null,
                              ),
                            ),
                            IconButton(
                              tooltip: 'إضافة عميل',
                              onPressed: _addCustomer,
                              icon: const Icon(Icons.person_add_alt_1_rounded),
                            ),
                          ],
                        ),
                      const SizedBox(height: 12),
                      SegmentedButton<EntryType>(
                        segments: const [
                          ButtonSegment(
                            value: EntryType.credit,
                            label: Text('له'),
                            icon: Icon(Icons.arrow_downward_rounded),
                          ),
                          ButtonSegment(
                            value: EntryType.debit,
                            label: Text('عليه'),
                            icon: Icon(Icons.arrow_upward_rounded),
                          ),
                        ],
                        selected: {type},
                        onSelectionChanged: (v) => setState(() => type = v.first),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: amount,
                        autofocus: customers.isNotEmpty,
                        keyboardType: const TextInputType.numberWithOptions(
                          decimal: true,
                        ),
                        decoration: const InputDecoration(
                          labelText: 'المبلغ',
                          prefixIcon: Icon(Icons.payments_outlined),
                        ),
                        validator: (v) {
                          final n = double.tryParse(v?.trim() ?? '');
                          return n == null || n <= 0 ? 'أدخل مبلغاً صحيحاً' : null;
                        },
                      ),
                      const SizedBox(height: 10),
                      DropdownButtonFormField<String>(
                        value: currency,
                        decoration: const InputDecoration(
                          labelText: 'العملة',
                          prefixIcon: Icon(Icons.currency_exchange_rounded),
                        ),
                        items: const [
                          DropdownMenuItem(value: 'YER', child: Text('ريال يمني YER')),
                          DropdownMenuItem(value: 'SAR', child: Text('ريال سعودي SAR')),
                          DropdownMenuItem(value: 'USD', child: Text('دولار أمريكي USD')),
                        ],
                        onChanged: (v) {
                          if (v != null) setState(() => currency = v);
                        },
                      ),
                      const SizedBox(height: 10),
                      TextFormField(
                        controller: description,
                        maxLines: 2,
                        decoration: const InputDecoration(
                          labelText: 'البيان / الملاحظة',
                          prefixIcon: Icon(Icons.notes_rounded),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, false),
          child: const Text('إلغاء'),
        ),
        FilledButton.icon(
          onPressed: customers.isEmpty ? null : _save,
          icon: const Icon(Icons.check_rounded),
          label: const Text('حفظ العملية'),
        ),
      ],
    );
  }

  Future<void> _save() async {
    if (!form.currentState!.validate() || customerId == null) return;
    await AppDatabase.instance.insertEntry(
      Entry(
        customerId: customerId!,
        type: type,
        amount: double.parse(amount.text.trim()),
        currency: currency,
        description: description.text.trim(),
        date: nowText(),
      ),
    );
    if (mounted) Navigator.pop(context, true);
  }
}

class EntryDialog extends StatefulWidget {
  final int customerId;

  const EntryDialog({super.key, required this.customerId});

  @override
  State<EntryDialog> createState() => _EntryDialogState();
}

class _EntryDialogState extends State<EntryDialog> {
  final form = GlobalKey<FormState>();
  final amount = TextEditingController();
  final description = TextEditingController();
  EntryType type = EntryType.credit;
  String currency = 'YER';

  @override
  void dispose() {
    amount.dispose();
    description.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text(
        'إضافة عملية',
        style: TextStyle(fontWeight: FontWeight.w800),
      ),
      content: Form(
        key: form,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SegmentedButton<EntryType>(
                segments: const [
                  ButtonSegment(
                    value: EntryType.credit,
                    label: Text('له'),
                    icon: Icon(Icons.arrow_downward_rounded),
                  ),
                  ButtonSegment(
                    value: EntryType.debit,
                    label: Text('عليه'),
                    icon: Icon(Icons.arrow_upward_rounded),
                  ),
                ],
                selected: {type},
                onSelectionChanged: (v) => setState(() => type = v.first),
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: amount,
                autofocus: true,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: const InputDecoration(
                  labelText: 'المبلغ',
                  prefixIcon: Icon(Icons.payments_outlined),
                ),
                validator: (v) {
                  final n = double.tryParse(v?.trim() ?? '');
                  return n == null || n <= 0 ? 'أدخل مبلغاً صحيحاً' : null;
                },
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: currency,
                decoration: const InputDecoration(
                  labelText: 'العملة',
                  prefixIcon: Icon(Icons.currency_exchange_rounded),
                ),
                items: const [
                  DropdownMenuItem(
                    value: 'YER',
                    child: Text('ريال يمني YER'),
                  ),
                  DropdownMenuItem(
                    value: 'SAR',
                    child: Text('ريال سعودي SAR'),
                  ),
                  DropdownMenuItem(
                    value: 'USD',
                    child: Text('دولار أمريكي USD'),
                  ),
                ],
                onChanged: (v) {
                  if (v != null) setState(() => currency = v);
                },
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: description,
                maxLines: 2,
                decoration: const InputDecoration(
                  labelText: 'البيان / الملاحظة',
                  prefixIcon: Icon(Icons.notes_rounded),
                ),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, false),
          child: const Text('إلغاء'),
        ),
        FilledButton.icon(
          onPressed: _save,
          icon: const Icon(Icons.check_rounded),
          label: const Text('حفظ'),
        ),
      ],
    );
  }

  Future<void> _save() async {
    if (!form.currentState!.validate()) return;
    await AppDatabase.instance.insertEntry(
      Entry(
        customerId: widget.customerId,
        type: type,
        amount: double.parse(amount.text.trim()),
        currency: currency,
        description: description.text.trim(),
        date: nowText(),
      ),
    );
    if (mounted) Navigator.pop(context, true);
  }
}


class InvoicePage extends StatefulWidget {
  const InvoicePage({super.key});

  @override
  State<InvoicePage> createState() => _InvoicePageState();
}

class _InvoicePageState extends State<InvoicePage> {
  final form = GlobalKey<FormState>();
  final note = TextEditingController();
  final List<_InvoiceLineControllers> lines = [_InvoiceLineControllers()];
  List<Customer> customers = [];
  int? customerId;
  String currency = 'YER';
  String paymentType = 'cash';
  String invoiceNumber = '...';
  bool loading = true;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    _prepare();
  }

  Future<void> _prepare() async {
    final cashId = await AppDatabase.instance.ensureCashCustomer();
    final data = await AppDatabase.instance.customers();
    final number = await AppDatabase.instance.nextInvoiceNumber();
    if (!mounted) return;
    setState(() {
      customers = data;
      customerId = cashId;
      invoiceNumber = number;
      loading = false;
    });
  }

  @override
  void dispose() {
    note.dispose();
    for (final line in lines) {
      line.dispose();
    }
    super.dispose();
  }

  Future<void> _addCustomer() async {
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => const CustomerDialog(),
    );
    if (saved == true) {
      final data = await AppDatabase.instance.customers();
      if (!mounted) return;
      setState(() => customers = data);
    }
  }

  void _addLine() {
    setState(() => lines.add(_InvoiceLineControllers()));
  }

  void _removeLine(int index) {
    if (lines.length == 1) return;
    final line = lines.removeAt(index);
    line.dispose();
    setState(() {});
  }

  bool get _isCashCustomer {
    for (final customer in customers) {
      if (customer.id == customerId) return customer.name.trim() == 'نقد';
    }
    return false;
  }

  double _lineTotal(_InvoiceLineControllers line) {
    final qty = double.tryParse(line.quantity.text.trim()) ?? 0;
    final price = double.tryParse(line.price.text.trim()) ?? 0;
    return qty * price;
  }

  double get _grandTotal => lines.fold(0.0, (sum, line) => sum + _lineTotal(line));

  Future<void> _save() async {
    if (saving || customerId == null) return;
    if (!form.currentState!.validate()) return;
    for (final line in lines) {
      if (line.name.text.trim().isEmpty) {
        _showMessage('اكتب اسم الصنف في جميع الصفوف');
        return;
      }
      final qty = double.tryParse(line.quantity.text.trim()) ?? 0;
      final price = double.tryParse(line.price.text.trim()) ?? 0;
      if (qty <= 0 || price <= 0) {
        _showMessage('تحقق من الكمية والسعر في أصناف الفاتورة');
        return;
      }
    }

    setState(() => saving = true);
    final items = lines
        .map(
          (line) => InvoiceItem(
            invoiceId: 0,
            name: line.name.text.trim(),
            quantity: double.parse(line.quantity.text.trim()),
            price: double.parse(line.price.text.trim()),
          ),
        )
        .toList();

    try {
      await AppDatabase.instance.insertInvoiceWithItems(
        Invoice(
          invoiceNumber: invoiceNumber,
          customerId: customerId!,
          currency: currency,
          total: _grandTotal,
          note: note.text.trim(),
          date: nowText(),
          paymentType: _isCashCustomer ? 'cash' : paymentType,
        ),
        items,
      );
      if (mounted) Navigator.pop(context, invoiceNumber);
    } catch (e) {
      if (!mounted) return;
      setState(() => saving = false);
      _showMessage('تعذر حفظ الفاتورة. حاول مرة أخرى.');
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'فاتورة جديدة',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        actions: [
          Padding(
            padding: const EdgeInsetsDirectional.only(end: 12),
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  invoiceNumber,
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.primary,
                    fontWeight: FontWeight.w900,
                    fontSize: 12,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      body: Form(
        key: form,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
          children: [
            _InvoiceHeaderCard(
              invoiceNumber: invoiceNumber,
              date: nowText(),
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(15),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'بيانات الفاتورة',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: DropdownButtonFormField<int>(
                            value: customerId,
                            isExpanded: true,
                            decoration: const InputDecoration(
                              labelText: 'العميل',
                              prefixIcon: Icon(Icons.person_outline_rounded),
                            ),
                            items: customers
                                .map(
                                  (c) => DropdownMenuItem<int>(
                                    value: c.id,
                                    child: Text(c.name),
                                  ),
                                )
                                .toList(),
                            onChanged: (v) {
                              setState(() {
                                customerId = v;
                                if (_isCashCustomer) paymentType = 'cash';
                              });
                            },
                            validator: (v) => v == null ? 'اختر العميل' : null,
                          ),
                        ),
                        IconButton(
                          tooltip: 'إضافة عميل',
                          onPressed: _addCustomer,
                          icon: const Icon(Icons.person_add_alt_1_rounded),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<String>(
                      value: currency,
                      decoration: const InputDecoration(
                        labelText: 'عملة الفاتورة',
                        prefixIcon: Icon(Icons.currency_exchange_rounded),
                      ),
                      items: const [
                        DropdownMenuItem(value: 'YER', child: Text('ريال يمني YER')),
                        DropdownMenuItem(value: 'SAR', child: Text('ريال سعودي SAR')),
                        DropdownMenuItem(value: 'USD', child: Text('دولار أمريكي USD')),
                      ],
                      onChanged: (v) {
                        if (v != null) setState(() => currency = v);
                      },
                    ),
                    if (!_isCashCustomer) ...[
                      const SizedBox(height: 12),
                      const Text(
                        'طريقة السداد',
                        style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(height: 8),
                      SegmentedButton<String>(
                        segments: const [
                          ButtonSegment<String>(
                            value: 'cash',
                            icon: Icon(Icons.payments_outlined),
                            label: Text('نقد'),
                          ),
                          ButtonSegment<String>(
                            value: 'credit',
                            icon: Icon(Icons.schedule_rounded),
                            label: Text('آجل'),
                          ),
                        ],
                        selected: {paymentType},
                        onSelectionChanged: (value) {
                          setState(() => paymentType = value.first);
                        },
                      ),
                      if (paymentType == 'credit')
                        Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Text(
                            'سيتم تسجيل إجمالي الفاتورة على العميل كـ «عليه».',
                            style: TextStyle(
                              color: Colors.orange.shade800,
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 14, 12, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'أصناف الفاتورة',
                                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
                              ),
                              SizedBox(height: 3),
                              Text(
                                'أضف أي عدد من الأصناف واكتب السعر والكمية يدوياً',
                                style: TextStyle(fontSize: 11, color: Colors.black54),
                              ),
                            ],
                          ),
                        ),
                        FilledButton.icon(
                          onPressed: _addLine,
                          icon: const Icon(Icons.add_rounded, size: 18),
                          label: const Text('إضافة صنف'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Table(
                        defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                        columnWidths: const {
                          0: FixedColumnWidth(170),
                          1: FixedColumnWidth(85),
                          2: FixedColumnWidth(120),
                          3: FixedColumnWidth(120),
                          4: FixedColumnWidth(48),
                        },
                        border: TableBorder.all(
                          color: Color(0xFFE6EAF0),
                          borderRadius: BorderRadius.all(Radius.circular(14)),
                        ),
                        children: [
                          TableRow(
                            decoration: const BoxDecoration(color: Color(0xFFF6F8FC)),
                            children: const [
                              _InvoiceTableHeader('الصنف'),
                              _InvoiceTableHeader('الكمية'),
                              _InvoiceTableHeader('السعر'),
                              _InvoiceTableHeader('الإجمالي'),
                              _InvoiceTableHeader(''),
                            ],
                          ),
                          ...List.generate(lines.length, (index) {
                            final line = lines[index];
                            return TableRow(
                              children: [
                                _InvoiceCell(
                                  child: TextField(
                                    controller: line.name,
                                    decoration: const InputDecoration(
                                      hintText: 'اسم الصنف',
                                      border: InputBorder.none,
                                      filled: false,
                                    ),
                                    onChanged: (_) => setState(() {}),
                                  ),
                                ),
                                _InvoiceCell(
                                  child: TextField(
                                    controller: line.quantity,
                                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                    textAlign: TextAlign.center,
                                    decoration: const InputDecoration(
                                      hintText: '1',
                                      border: InputBorder.none,
                                      filled: false,
                                    ),
                                    onChanged: (_) => setState(() {}),
                                  ),
                                ),
                                _InvoiceCell(
                                  child: TextField(
                                    controller: line.price,
                                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                    textAlign: TextAlign.center,
                                    decoration: const InputDecoration(
                                      hintText: '0',
                                      border: InputBorder.none,
                                      filled: false,
                                    ),
                                    onChanged: (_) => setState(() {}),
                                  ),
                                ),
                                _InvoiceCell(
                                  child: Text(
                                    money(_lineTotal(line)),
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(fontWeight: FontWeight.w900),
                                  ),
                                ),
                                _InvoiceCell(
                                  child: IconButton(
                                    onPressed: lines.length == 1 ? null : () => _removeLine(index),
                                    icon: const Icon(Icons.delete_outline_rounded),
                                    color: Colors.red,
                                  ),
                                ),
                              ],
                            );
                          }),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                      decoration: BoxDecoration(
                        color: currencyColor(currency).withAlpha(15),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Row(
                        children: [
                          const Expanded(
                            child: Text(
                              'إجمالي الفاتورة',
                              style: TextStyle(fontWeight: FontWeight.w800),
                            ),
                          ),
                          Text(
                            '${money(_grandTotal)} ${currencySymbol(currency)}',
                            style: TextStyle(
                              color: currencyColor(currency),
                              fontSize: 19,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(15),
                child: TextFormField(
                  controller: note,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'ملاحظة الفاتورة',
                    hintText: 'اكتب أي ملاحظة إضافية هنا',
                    prefixIcon: Icon(Icons.notes_rounded),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: saving ? null : _save,
              style: FilledButton.styleFrom(
                minimumSize: const Size.fromHeight(54),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              icon: saving
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.save_rounded),
              label: Text(saving ? 'جارٍ الحفظ...' : 'حفظ الفاتورة'),
            ),
          ],
        ),
      ),
    );
  }
}

class _InvoiceLineControllers {
  final name = TextEditingController();
  final quantity = TextEditingController(text: '1');
  final price = TextEditingController();

  void dispose() {
    name.dispose();
    quantity.dispose();
    price.dispose();
  }
}

class _InvoiceTableHeader extends StatelessWidget {
  final String text;

  const _InvoiceTableHeader(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900),
      ),
    );
  }
}

class _InvoiceCell extends StatelessWidget {
  final Widget child;

  const _InvoiceCell({required this.child});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
      child: child,
    );
  }
}

class _InvoiceHeaderCard extends StatelessWidget {
  final String invoiceNumber;
  final String date;

  const _InvoiceHeaderCard({required this.invoiceNumber, required this.date});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF0756C9), Color(0xFF1D86F8)],
          begin: Alignment.bottomRight,
          end: Alignment.topLeft,
        ),
        borderRadius: BorderRadius.circular(22),
      ),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: Colors.white.withAlpha(30),
              borderRadius: BorderRadius.circular(15),
            ),
            child: const Icon(Icons.receipt_long_rounded, color: Colors.white, size: 27),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'فاتورة مبيعات',
                  style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 4),
                Text(
                  'رقم الفاتورة: $invoiceNumber',
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                ),
                Text(
                  'التاريخ: ${dateOnly(date)}',
                  style: const TextStyle(color: Colors.white70, fontSize: 11),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class CustomerDialog extends StatefulWidget {
  final Customer? customer;

  const CustomerDialog({super.key, this.customer});

  @override
  State<CustomerDialog> createState() => _CustomerDialogState();
}

class _CustomerDialogState extends State<CustomerDialog> {
  final form = GlobalKey<FormState>();
  late final TextEditingController name;
  late final TextEditingController phone;
  late final TextEditingController address;
  late final TextEditingController note;

  @override
  void initState() {
    super.initState();
    final c = widget.customer;
    name = TextEditingController(text: c?.name ?? '');
    phone = TextEditingController(text: c?.phone ?? '');
    address = TextEditingController(text: c?.address ?? '');
    note = TextEditingController(text: c?.note ?? '');
  }

  @override
  void dispose() {
    name.dispose();
    phone.dispose();
    address.dispose();
    note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(
        widget.customer == null ? 'إضافة عميل جديد' : 'تعديل بيانات العميل',
        style: const TextStyle(fontWeight: FontWeight.w800),
      ),
      content: Form(
        key: form,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: name,
                autofocus: true,
                decoration: const InputDecoration(
                  labelText: 'اسم العميل *',
                  prefixIcon: Icon(Icons.person_outline_rounded),
                ),
                validator: (v) =>
                    v!.trim().isEmpty ? 'أدخل اسم العميل' : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: phone,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: 'رقم الهاتف',
                  prefixIcon: Icon(Icons.phone_outlined),
                ),
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: address,
                decoration: const InputDecoration(
                  labelText: 'العنوان',
                  prefixIcon: Icon(Icons.location_on_outlined),
                ),
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: note,
                maxLines: 2,
                decoration: const InputDecoration(
                  labelText: 'ملاحظة',
                  prefixIcon: Icon(Icons.notes_outlined),
                ),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, false),
          child: const Text('إلغاء'),
        ),
        FilledButton.icon(
          onPressed: _save,
          icon: const Icon(Icons.check_rounded),
          label: const Text('حفظ'),
        ),
      ],
    );
  }

  Future<void> _save() async {
    if (!form.currentState!.validate()) return;
    final old = widget.customer;
    final customer = Customer(
      id: old?.id,
      name: name.text.trim(),
      phone: phone.text.trim(),
      address: address.text.trim(),
      note: note.text.trim(),
      createdAt: old?.createdAt ?? nowText(),
    );
    if (old == null) {
      await AppDatabase.instance.insertCustomer(customer);
    } else {
      await AppDatabase.instance.updateCustomer(customer);
    }
    if (mounted) Navigator.pop(context, true);
  }
}

class TransactionsPage extends StatefulWidget {
  const TransactionsPage({super.key});

  @override
  State<TransactionsPage> createState() => _TransactionsPageState();
}

class _TransactionsPageState extends State<TransactionsPage> {
  String currency = 'ALL';
  String type = 'ALL';
  String search = '';

  Future<_TransactionsData> _load() async {
    final entries = await AppDatabase.instance.allEntriesWithCustomers(
      currency: currency == 'ALL' ? null : currency,
      type: type == 'ALL' ? null : type,
      query: search,
    );
    final cashInvoices = (type == 'ALL' || type == 'credit')
        ? await AppDatabase.instance.cashInvoicesWithCustomers(
            currency: currency == 'ALL' ? null : currency,
            query: search,
          )
        : <InvoiceWithCustomer>[];
    return _TransactionsData(entries: entries, cashInvoices: cashInvoices);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 9),
          child: TextField(
            decoration: const InputDecoration(
              hintText: 'ابحث في العمليات أو الفواتير أو أسماء العملاء',
              prefixIcon: Icon(Icons.search_rounded),
            ),
            onChanged: (v) => setState(() => search = v),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              Expanded(
                child: _SimpleDropdown(
                  value: currency,
                  items: const [
                    DropdownMenuItem(value: 'ALL', child: Text('كل العملات')),
                    DropdownMenuItem(value: 'YER', child: Text('ريال يمني')),
                    DropdownMenuItem(value: 'SAR', child: Text('ريال سعودي')),
                    DropdownMenuItem(value: 'USD', child: Text('دولار أمريكي')),
                  ],
                  onChanged: (v) => setState(() => currency = v),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _SimpleDropdown(
                  value: type,
                  items: const [
                    DropdownMenuItem(value: 'ALL', child: Text('كل العمليات')),
                    DropdownMenuItem(value: 'credit', child: Text('له + فواتير نقد')),
                    DropdownMenuItem(value: 'debit', child: Text('عليه')),
                  ],
                  onChanged: (v) => setState(() => type = v),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 9),
        Expanded(
          child: FutureBuilder<_TransactionsData>(
            future: _load(),
            builder: (context, snap) {
              if (snap.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snap.hasError) return _ErrorView(error: snap.error);
              final data = snap.data!;
              final total = data.entries.length + data.cashInvoices.length;
              if (total == 0) {
                return const _EmptyCard(
                  icon: Icons.receipt_long_outlined,
                  text: 'لا توجد عمليات مطابقة',
                );
              }
              return RefreshIndicator(
                onRefresh: () async => setState(() {}),
                child: ListView.separated(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 100),
                  itemCount: total,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (_, i) {
                    if (i < data.entries.length) {
                      return TransactionTile(
                        item: data.entries[i],
                        onDeleted: () => setState(() {}),
                      );
                    }
                    return CashInvoiceOperationTile(
                      item: data.cashInvoices[i - data.entries.length],
                    );
                  },
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _TransactionsData {
  final List<EntryWithCustomer> entries;
  final List<InvoiceWithCustomer> cashInvoices;

  const _TransactionsData({
    required this.entries,
    required this.cashInvoices,
  });
}

class CashInvoiceOperationTile extends StatelessWidget {
  final InvoiceWithCustomer item;

  const CashInvoiceOperationTile({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    final color = currencyColor(item.invoice.currency);
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        leading: Container(
          width: 43,
          height: 43,
          decoration: BoxDecoration(
            color: color.withAlpha(20),
            borderRadius: BorderRadius.circular(13),
          ),
          child: Icon(Icons.point_of_sale_rounded, color: color),
        ),
        title: Text(
          'فاتورة نقدية • ${money(item.invoice.total)} ${currencySymbol(item.invoice.currency)}',
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
        subtitle: Text(
          '${item.customerName} • رقم ${item.invoice.invoiceNumber}\n${dateOnly(item.invoice.date)}',
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
        isThreeLine: true,
        trailing: const Chip(
          avatar: Icon(Icons.payments_rounded, size: 17),
          label: Text('نقد'),
        ),
      ),
    );
  }
}

class _SimpleDropdown extends StatelessWidget {
  final String value;
  final List<DropdownMenuItem<String>> items;
  final ValueChanged<String> onChanged;

  const _SimpleDropdown({
    required this.value,
    required this.items,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      value: value,
      isExpanded: true,
      decoration: const InputDecoration(
        contentPadding: EdgeInsets.symmetric(horizontal: 13, vertical: 12),
      ),
      items: items,
      onChanged: (v) {
        if (v != null) onChanged(v);
      },
    );
  }
}

class _CurrencyFilter extends StatelessWidget {
  final String selected;
  final ValueChanged<String> onChanged;
  final bool includeAll;

  const _CurrencyFilter({
    required this.selected,
    required this.onChanged,
    this.includeAll = false,
  });

  @override
  Widget build(BuildContext context) {
    final values = [if (includeAll) 'ALL', 'YER', 'SAR', 'USD'];
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: values.map((value) {
          final active = value == selected;
          return Padding(
            padding: const EdgeInsets.only(left: 7),
            child: ChoiceChip(
              label: Text(value == 'ALL' ? 'الكل' : currencyName(value)),
              selected: active,
              onSelected: (_) => onChanged(value),
            ),
          );
        }).toList(),
      ),
    );
  }
}

class TransactionTile extends StatelessWidget {
  final EntryWithCustomer item;
  final bool compact;
  final VoidCallback? onDeleted;

  const TransactionTile({
    super.key,
    required this.item,
    this.compact = false,
    this.onDeleted,
  });

  @override
  Widget build(BuildContext context) {
    final positive = item.entry.type == EntryType.credit;
    final color = currencyColor(item.entry.currency);
    return Card(
      child: ListTile(
        contentPadding: EdgeInsets.symmetric(
          horizontal: compact ? 12 : 14,
          vertical: compact ? 3 : 6,
        ),
        leading: Container(
          width: 43,
          height: 43,
          decoration: BoxDecoration(
            color: (positive ? color : Colors.red).withAlpha(20),
            borderRadius: BorderRadius.circular(13),
          ),
          child: Icon(
            positive
                ? Icons.arrow_downward_rounded
                : Icons.arrow_upward_rounded,
            color: positive ? color : Colors.red.shade700,
          ),
        ),
        title: Text(
          '${positive ? 'له' : 'عليه'} • ${money(item.entry.amount)} ${currencySymbol(item.entry.currency)}',
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
        subtitle: Text(
          '${item.customerName} • ${item.entry.description.isEmpty ? 'بدون بيان' : item.entry.description}\n${dateOnly(item.entry.date)}',
          maxLines: compact ? 2 : 3,
          overflow: TextOverflow.ellipsis,
        ),
        isThreeLine: true,
        trailing: PopupMenuButton<String>(
          onSelected: (value) async {
            if (value == 'share') {
              await Share.share(_shareText());
            } else if (value == 'delete') {
              final ok = await _confirmDelete(context);
              if (ok) {
                await AppDatabase.instance.deleteEntry(item.entry.id!);
                onDeleted?.call();
              }
            }
          },
          itemBuilder: (_) => const [
            PopupMenuItem(
              value: 'share',
              child: Text('مشاركة العملية'),
            ),
            PopupMenuItem(
              value: 'delete',
              child: Text('حذف العملية'),
            ),
          ],
        ),
      ),
    );
  }

  String _shareText() {
    return 'حساباتي\n'
        'العميل: ${item.customerName}\n'
        'العملية: ${item.entry.type.label}\n'
        'المبلغ: ${money(item.entry.amount)} ${currencyName(item.entry.currency)}\n'
        'البيان: ${item.entry.description.isEmpty ? 'بدون بيان' : item.entry.description}\n'
        'التاريخ: ${item.entry.date}';
  }

  Future<bool> _confirmDelete(BuildContext context) async {
    return await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('حذف العملية'),
            content: const Text('هل تريد حذف هذه العملية نهائياً؟'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('إلغاء'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('حذف'),
              ),
            ],
          ),
        ) ??
        false;
  }
}

class InvoicesPage extends StatefulWidget {
  const InvoicesPage({super.key});

  @override
  State<InvoicesPage> createState() => _InvoicesPageState();
}

class _InvoicesPageState extends State<InvoicesPage> {
  String selectedCurrency = 'ALL';

  Future<List<Invoice>> _load() {
    return AppDatabase.instance.invoices(
      currency: selectedCurrency == 'ALL' ? null : selectedCurrency,
    );
  }

  Future<void> _openNewInvoice() async {
    final number = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (_) => const InvoicePage()),
    );
    if (!mounted) return;
    if (number != null) {
      setState(() {});
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تم حفظ الفاتورة $number بنجاح')),
      );
    }
  }

  Future<void> _showInvoice(Invoice invoice) async {
    final name = await AppDatabase.instance.customerNameById(invoice.customerId) ?? 'غير معروف';
    final items = await AppDatabase.instance.invoiceItems(invoice.id!);
    if (!mounted) return;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        'الفاتورة ${invoice.invoiceNumber}',
                        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                      ),
                    ),
                    Chip(
                      avatar: Icon(
                        invoice.paymentType == 'credit'
                            ? Icons.schedule_rounded
                            : Icons.payments_outlined,
                        size: 18,
                      ),
                      label: Text(invoice.paymentType == 'credit' ? 'آجل' : 'نقد'),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text('العميل: $name'),
                Text('التاريخ: ${dateOnly(invoice.date)}'),
                const SizedBox(height: 14),
                ...items.map(
                  (item) => Card(
                    margin: const EdgeInsets.only(bottom: 7),
                    child: ListTile(
                      title: Text(item.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                      subtitle: Text('${money(item.quantity)} × ${money(item.price)}'),
                      trailing: Text(
                        '${money(item.total)} ${currencySymbol(invoice.currency)}',
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: currencyColor(invoice.currency).withAlpha(16),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    children: [
                      const Expanded(
                        child: Text('الإجمالي', style: TextStyle(fontWeight: FontWeight.w900)),
                      ),
                      Text(
                        '${money(invoice.total)} ${currencySymbol(invoice.currency)}',
                        style: TextStyle(
                          color: currencyColor(invoice.currency),
                          fontSize: 19,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                ),
                if (invoice.note.trim().isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Text('ملاحظة: ${invoice.note}'),
                ],
                if (invoice.paymentType == 'credit')
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Text(
                      'هذه الفاتورة مسجلة على العميل كـ «عليه».',
                      style: TextStyle(color: Colors.orange.shade800, fontWeight: FontWeight.w800),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openNewInvoice,
        icon: const Icon(Icons.add_rounded),
        label: const Text('فاتورة جديدة'),
      ),
      body: FutureBuilder<List<Invoice>>(
        future: _load(),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) return _ErrorView(error: snap.error);
          final invoices = snap.data ?? <Invoice>[];
          return RefreshIndicator(
            onRefresh: () async => setState(() {}),
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
              children: [
                const _SectionTitle(
                  title: 'الفواتير',
                  subtitle: 'جميع الفواتير المحفوظة مع تفاصيل الأصناف والسداد',
                ),
                const SizedBox(height: 10),
                _CurrencyFilter(
                  selected: selectedCurrency,
                  onChanged: (v) => setState(() => selectedCurrency = v),
                  includeAll: true,
                ),
                const SizedBox(height: 12),
                if (invoices.isEmpty)
                  const _EmptyCard(
                    icon: Icons.receipt_long_outlined,
                    text: 'لا توجد فواتير محفوظة حتى الآن',
                  )
                else
                  ...invoices.map(
                    (invoice) => Padding(
                      padding: const EdgeInsets.only(bottom: 9),
                      child: FutureBuilder<String?>(
                        future: AppDatabase.instance.customerNameById(invoice.customerId),
                        builder: (context, customerSnap) {
                          final customer = customerSnap.data ?? '...';
                          final credit = invoice.paymentType == 'credit';
                          return Card(
                            child: ListTile(
                              onTap: () => _showInvoice(invoice),
                              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                              leading: CircleAvatar(
                                backgroundColor: currencyColor(invoice.currency).withAlpha(18),
                                child: Icon(Icons.receipt_long_rounded, color: currencyColor(invoice.currency)),
                              ),
                              title: Text(
                                invoice.invoiceNumber,
                                style: const TextStyle(fontWeight: FontWeight.w900),
                              ),
                              subtitle: Text('$customer • ${dateOnly(invoice.date)} • ${credit ? 'آجل' : 'نقد'}'),
                              trailing: Text(
                                '${money(invoice.total)}\n${currencySymbol(invoice.currency)}',
                                textAlign: TextAlign.end,
                                style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  color: currencyColor(invoice.currency),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class ReportsPage extends StatefulWidget {
  const ReportsPage({super.key});

  @override
  State<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends State<ReportsPage> {
  String selectedCurrency = 'YER';

  Future<_ReportData> _load() async {
    final currencies = await AppDatabase.instance.currencyTotals();
    final customers = await AppDatabase.instance.customerCurrencyReport(
      currency: selectedCurrency,
    );
    final entries = await AppDatabase.instance.allEntriesWithCustomers(
      currency: selectedCurrency,
    );
    return _ReportData(
      currencies: currencies,
      customers: customers,
      entries: entries,
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<_ReportData>(
      future: _load(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) return _ErrorView(error: snap.error);
        final data = snap.data!;
        CurrencyTotal? current;
        for (final item in data.currencies) {
          if (item.currency == selectedCurrency) {
            current = item;
            break;
          }
        }

        return RefreshIndicator(
          onRefresh: () async => setState(() {}),
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 6, 16, 100),
            children: [
              const _SectionTitle(
                title: 'التقارير المالية',
                subtitle: 'اختر العملة لعرض تقرير مستقل عنها',
              ),
              const SizedBox(height: 10),
              _CurrencyFilter(
                selected: selectedCurrency,
                onChanged: (v) {
                  if (v != 'ALL') setState(() => selectedCurrency = v);
                },
              ),
              const SizedBox(height: 12),
              if (current != null) CurrencyBalanceCard(item: current),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: _ReportStat(
                      title: 'له',
                      value: money(
                        data.entries
                            .where((e) => e.entry.type == EntryType.credit)
                            .fold(0.0, (s, e) => s + e.entry.amount),
                      ),
                      icon: Icons.arrow_downward_rounded,
                      color: Colors.green,
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: _ReportStat(
                      title: 'عليه',
                      value: money(
                        data.entries
                            .where((e) => e.entry.type == EntryType.debit)
                            .fold(0.0, (s, e) => s + e.entry.amount),
                      ),
                      icon: Icons.arrow_upward_rounded,
                      color: Colors.red,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              const _SectionTitle(
                title: 'أرصدة العملاء',
                subtitle: 'الرصيد لكل عميل بهذه العملة فقط',
              ),
              const SizedBox(height: 10),
              if (data.customers.isEmpty)
                const _EmptyCard(
                  icon: Icons.people_outline_rounded,
                  text: 'لا توجد بيانات لهذه العملة',
                )
              else
                ...data.customers.map(
                  (row) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Card(
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor:
                              currencyColor(selectedCurrency).withAlpha(20),
                          child: Text(
                            row.customerName.isEmpty
                                ? '?'
                                : row.customerName.characters.first,
                            style: TextStyle(
                              color: currencyColor(selectedCurrency),
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                        title: Text(
                          row.customerName,
                          style: const TextStyle(fontWeight: FontWeight.w800),
                        ),
                        subtitle: Text('${row.transactions} عملية'),
                        trailing: Text(
                          '${money(row.balance)} ${currencySymbol(selectedCurrency)}',
                          style: TextStyle(
                            fontWeight: FontWeight.w900,
                            color: row.balance >= 0
                                ? currencyColor(selectedCurrency)
                                : Colors.red.shade700,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              const SizedBox(height: 16),
              const _SectionTitle(
                title: 'آخر عمليات التقرير',
                subtitle: 'منفصلة حسب العملة المختارة',
              ),
              const SizedBox(height: 10),
              ...data.entries.take(15).map(
                    (e) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: TransactionTile(item: e, compact: true),
                    ),
                  ),
              if (data.entries.length > 15)
                Center(
                  child: Text(
                    'تم عرض أحدث 15 عملية',
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.primary,
                      fontSize: 12,
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _ReportData {
  final List<CurrencyTotal> currencies;
  final List<CustomerCurrencyReportRow> customers;
  final List<EntryWithCustomer> entries;

  _ReportData({
    required this.currencies,
    required this.customers,
    required this.entries,
  });
}

class _ReportStat extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final Color color;

  const _ReportStat({
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Row(
          children: [
            CircleAvatar(
              radius: 21,
              backgroundColor: color.withAlpha(20),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(color: Colors.black54)),
                  const SizedBox(height: 3),
                  Text(
                    value,
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      color: color,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final String subtitle;

  const _SectionTitle({
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                subtitle,
                style: const TextStyle(
                  fontSize: 11,
                  color: Colors.black54,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _EmptyCard extends StatelessWidget {
  final IconData icon;
  final String text;

  const _EmptyCard({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 18),
        child: Column(
          children: [
            Icon(icon, size: 42, color: Colors.black26),
            const SizedBox(height: 10),
            Text(
              text,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final Object? error;

  const _ErrorView({this.error});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Text(
          'حدث خطأ أثناء تحميل البيانات.\n${error ?? ''}',
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
