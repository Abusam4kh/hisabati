import 'dart:io';
import 'dart:ui' as ui;
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as path;
import 'package:package_info_plus/package_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:pdf/pdf.dart' as pdf;
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'package:printing/printing.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:android_intent_plus/android_intent.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:timezone/data/latest.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;

import 'database.dart';
import 'models.dart';

final appSettings = AppSettingsController();

Future<void> sendDirectSMS({required String phone, required String message}) async {
  if (Platform.isAndroid) {
    final intent = AndroidIntent(
      action: 'android.intent.action.SENDTO',
      data: 'smsto:$phone',
      arguments: <String, dynamic>{
        'sms_body': message,
      },
    );
    await intent.launch();
    return;
  }

  final smsUri = Uri(
    scheme: 'sms',
    path: phone,
    queryParameters: <String, String>{'body': message},
  );
  if (!await launchUrl(smsUri, mode: LaunchMode.externalApplication)) {
    throw Exception('تعذر فتح الرسائل');
  }
}


class AppNotificationService extends ChangeNotifier {
  static final AppNotificationService instance = AppNotificationService._();
  AppNotificationService._();

  final FlutterLocalNotificationsPlugin plugin = FlutterLocalNotificationsPlugin();
  SharedPreferences? _prefs;
  bool ready = false;

  Future<void> init() async {
    if (ready) return;
    _prefs = await SharedPreferences.getInstance();
    tz_data.initializeTimeZones();
    try { tz.setLocalLocation(tz.getLocation('Asia/Aden')); } catch (_) {}
    const android = AndroidInitializationSettings('@drawable/hasabati_logo');
    const settings = InitializationSettings(android: android);
    await plugin.initialize(settings, onDidReceiveNotificationResponse: (response) {
      // The notification screen is opened by the app when the user taps the bell.
    });
    final androidImpl = plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await androidImpl?.requestNotificationsPermission();
    ready = true;
    notifyListeners();
  }

  List<Map<String, String>> get history {
    final raw = _prefs?.getStringList('app_notifications') ?? const <String>[];
    return raw.map((e) {
      final parts = e.split('|||');
      return {'title': parts.isNotEmpty ? parts[0] : '', 'body': parts.length > 1 ? parts[1] : '', 'date': parts.length > 2 ? parts[2] : ''};
    }).toList();
  }

  int get unreadCount => _prefs?.getInt('notifications_unread') ?? 0;

  Future<void> addInApp(String title, String body) async {
    final items = history.take(49).map((e) => '${e['title']}|||${e['body']}|||${e['date']}').toList();
    items.insert(0, '$title|||$body|||${DateTime.now().toIso8601String()}');
    await _prefs?.setStringList('app_notifications', items);
    await _prefs?.setInt('notifications_unread', unreadCount + 1);
    notifyListeners();
  }

  Future<void> markAllRead() async {
    await _prefs?.setInt('notifications_unread', 0);
    notifyListeners();
  }

  Future<void> clearHistory() async {
    await _prefs?.remove('app_notifications');
    await _prefs?.setInt('notifications_unread', 0);
    notifyListeners();
  }

  int reminderNotificationId(int customerId, String currency) => '${customerId}_$currency'.hashCode.abs() % 2147483647;

  Future<void> scheduleDebtReminder({required DebtReminder reminder, required String customerName, required double debt}) async {
    await init();
    final date = DateTime.tryParse(reminder.reminderDate);
    if (date == null) return;
    final timeParts = reminder.reminderTime.split(':');
    final hour = int.tryParse(timeParts.isNotEmpty ? timeParts[0] : '') ?? 9;
    final minute = int.tryParse(timeParts.length > 1 ? timeParts[1] : '') ?? 0;
    // استخدم تاريخ ووقت الجهاز مباشرة. نحول فرق الوقت إلى المنطقة الزمنية
    // التي تعتمد عليها خدمة الإشعارات، حتى لا يتأثر التذكير بإعداد منطقة
    // زمنية ثابتة داخل التطبيق.
    final targetLocal = DateTime(date.year, date.month, date.day, hour, minute);
    final nowLocal = DateTime.now();
    if (!targetLocal.isAfter(nowLocal)) return;
    final delay = targetLocal.difference(nowLocal);
    final when = tz.TZDateTime.now(tz.local).add(delay);
    final id = reminderNotificationId(reminder.customerId, reminder.currency);
    await plugin.cancel(id);
    final androidImpl = plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    final exactAllowed = await androidImpl?.requestExactAlarmsPermission() ?? false;
    try {
      await plugin.zonedSchedule(
        id,
        'تذكير بالدين',
        'لدى $customerName مبلغ مستحق ${money(debt)} ${currencySymbol(reminder.currency)}',
        when,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'debt_reminders',
            'تذكيرات الديون',
            channelDescription: 'تنبيهات تذكير ديون العملاء',
            importance: Importance.high,
            priority: Priority.high,
          ),
        ),
        androidScheduleMode: exactAllowed ? AndroidScheduleMode.exactAllowWhileIdle : AndroidScheduleMode.inexactAllowWhileIdle,
      );
    } catch (_) {
      // If exact-alarm access was denied/revoked, retry with an inexact schedule
      // so the reminder still has a chance to arrive.
      await plugin.zonedSchedule(
        id,
        'تذكير بالدين',
        'لدى $customerName مبلغ مستحق ${money(debt)} ${currencySymbol(reminder.currency)}',
        when,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'debt_reminders',
            'تذكيرات الديون',
            channelDescription: 'تنبيهات تذكير ديون العملاء',
            importance: Importance.high,
            priority: Priority.high,
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      );
    }
    await addInApp('تذكير مجدول', 'سيتم تذكيرك بدين $customerName بتاريخ ${DateFormat('yyyy-MM-dd').format(date)} الساعة ${reminder.reminderTime}');
  }

  Future<void> cancelDebtReminder({required int customerId, required String currency}) async {
    await init();
    await plugin.cancel(reminderNotificationId(customerId, currency));
  }
}

final appNotifications = AppNotificationService.instance;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await appSettings.load();
  await appNotifications.init();
  runApp(const HasabatiApp());
}

class AppSettingsController extends ChangeNotifier {
  static const _businessNameKey = 'business_name';
  static const _businessPhoneKey = 'business_phone';
  static const _businessAddressKey = 'business_address';
  static const _defaultCurrencyKey = 'default_currency';
  static const _invoicePrefixKey = 'invoice_prefix';
  static const _darkModeKey = 'dark_mode';
  static const _businessLogoPathKey = 'business_logo_path';

  String businessName = 'حساباتي';
  String businessPhone = '';
  String businessAddress = '';
  String defaultCurrency = 'YER';
  String invoicePrefix = 'INV-';
  bool darkMode = false;
  String businessLogoPath = '';
  SharedPreferences? _prefs;

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    businessName = _prefs!.getString(_businessNameKey) ?? 'حساباتي';
    businessPhone = _prefs!.getString(_businessPhoneKey) ?? '';
    businessAddress = _prefs!.getString(_businessAddressKey) ?? '';
    defaultCurrency = _prefs!.getString(_defaultCurrencyKey) ?? 'YER';
    invoicePrefix = _prefs!.getString(_invoicePrefixKey) ?? 'INV-';
    darkMode = _prefs!.getBool(_darkModeKey) ?? false;
    businessLogoPath = _prefs!.getString(_businessLogoPathKey) ?? '';
  }

  Future<void> saveProfile({required String name, required String phone, required String address}) async {
    businessName = name.trim().isEmpty ? 'حساباتي' : name.trim();
    businessPhone = phone.trim();
    businessAddress = address.trim();
    await _prefs!.setString(_businessNameKey, businessName);
    await _prefs!.setString(_businessPhoneKey, businessPhone);
    await _prefs!.setString(_businessAddressKey, businessAddress);
    notifyListeners();
  }


  Future<void> setBusinessLogo(String filePath) async {
    final source = File(filePath);
    if (!await source.exists()) return;
    final dir = await getApplicationSupportDirectory();
    final ext = path.extension(filePath).isEmpty ? '.png' : path.extension(filePath);
    final target = File(path.join(dir.path, 'business_logo$ext'));
    if (businessLogoPath.isNotEmpty && businessLogoPath != target.path) {
      try {
        final old = File(businessLogoPath);
        if (await old.exists()) await old.delete();
      } catch (_) {}
    }
    await source.copy(target.path);
    businessLogoPath = target.path;
    await _prefs!.setString(_businessLogoPathKey, businessLogoPath);
    notifyListeners();
  }

  Future<void> removeBusinessLogo() async {
    if (businessLogoPath.isNotEmpty) {
      try {
        final file = File(businessLogoPath);
        if (await file.exists()) await file.delete();
      } catch (_) {}
    }
    businessLogoPath = '';
    await _prefs!.remove(_businessLogoPathKey);
    notifyListeners();
  }

  Future<void> setDefaultCurrency(String value) async {
    defaultCurrency = value;
    await _prefs!.setString(_defaultCurrencyKey, value);
    notifyListeners();
  }

  Future<void> setInvoicePrefix(String value) async {
    invoicePrefix = value.trim().isEmpty ? 'INV-' : value.trim();
    await _prefs!.setString(_invoicePrefixKey, invoicePrefix);
    notifyListeners();
  }

  Future<void> setDarkMode(bool value) async {
    darkMode = value;
    await _prefs!.setBool(_darkModeKey, value);
    notifyListeners();
  }
}

class HasabatiApp extends StatelessWidget {
  const HasabatiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: appSettings,
      builder: (context, _) {
        const seed = Color(0xFF0D6EFD);
        final isDark = appSettings.darkMode;
        final scheme = ColorScheme.fromSeed(
          seedColor: seed,
          brightness: isDark ? Brightness.dark : Brightness.light,
        );
        final pageBackground = isDark ? const Color(0xFF0B1220) : const Color(0xFFF4F7FB);
        final cardBackground = isDark ? const Color(0xFF151E2E) : Colors.white;
        final borderColor = isDark ? const Color(0xFF263348) : const Color(0xFFE3E9F2);
        return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'حساباتي',
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      builder: (context, child) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: child ?? const SizedBox.shrink(),
      ),
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: scheme,
        scaffoldBackgroundColor: pageBackground,
        fontFamily: null,
        appBarTheme: AppBarTheme(
          centerTitle: true,
          scrolledUnderElevation: 0,
          elevation: 0,
          backgroundColor: pageBackground,
          surfaceTintColor: Colors.transparent,
          foregroundColor: scheme.onSurface,
        ),
        cardTheme: CardThemeData(
          elevation: 0,
          margin: EdgeInsets.zero,
          surfaceTintColor: Colors.transparent,
          color: cardBackground,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
            side: BorderSide(color: borderColor),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: cardBackground,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: borderColor),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: scheme.primary, width: 1.6),
          ),
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 15,
          ),
        ),
        navigationBarTheme: NavigationBarThemeData(
          height: 72,
          elevation: 0,
          backgroundColor: cardBackground,
          indicatorColor: scheme.primaryContainer,
        ),
        floatingActionButtonTheme: FloatingActionButtonThemeData(
          backgroundColor: scheme.primary,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
        ),
      ),
          home: const HomePage(),
        );
      },
    );
  }
}

String money(double value) =>
    NumberFormat('#,##0.##', 'en_US').format(value);

String nowText() => DateFormat('yyyy-MM-dd HH:mm').format(DateTime.now());

String dateOnly(String value) {
  final parsed = DateTime.tryParse(value.replaceFirst(' ', 'T'));
  if (parsed == null) return value;
  const days = ['الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت', 'الأحد'];
  final day = days[parsed.weekday - 1];
  final date = DateFormat('yyyy-MM-dd').format(parsed);
  final time = DateFormat('HH:mm').format(parsed);
  return '$day • $date • $time';
}

String currencyName(String code) {
  switch (code) {
    case 'SAR':
      return 'ريال سعودي';
    case 'USD':
      return 'دولار أمريكي';
    default:
      return 'ريال يمني';
  }
}

String currencySymbol(String code) {
  switch (code) {
    case 'SAR':
      return 'ر.س';
    case 'USD':
      return '\$';
    default:
      return 'ر.ي';
  }
}

Color currencyColor(String code) {
  switch (code) {
    case 'SAR':
      return const Color(0xFF138A5B);
    case 'USD':
      return const Color(0xFF7B57C2);
    default:
      return const Color(0xFF0D6EFD);
  }
}



class BusinessInfoCard extends StatelessWidget {
  final bool compact;
  final bool bordered;

  const BusinessInfoCard({super.key, this.compact = false, this.bordered = true});

  @override
  Widget build(BuildContext context) {
    final hasLogo = appSettings.businessLogoPath.isNotEmpty && File(appSettings.businessLogoPath).existsSync();
    final name = appSettings.businessName.trim().isEmpty ? 'حساباتي' : appSettings.businessName.trim();
    final phone = appSettings.businessPhone.trim();
    final address = appSettings.businessAddress.trim();
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(compact ? 12 : 16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(compact ? 16 : 20),
        border: bordered ? Border.all(color: Theme.of(context).colorScheme.outlineVariant) : null,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          if (hasLogo)
            ClipRRect(
              borderRadius: BorderRadius.circular(compact ? 12 : 15),
              child: Image.file(File(appSettings.businessLogoPath), width: compact ? 54 : 64, height: compact ? 54 : 64, fit: BoxFit.cover),
            )
          else
            Container(
              width: compact ? 54 : 64,
              height: compact ? 54 : 64,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary.withAlpha(18),
                borderRadius: BorderRadius.circular(compact ? 12 : 15),
              ),
              child: FaIcon(FontAwesomeIcons.store, size: compact ? 28 : 32, color: Theme.of(context).colorScheme.primary),
            ),
          const SizedBox(width: 12),
          Expanded(
            child: Directionality(
              textDirection: ui.TextDirection.rtl,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name, style: TextStyle(fontSize: compact ? 16 : 19, fontWeight: FontWeight.w900)),
                  if (address.isNotEmpty) ...[
                    const SizedBox(height: 3),
                    Text(address, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: compact ? 11 : 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
                  ],
                  if (phone.isNotEmpty) ...[
                    const SizedBox(height: 2),
                    Text(phone, style: TextStyle(fontSize: compact ? 11 : 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

Future<Uint8List?> _businessLogoBytes() async {
  try {
    if (appSettings.businessLogoPath.isNotEmpty) {
      final file = File(appSettings.businessLogoPath);
      if (await file.exists()) return await file.readAsBytes();
    }
  } catch (_) {}
  try {
    final data = await rootBundle.load('assets/hasabati_logo.png');
    return data.buffer.asUint8List();
  } catch (_) {
    return null;
  }
}

const _pdfPageWidth = 794.0;
const _pdfPageHeight = 1123.0;
const _pdfBlue = Color(0xFF5068A0);
const _pdfInk = Color(0xFF20242B);
const _pdfMuted = Color(0xFF6B7280);
const _pdfLine = Color(0xFFE5E7EB);
const _pdfSoft = Color(0xFFF5F7FB);

TextStyle _pdfText({double size = 12, FontWeight weight = FontWeight.w500, Color color = _pdfInk}) =>
    TextStyle(fontFamily: 'NotoKufiArabic', fontSize: size, fontWeight: weight, color: color, height: 1.35);

class _PdfReportPage extends StatelessWidget {
  final Widget child;
  const _PdfReportPage({required this.child});
  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: Material(
          color: Colors.white,
          child: SizedBox(
            width: _pdfPageWidth,
            height: _pdfPageHeight,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(42, 38, 42, 34),
              child: child,
            ),
          ),
        ),
      );
}

class _PdfBusinessHeader extends StatelessWidget {
  final Uint8List? logoBytes;
  final String title;
  const _PdfBusinessHeader({required this.logoBytes, required this.title});
  @override
  Widget build(BuildContext context) {
    final name = appSettings.businessName.trim().isEmpty ? 'حساباتي' : appSettings.businessName.trim();
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 16),
      decoration: BoxDecoration(color: Colors.white, border: Border.all(color: _pdfLine), borderRadius: BorderRadius.circular(16)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              if (logoBytes != null)
                Container(
                  width: 82,
                  height: 82,
                  decoration: BoxDecoration(color: _pdfSoft, borderRadius: BorderRadius.circular(14)),
                  padding: const EdgeInsets.all(5),
                  child: Image.memory(
                    logoBytes!,
                    fit: BoxFit.contain,
                    gaplessPlayback: true,
                    errorBuilder: (_, __, ___) => Image.asset('assets/hasabati_logo.png', fit: BoxFit.contain),
                  ),
                )
              else
                Container(
                  width: 82,
                  height: 82,
                  decoration: BoxDecoration(color: _pdfSoft, borderRadius: BorderRadius.circular(14)),
                  padding: const EdgeInsets.all(5),
                  child: Image.asset('assets/hasabati_logo.png', fit: BoxFit.contain),
                ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(name, style: _pdfText(size: 22, weight: FontWeight.w900)),
                    if (appSettings.businessAddress.trim().isNotEmpty) ...[
                      const SizedBox(height: 5),
                      Text(appSettings.businessAddress.trim(), style: _pdfText(size: 11, color: _pdfMuted)),
                    ],
                    if (appSettings.businessPhone.trim().isNotEmpty) ...[
                      const SizedBox(height: 3),
                      Text(appSettings.businessPhone.trim(), style: _pdfText(size: 11, color: _pdfMuted)),
                    ],
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(color: _pdfSoft, borderRadius: BorderRadius.circular(9)),
            child: Text(title, textAlign: TextAlign.right, style: _pdfText(size: 12, weight: FontWeight.w800, color: _pdfBlue)),
          ),
        ],
      ),
    );
  }
}

Widget _pdfSectionTitle(String title) => Padding(
      padding: const EdgeInsets.only(top: 18, bottom: 8),
      child: Text(title, style: _pdfText(size: 15, weight: FontWeight.w900)),
    );

Widget _pdfInfoCard(List<Widget> children) => Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: _pdfSoft, border: Border.all(color: _pdfLine), borderRadius: BorderRadius.circular(12)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children),
    );

Widget _pdfInfoLine(String label, String value, {bool bold = false}) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: RichText(
        text: TextSpan(children: [
          TextSpan(text: '$label: ', style: _pdfText(size: 10, color: _pdfMuted)),
          TextSpan(text: value, style: _pdfText(size: 11, weight: bold ? FontWeight.w900 : FontWeight.w600)),
        ]),
      ),
    );

Widget _pdfTable({
  required List<String> headers,
  required List<List<String>> rows,
  List<int>? flexes,
  List<Color?>? rowColors,
}) {
  final f = flexes ?? List<int>.filled(headers.length, 1);
  Widget row(List<String> values, {bool header = false, Color? rowColor}) => Container(
        decoration: BoxDecoration(
          color: header ? _pdfBlue : Colors.white,
          border: Border(bottom: BorderSide(color: header ? _pdfBlue : _pdfLine)),
        ),
        padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 8),
        child: Row(
          children: List.generate(
            values.length,
            (i) => Expanded(
              flex: f[i],
              child: Text(
                values[i],
                textAlign: TextAlign.right,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: _pdfText(
                  size: header ? 9.5 : 9,
                  weight: header ? FontWeight.w900 : FontWeight.w700,
                  color: header ? Colors.white : (rowColor ?? _pdfInk),
                ),
              ),
            ),
          ),
        ),
      );
  return Container(
    clipBehavior: Clip.antiAlias,
    decoration: BoxDecoration(border: Border.all(color: _pdfLine), borderRadius: BorderRadius.circular(10)),
    child: Column(
      children: [
        row(headers, header: true),
        ...List.generate(rows.length, (i) => row(rows[i], rowColor: rowColors != null && i < rowColors.length ? rowColors[i] : null)),
      ],
    ),
  );
}

Widget _pdfTotalsCard({required Map<String, List<double>> totals}) {
  if (totals.isEmpty) {
    return _pdfInfoCard([Text('لا توجد مبالغ لحساب الإجمالي.', style: _pdfText(size: 10, color: _pdfMuted))]);
  }

  final rows = <Widget>[];
  for (final item in totals.entries) {
    final currency = item.key;
    final values = item.value;
    final credit = values.isNotEmpty ? values[0] : 0.0;
    final debit = values.length > 1 ? values[1] : 0.0;
    final net = credit - debit;
    final netColor = net > 0 ? const Color(0xFF2563EB) : net < 0 ? const Color(0xFFD04444) : _pdfMuted;
    rows.add(
      Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(color: Colors.white, border: Border.all(color: _pdfLine), borderRadius: BorderRadius.circular(10)),
        child: Row(
          children: [
            Expanded(flex: 2, child: Text(currencyName(currency), style: _pdfText(size: 10, weight: FontWeight.w900))),
            Expanded(child: Text('له: ${money(credit)} ${currencySymbol(currency)}', textAlign: TextAlign.right, style: _pdfText(size: 9.5, weight: FontWeight.w900, color: const Color(0xFF2563EB)))),
            Expanded(child: Text('عليه: ${money(debit)} ${currencySymbol(currency)}', textAlign: TextAlign.right, style: _pdfText(size: 9.5, weight: FontWeight.w900, color: const Color(0xFFD04444)))),
            Expanded(child: Text('الناتج: ${money(net)} ${currencySymbol(currency)}', textAlign: TextAlign.right, style: _pdfText(size: 9.5, weight: FontWeight.w900, color: netColor))),
          ],
        ),
      ),
    );
  }

  return Container(
    width: double.infinity,
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: _pdfSoft, border: Border.all(color: _pdfLine), borderRadius: BorderRadius.circular(12)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Text('الإجمالي', style: _pdfText(size: 14, weight: FontWeight.w900)),
      const SizedBox(height: 8),
      ...rows,
    ]),
  );
}

List<List<T>> _pdfChunks<T>(List<T> items, int size) {
  if (items.isEmpty) return <List<T>>[];
  final result = <List<T>>[];
  for (var i = 0; i < items.length; i += size) {
    result.add(items.sublist(i, i + size > items.length ? items.length : i + size));
  }
  return result;
}

Future<void> _precachePdfBusinessLogo(BuildContext context, Uint8List? logoBytes) async {
  if (logoBytes == null || !context.mounted) return;
  try {
    await precacheImage(MemoryImage(logoBytes), context);
  } catch (_) {
    // If the image cannot be cached, the PDF page will use its fallback logo.
  }
}

Future<List<Uint8List>> _capturePdfPages(BuildContext context, List<Widget> pages) async {
  final overlay = Overlay.of(context, rootOverlay: true);
  final images = <Uint8List>[];
  for (final page in pages) {
    final key = GlobalKey();
    late OverlayEntry entry;
    entry = OverlayEntry(
      builder: (_) => Positioned(
        left: -10000,
        top: 0,
        child: IgnorePointer(child: RepaintBoundary(key: key, child: page)),
      ),
    );
    overlay.insert(entry);
    try {
      // Images such as the business logo are decoded asynchronously.
      // Wait for a few frames so the first captured PDF page cannot be rendered
      // before the logo finishes decoding (which previously caused the logo to
      // appear only from the second page onward).
      await WidgetsBinding.instance.endOfFrame;
      await WidgetsBinding.instance.endOfFrame;
      await WidgetsBinding.instance.endOfFrame;
      final boundary = key.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null) throw Exception('تعذر تجهيز صفحة التقرير');
      final image = await boundary.toImage(pixelRatio: 2.0);
      final data = await image.toByteData(format: ui.ImageByteFormat.png);
      image.dispose();
      if (data == null) throw Exception('تعذر تحويل صفحة التقرير إلى صورة');
      images.add(data.buffer.asUint8List());
    } finally {
      entry.remove();
    }
  }
  return images;
}

Future<Uint8List> _imagesToPdf(List<Uint8List> images) async {
  final doc = pw.Document();
  for (final bytes in images) {
    final image = pw.MemoryImage(bytes);
    doc.addPage(pw.Page(
      pageFormat: pdf.PdfPageFormat.a4,
      margin: pw.EdgeInsets.zero,
      build: (_) => pw.Center(child: pw.Image(image, fit: pw.BoxFit.contain)),
    ));
  }
  return doc.save();
}


Future<void> showEntryResultDialog(
  BuildContext context, {
  required Entry entry,
  required String customerName,
  String customerPhone = '',
  String title = 'تم حفظ العملية',
}) async {
  final resolvedPhone = customerPhone.isNotEmpty ? customerPhone : ((await AppDatabase.instance.customerById(entry.customerId))?.phone ?? '');
  await showDialog<void>(
    context: context,
    builder: (_) => _OperationPreviewDialog(
      title: title,
      fileName: 'hasabati_operation_${entry.id ?? DateTime.now().millisecondsSinceEpoch}.png',
      content: _EntryShareCard(entry: entry, customerName: customerName),
      customerPhone: resolvedPhone,
      message: 'تم تسجيل عملية جديدة\nالعميل: $customerName\nالمبلغ: ${money(entry.amount)} ${currencySymbol(entry.currency)}\n${entry.type == EntryType.debit ? 'المبلغ المستحق عليكم' : 'المبلغ المسجل لكم'}',
    ),
  );
}

Future<void> showInvoiceResultDialog(
  BuildContext context, {
  required Invoice invoice,
  required String customerName,
  String customerPhone = '',
  String title = 'تم حفظ الفاتورة',
}) async {
  final resolvedPhone = customerPhone.isNotEmpty ? customerPhone : ((await AppDatabase.instance.customerById(invoice.customerId))?.phone ?? '');
  final invoiceItems = await AppDatabase.instance.invoiceItems(invoice.id!);
  await showDialog<void>(
    context: context,
    builder: (_) => _OperationPreviewDialog(
      title: title,
      fileName: 'hasabati_invoice_${invoice.invoiceNumber}.png',
      content: _InvoiceShareCard(invoice: invoice, customerName: customerName),
      customerPhone: resolvedPhone,
      message: 'فاتورة ${invoice.invoiceNumber}\nالعميل: $customerName\nالإجمالي: ${money(invoice.total)} ${currencySymbol(invoice.currency)}\n${invoice.note.trim()}',
      pdfFileName: 'فاتورة_${invoice.invoiceNumber}.pdf',
      pdfBuilder: (dialogContext) => _buildInvoicePdfForShare(
        dialogContext,
        invoice: invoice,
        customerName: customerName,
        items: invoiceItems,
      ),
    ),
  );
}

Future<Uint8List> _buildInvoicePdfForShare(
  BuildContext context, {
  required Invoice invoice,
  required String customerName,
  required List<InvoiceItem> items,
}) async {
  final logo = await _businessLogoBytes();
  await _precachePdfBusinessLogo(context, logo);
  final chunks = _pdfChunks(items, 8);
  final pages = <Widget>[];
  if (chunks.isEmpty) {
    pages.add(_InvoicePrintPage(
      invoice: invoice,
      customerName: customerName,
      items: const [],
      logo: logo,
      firstPage: true,
      lastPage: true,
    ));
  } else {
    for (var i = 0; i < chunks.length; i++) {
      pages.add(_InvoicePrintPage(
        invoice: invoice,
        customerName: customerName,
        items: chunks[i],
        logo: logo,
        firstPage: i == 0,
        lastPage: i == chunks.length - 1,
      ));
    }
  }
  final images = await _capturePdfPages(context, pages);
  return _imagesToPdf(images);
}


final Set<int> _activePrintContexts = <int>{};

Future<T?> _runWithPrintWaiting<T>(BuildContext context, Future<T> Function() action) async {
  final key = identityHashCode(context);
  if (_activePrintContexts.contains(key)) return null;
  _activePrintContexts.add(key);
  var dialogShown = false;
  try {
    final future = showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const _PrintWaitingDialog(),
    );
    dialogShown = true;
    // Give the waiting dialog one frame to render before the PDF work starts.
    await Future<void>.delayed(const Duration(milliseconds: 120));
    final result = await action();
    if (dialogShown && context.mounted) {
      Navigator.of(context, rootNavigator: true).pop();
    }
    await future;
    return result;
  } catch (_) {
    if (dialogShown && context.mounted) {
      Navigator.of(context, rootNavigator: true).maybePop();
    }
    rethrow;
  } finally {
    _activePrintContexts.remove(key);
  }
}

class _PrintWaitingDialog extends StatelessWidget {
  const _PrintWaitingDialog();

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 30),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 76,
              height: 76,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  const SizedBox(
                    width: 70,
                    height: 70,
                    child: CircularProgressIndicator(strokeWidth: 4),
                  ),
                  FaIcon(FontAwesomeIcons.print, size: 34, color: Theme.of(context).colorScheme.primary),
                ],
              ),
            ),
            const SizedBox(height: 18),
            Text(
              'جاري تجهيز الطباعة',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 7),
            Text(
              'يرجى الانتظار وعدم الضغط مرة أخرى',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13, color: Theme.of(context).colorScheme.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }
}

class _OperationPreviewDialog extends StatefulWidget {
  final String title;
  final String fileName;
  final Widget content;
  final String customerPhone;
  final String message;
  final String? pdfFileName;
  final Future<Uint8List> Function(BuildContext context)? pdfBuilder;
  const _OperationPreviewDialog({
    required this.title,
    required this.fileName,
    required this.content,
    required this.customerPhone,
    required this.message,
    this.pdfFileName,
    this.pdfBuilder,
  });
  @override
  State<_OperationPreviewDialog> createState() => _OperationPreviewDialogState();
}

class _OperationPreviewDialogState extends State<_OperationPreviewDialog> {
  final _captureKey = GlobalKey();
  String mode = 'none';
  bool busy = false;

  String _normalizePhone(String phone) {
    var value = phone.replaceAll(RegExp(r'[^0-9+]'), '');
    if (value.startsWith('+')) return value.substring(1);
    if (value.startsWith('00967')) return value.substring(2);
    if (value.startsWith('967')) return value;
    if (value.startsWith('0')) return '967${value.substring(1)}';
    if (value.startsWith('7') && value.length >= 9) return '967$value';
    return value;
  }

  Future<Uint8List> _captureImage() async {
    await WidgetsBinding.instance.endOfFrame;
    final boundary = _captureKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
    if (boundary == null) throw Exception('تعذر التقاط المعاينة');
    final image = await boundary.toImage(pixelRatio: 3.0);
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    if (data == null) throw Exception('تعذر إنشاء الصورة');
    return data.buffer.asUint8List();
  }

  Future<void> _send() async {
    if (busy) return;
    setState(() => busy = true);
    try {
      final phone = _normalizePhone(widget.customerPhone);
      if (mode == 'none') {
        if (mounted) Navigator.pop(context);
        return;
      }
      if (mode == 'image') {
        final bytes = await _captureImage();
        await Share.shareXFiles([XFile.fromData(bytes, name: widget.fileName, mimeType: 'image/png')], text: widget.message);
      } else if (mode == 'pdf') {
        final builder = widget.pdfBuilder;
        if (builder == null) throw Exception('تعذر تجهيز ملف الفاتورة');
        final bytes = await builder(context);
        final name = widget.pdfFileName ?? 'document.pdf';
        await Share.shareXFiles([XFile.fromData(bytes, name: name, mimeType: 'application/pdf')]);
      } else if (mode == 'text') {
        if (phone.isEmpty) throw Exception('لا يوجد رقم هاتف لهذا العميل');
        await sendDirectSMS(phone: phone, message: widget.message);
      } else if (mode == 'whatsapp') {
        if (phone.isEmpty) throw Exception('لا يوجد رقم هاتف لهذا العميل');
        final bytes = await _captureImage();
        // Share the generated card with the caption; WhatsApp/Business can be selected from the Android share sheet.
        await Share.shareXFiles([XFile.fromData(bytes, name: widget.fileName, mimeType: 'image/png')], text: widget.message);
      }
      if (mounted && mode != 'image') Navigator.pop(context);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر الإرسال: $e')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final options = <(String, String, IconData)>[
      ('none', 'لا ترسل', FontAwesomeIcons.ban),
      if (widget.pdfBuilder != null)
        ('pdf', 'PDF', FontAwesomeIcons.filePdf)
      else
        ('image', 'صورة', FontAwesomeIcons.image),
      ('text', 'رسالة نصية', FontAwesomeIcons.commentSms),
      ('whatsapp', 'واتساب', FontAwesomeIcons.whatsapp),
    ];
    return Dialog(
      insetPadding: const EdgeInsets.all(16),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Row(children: [Expanded(child: Text(widget.title, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800))), IconButton(onPressed: () => Navigator.pop(context), icon: const FaIcon(FontAwesomeIcons.xmark))]),
          const SizedBox(height: 6),
          Flexible(child: SingleChildScrollView(child: RepaintBoundary(key: _captureKey, child: widget.content))),
          const SizedBox(height: 12),
          Align(alignment: Alignment.centerRight, child: Text('إرسال إشعار فوري عبر', style: TextStyle(fontWeight: FontWeight.w900, color: Theme.of(context).colorScheme.onSurface))),
          const SizedBox(height: 7),
          ...options.map((o) => RadioListTile<String>(dense: true, contentPadding: EdgeInsets.zero, value: o.$1, groupValue: mode, onChanged: busy ? null : (v) => setState(() => mode = v!), title: Text(o.$2), secondary: Icon(o.$3))),
          const SizedBox(height: 5),
          Row(children: [
            if (mode != 'none') ...[
              Expanded(child: OutlinedButton.icon(onPressed: busy ? null : () => Navigator.pop(context), icon: const FaIcon(FontAwesomeIcons.check), label: Text('تم'))),
              const SizedBox(width: 8),
            ],
            Expanded(child: FilledButton.icon(
              onPressed: busy ? null : _send,
              icon: Icon(
                mode == 'none' || mode == 'pdf' || mode == 'image' ? (mode == 'none' ? FontAwesomeIcons.check : FontAwesomeIcons.shareNodes) : FontAwesomeIcons.paperPlane,
              ),
              label: Text(
                busy ? 'جارٍ...' : mode == 'none' ? 'تم' : (mode == 'image' || mode == 'pdf') ? 'مشاركة' : 'إرسال',
              ),
            )),
          ]),
        ]),
      ),
    );
  }
}

class _ShareCardShell extends StatelessWidget {
  final String title;
  final List<Widget> children;
  const _ShareCardShell({required this.title, required this.children});
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Container(
        width: 390,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFFE2E8F0)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          BusinessInfoCard(compact: true, bordered: false),
          const SizedBox(height: 10),
          Text(title, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          const Divider(height: 28),
          ...children,
          const SizedBox(height: 14),
          Center(child: Text('حساباتي • دفتر حساباتك', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 11))),
        ]),
      ),
    );
  }
}

class _EntryShareCard extends StatelessWidget {
  final Entry entry;
  final String customerName;
  const _EntryShareCard({required this.entry, required this.customerName});
  @override
  Widget build(BuildContext context) => _ShareCardShell(
    title: 'تفاصيل العملية',
    children: [
      _ShareLine('العميل', customerName),
      _ShareLine('النوع', entry.type == EntryType.credit ? 'له' : 'عليه'),
      _ShareLine('المبلغ', '${money(entry.amount)} ${currencySymbol(entry.currency)}'),
      _ShareLine('البيان', entry.description.isEmpty ? 'بدون بيان' : entry.description),
      _ShareLine('التاريخ', dateOnly(entry.date)),
    ],
  );
}

class _InvoiceShareCard extends StatelessWidget {
  final Invoice invoice;
  final String customerName;
  const _InvoiceShareCard({required this.invoice, required this.customerName});
  @override
  Widget build(BuildContext context) => _ShareCardShell(
    title: 'الفاتورة ${invoice.invoiceNumber}',
    children: [
      _ShareLine('العميل', customerName),
      _ShareLine('الدفع', invoice.paymentType == 'credit' ? 'آجل' : 'نقد'),
      _ShareLine('الإجمالي', '${money(invoice.total)} ${currencySymbol(invoice.currency)}'),
      _ShareLine('التاريخ', dateOnly(invoice.date)),
      if (invoice.note.trim().isNotEmpty) _ShareLine('ملاحظة', invoice.note),
    ],
  );
}

class _ShareLine extends StatelessWidget {
  final String label;
  final String value;
  const _ShareLine(this.label, this.value);
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 6),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SizedBox(width: 82, child: Text(label, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 12))),
      Expanded(child: Text(value, style: TextStyle(fontWeight: FontWeight.w800))),
    ]),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;

  @override
  void initState() {
    super.initState();
    AppDatabase.instance.ensureCashCustomer();
  }

  void refresh() => setState(() {});

  Future<void> _createLocalBackupAndExit() async {
    try {
      final root = await getApplicationSupportDirectory();
      final dir = Directory('${root.path}/backups');
      await dir.create(recursive: true);
      final file = File('${dir.path}/hasabati_backup_${DateFormat('yyyyMMdd_HHmmss').format(DateTime.now())}.db');
      await AppDatabase.instance.createBackup(file.path);
      await Future<void>.delayed(const Duration(milliseconds: 120));
      SystemNavigator.pop();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر إنشاء النسخة الاحتياطية: $e')));
      }
    }
  }

  Future<void> _handleBack() async {
    if (index != 0) {
      setState(() => index = 0);
      return;
    }
    final choice = await showDialog<String>(
      context: context,
      barrierDismissible: true,
      builder: (dialogContext) => AlertDialog(
        title: Text('الخروج من التطبيق', style: TextStyle(fontWeight: FontWeight.w900)),
        content: Text('هل تريد الخروج من حساباتي؟ يمكنك إنشاء نسخة احتياطية قبل الخروج.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(dialogContext).pop('cancel'), child: Text('إلغاء')),
          OutlinedButton.icon(onPressed: () => Navigator.of(dialogContext).pop('backup'), icon: const FaIcon(FontAwesomeIcons.database), label: Text('نسخة احتياطية')),
          FilledButton.icon(onPressed: () => Navigator.of(dialogContext).pop('exit'), icon: const FaIcon(FontAwesomeIcons.rightFromBracket), label: Text('خروج')),
        ],
      ),
    );
    if (!mounted) return;
    if (choice == 'backup') {
      await _createLocalBackupAndExit();
    } else if (choice == 'exit') {
      SystemNavigator.pop();
    }
  }

  void _selectPage(int value) {
    Navigator.of(context).pop();
    if (mounted) setState(() => index = value);
  }

  Future<void> _openAbout() async {
    Navigator.of(context).pop();
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const AboutAppPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardPage(
        onNavigate: (value) => setState(() => index = value),
        onNewInvoice: () async {
          final savedInvoice = await Navigator.push<Invoice>(
            context,
            MaterialPageRoute(builder: (_) => const InvoicePage()),
          );
          if (mounted && savedInvoice != null) {
            setState(() {});
            final customer = await AppDatabase.instance.customerNameById(savedInvoice.customerId) ?? 'غير معروف';
            if (mounted) await showInvoiceResultDialog(context, invoice: savedInvoice, customerName: customer);
          }
        },
      ),
      CustomersPage(onChanged: refresh),
      const TransactionsPage(),
      const InvoicesPage(),
    ];

    return PopScope<void>(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) _handleBack();
      },
      child: Scaffold(
      drawer: Drawer(
        child: SafeArea(
          child: Column(
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF0D6EFD), Color(0xFF0755C8)],
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                  ),
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(26),
                    bottomRight: Radius.circular(26),
                  ),
                ),
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: Image.asset(
                        'assets/hasabati_logo.png',
                        width: 68,
                        height: 68,
                        fit: BoxFit.cover,
                      ),
                    ),
                    const SizedBox(width: 10),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'حساباتي',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            'دفتر حساباتك',
                            style: TextStyle(color: Colors.white70),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              _DrawerItem(
                icon: FontAwesomeIcons.gaugeHigh,
                title: 'الرئيسية',
                selected: index == 0,
                onTap: () => _selectPage(0),
              ),
              _DrawerItem(
                icon: FontAwesomeIcons.users,
                title: 'العملاء',
                selected: index == 1,
                onTap: () => _selectPage(1),
              ),
              _DrawerItem(
                icon: FontAwesomeIcons.moneyBillTransfer,
                title: 'العمليات',
                selected: index == 2,
                onTap: () => _selectPage(2),
              ),
              _DrawerItem(
                icon: FontAwesomeIcons.receipt,
                title: 'الفواتير',
                selected: index == 3,
                onTap: () => _selectPage(3),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                child: Divider(),
              ),
              _DrawerItem(
                icon: FontAwesomeIcons.bell,
                title: 'تنبيهات الديون',
                onTap: () {
                  Navigator.of(context).pop();
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const DebtAlertsPage()));
                },
              ),
              _DrawerItem(
                icon: FontAwesomeIcons.gear,
                title: 'الإعدادات',
                onTap: () {
                  Navigator.of(context).pop();
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsPage()));
                },
              ),
              _DrawerItem(
                icon: FontAwesomeIcons.circleInfo,
                title: 'حول التطبيق',
                onTap: _openAbout,
              ),
              _DrawerItem(
                icon: FontAwesomeIcons.shieldHalved,
                title: 'سياسة الخصوصية',
                onTap: () {
                  Navigator.of(context).pop();
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const PrivacyPolicyPage()));
                },
              ),
              _DrawerItem(
                icon: FontAwesomeIcons.chartLine,
                title: 'التقارير وكشف الحساب',
                onTap: () {
                  Navigator.of(context).pop();
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const ReportsPage()));
                },
              ),
              _DrawerItem(
                icon: FontAwesomeIcons.database,
                title: 'النسخ الاحتياطي',
                onTap: () {
                  Navigator.of(context).pop();
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const BackupPage()));
                },
              ),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.all(18),
                child: Text(
                  'حساباتي • يعمل بدون إنترنت',
                  style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 11),
                ),
              ),
            ],
          ),
        ),
      ),
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.asset(
                'assets/hasabati_logo.png',
                width: 34,
                height: 34,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(width: 8),
            Text(
              'حساباتي',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
            ),
          ],
        ),
        actions: [
          AnimatedBuilder(
            animation: appNotifications,
            builder: (context, _) => Stack(
              clipBehavior: Clip.none,
              children: [
                IconButton(
                  tooltip: 'الإشعارات',
                  onPressed: () async {
                    await Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsPage()));
                    if (mounted) setState(() {});
                  },
                  icon: const FaIcon(FontAwesomeIcons.bell),
                ),
                if (appNotifications.unreadCount > 0)
                  Positioned(
                    right: 7,
                    top: 5,
                    child: Container(
                      constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      decoration: BoxDecoration(color: Colors.red.shade600, shape: BoxShape.circle),
                      alignment: Alignment.center,
                      child: Text('${appNotifications.unreadCount > 9 ? '9+' : appNotifications.unreadCount}', style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w900)),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
      body: IndexedStack(index: index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(
            icon: FaIcon(FontAwesomeIcons.gaugeHigh),
            selectedIcon: FaIcon(FontAwesomeIcons.gaugeHigh),
            label: 'الرئيسية',
          ),
          NavigationDestination(
            icon: FaIcon(FontAwesomeIcons.users),
            selectedIcon: FaIcon(FontAwesomeIcons.users),
            label: 'العملاء',
          ),
          NavigationDestination(
            icon: FaIcon(FontAwesomeIcons.receipt),
            selectedIcon: FaIcon(FontAwesomeIcons.receipt),
            label: 'العمليات',
          ),
          NavigationDestination(
            icon: FaIcon(FontAwesomeIcons.receipt),
            selectedIcon: FaIcon(FontAwesomeIcons.receipt),
            label: 'الفواتير',
          ),
        ],
      ),
      // وضع الـ FAB داخل حاوية ثابتة العرض يضمن أن زر الإغلاق
      // وجميع أزرار الإضافة تكون على نفس المحور الأفقي في RTL/LTR.
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: _QuickActionsFab(
        onTransaction: () async {
          final saved = await showDialog<Entry>(
            context: context,
            builder: (_) => const QuickEntryDialog(),
          );
          if (saved != null && mounted) {
            setState(() {});
            final customerObj = await AppDatabase.instance.customerById(saved.customerId);
            final customer = customerObj?.name ?? 'غير معروف';
            if (mounted) await showEntryResultDialog(context, entry: saved, customerName: customer, customerPhone: customerObj?.phone ?? '');
          }
        },
        onInvoice: () async {
          final saved = await Navigator.push<Invoice>(
            context,
            MaterialPageRoute(builder: (_) => const InvoicePage()),
          );
          if (mounted && saved != null) {
            setState(() {});
            final customer = await AppDatabase.instance.customerNameById(saved.customerId) ?? 'غير معروف';
            if (mounted) await showInvoiceResultDialog(context, invoice: saved, customerName: customer);
          }
        },
        onCustomer: () async {
          final saved = await showDialog<bool>(
            context: context,
            builder: (_) => const CustomerDialog(),
          );
          if (saved == true && mounted) refresh();
        },
      ),
    ),
    );
  }
}

class _QuickActionsFab extends StatefulWidget {
  final Future<void> Function() onTransaction;
  final Future<void> Function() onInvoice;
  final Future<void> Function() onCustomer;

  const _QuickActionsFab({
    required this.onTransaction,
    required this.onInvoice,
    required this.onCustomer,
  });

  @override
  State<_QuickActionsFab> createState() => _QuickActionsFabState();
}

class _QuickActionsFabState extends State<_QuickActionsFab>
    with SingleTickerProviderStateMixin {
  bool expanded = false;
  late final AnimationController _controller;
  late final Animation<double> _menuAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 260),
    );
    _menuAnimation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutBack,
      reverseCurve: Curves.easeIn,
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _run(Future<void> Function() action) async {
    await _controller.reverse();
    if (!mounted) return;
    setState(() => expanded = false);
    await action();
  }

  void _toggle() {
    setState(() => expanded = !expanded);
    if (expanded) {
      _controller.forward();
    } else {
      _controller.reverse();
    }
  }

  Widget _animatedAction({
    required int index,
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
  }) {
    final beginOffset = Offset(0, 0.35 + (index * 0.08));
    final animation = CurvedAnimation(
      parent: _controller,
      curve: Interval(
        index * 0.08,
        0.72 + index * 0.08,
        curve: Curves.easeOutBack,
      ),
    );

    return AnimatedBuilder(
      animation: animation,
      builder: (context, child) {
        final value = animation.value;
        return Opacity(
          opacity: value.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(
              beginOffset.dx * (1 - value),
              beginOffset.dy * (1 - value) * 42,
            ),
            child: Transform.scale(
              scale: 0.82 + (0.18 * value),
              child: IgnorePointer(
                ignoring: value < 0.95,
                child: child,
              ),
            ),
          ),
        );
      },
      child: _QuickActionButton(
        icon: icon,
        label: label,
        onPressed: onPressed,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // جميع عناصر القائمة تأخذ نفس العرض، والـ Column نفسه في المنتصف.
    // هذا يمنع انحراف أزرار الـ FAB عن زر X خصوصاً مع Directionality.rtl.
    final screenWidth = MediaQuery.sizeOf(context).width;
    final menuWidth = (screenWidth * 0.36).clamp(120.0, 510.0);

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (expanded)
          SizedBox(
            width: menuWidth,
            child: AnimatedBuilder(
              animation: _menuAnimation,
              builder: (context, child) {
                return SizeTransition(
                  sizeFactor: _menuAnimation,
                  axisAlignment: 1,
                  child: child,
                );
              },
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _animatedAction(
                    index: 0,
                    icon: FontAwesomeIcons.userPlus,
                    label: 'إضافة عميل',
                    onPressed: () => _run(widget.onCustomer),
                  ),
                  const SizedBox(height: 7),
                  _animatedAction(
                    index: 1,
                    icon: FontAwesomeIcons.creditCard,
                    label: 'إضافة عملية',
                    onPressed: () => _run(widget.onTransaction),
                  ),
                  const SizedBox(height: 7),
                  _animatedAction(
                    index: 2,
                    icon: FontAwesomeIcons.receipt,
                    label: 'إضافة فاتورة',
                    onPressed: () => _run(widget.onInvoice),
                  ),
                  const SizedBox(height: 8),
                ],
              ),
            ),
          ),
        Center(
          child: FloatingActionButton(
            heroTag: 'global_add_fab',
            onPressed: _toggle,
            child: AnimatedRotation(
              turns: expanded ? 0.125 : 0,
              duration: const Duration(milliseconds: 220),
              curve: Curves.easeOut,
              child: const FaIcon(FontAwesomeIcons.plus, size: 30),
            ),
          ),
        ),
      ],
    );
  }
}

class _QuickActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onPressed;

  const _QuickActionButton({
    required this.icon,
    required this.label,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 7,
      color: Theme.of(context).colorScheme.primary,
      borderRadius: BorderRadius.circular(24),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onPressed,
        child: SizedBox(
          width: double.infinity,
          height: 58,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              FaIcon(icon, size: 25, color: Colors.white),
              const SizedBox(width: 10),
              Text(
                label,
                textDirection: ui.TextDirection.rtl,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 15,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class DashboardPage extends StatefulWidget {
  final ValueChanged<int> onNavigate;
  final VoidCallback onNewInvoice;

  const DashboardPage({
    super.key,
    required this.onNavigate,
    required this.onNewInvoice,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  bool _balancesHidden = false;

  Future<_DashboardData> _load() async {
    final customers = await AppDatabase.instance.customers();
    final totals = await AppDatabase.instance.currencyTotals();
    final balances = await AppDatabase.instance.currencyBalancesSplit();
    final entries = await AppDatabase.instance.allEntriesWithCustomers(limit: 20);
    final allEntries = await AppDatabase.instance.allEntriesWithCustomers();
    final cashInvoices = await AppDatabase.instance.cashInvoicesWithCustomers();

    // Today's balances are based on the device's local date.
    // Credit invoices already create a debit ledger entry when saved, so only
    // cash invoices need to be added here separately to avoid double counting.
    final todayKey = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final todayBalancesMap = <String, CurrencyBalanceSplit>{};
    for (final entry in allEntries) {
      if (!entry.entry.date.startsWith(todayKey)) continue;
      final old = todayBalancesMap[entry.entry.currency];
      final credit = (old?.credit ?? 0) +
          (entry.entry.type == EntryType.credit ? entry.entry.amount : 0);
      final debit = (old?.debit ?? 0) +
          (entry.entry.type == EntryType.debit ? entry.entry.amount : 0);
      todayBalancesMap[entry.entry.currency] = CurrencyBalanceSplit(
        currency: entry.entry.currency,
        credit: credit,
        debit: debit,
      );
    }
    for (final item in cashInvoices) {
      if (!item.invoice.date.startsWith(todayKey)) continue;
      final old = todayBalancesMap[item.invoice.currency];
      todayBalancesMap[item.invoice.currency] = CurrencyBalanceSplit(
        currency: item.invoice.currency,
        credit: (old?.credit ?? 0) + item.invoice.total,
        debit: old?.debit ?? 0,
      );
    }
    final todayBalances = todayBalancesMap.values.toList();
    final recent = <_DashboardRecentItem>[
      ...entries.map((e) => _DashboardRecentItem.entry(e)),
      ...cashInvoices.map((i) => _DashboardRecentItem.invoice(i)),
    ];
    recent.sort((a, b) => b.date.compareTo(a.date));
    return _DashboardData(
      customers: customers,
      totals: totals,
      balances: balances,
      todayBalances: todayBalances,
      entries: entries,
      recent: recent.take(8).toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async => setState(() {}),
      child: FutureBuilder<_DashboardData>(
        future: _load(),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return _ErrorView(error: snap.error);
          }
          final data = snap.data!;
          return ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
            children: [
              _DashboardBalanceHeader(
                hidden: _balancesHidden,
                onToggle: () => setState(() => _balancesHidden = !_balancesHidden),
              ),
              const SizedBox(height: 8),
              _SplitBalanceSection(balances: data.balances, hidden: _balancesHidden),
              const SizedBox(height: 12),
              _TodayBalancesSection(balances: data.todayBalances, hidden: _balancesHidden),
              const SizedBox(height: 12),
              const _DebtAlertsSummaryCard(),
              const SizedBox(height: 16),
              const SizedBox(height: 22),
              const _SectionTitle(
                title: 'آخر العمليات',
                subtitle: 'أحدث الحركات المسجلة',
              ),
              const SizedBox(height: 8),
              if (data.entries.isEmpty)
                const _EmptyCard(
                  icon: FontAwesomeIcons.receipt,
                  text: 'لا توجد عمليات مسجلة',
                )
              else
                ...data.recent.map(
                  (item) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: item.entry != null
                        ? TransactionTile(item: item.entry!, compact: true)
                        : CashInvoiceOperationTile(item: item.invoice!),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class _DashboardRecentItem {
  final EntryWithCustomer? entry;
  final InvoiceWithCustomer? invoice;
  final String date;
  const _DashboardRecentItem._({this.entry, this.invoice, required this.date});
  factory _DashboardRecentItem.entry(EntryWithCustomer value) => _DashboardRecentItem._(entry: value, date: value.entry.date);
  factory _DashboardRecentItem.invoice(InvoiceWithCustomer value) => _DashboardRecentItem._(invoice: value, date: value.invoice.date);
}

class _DashboardData {
  final List<Customer> customers;
  final List<CurrencyTotal> totals;
  final List<CurrencyBalanceSplit> balances;
  final List<CurrencyBalanceSplit> todayBalances;
  final List<EntryWithCustomer> entries;
  final List<_DashboardRecentItem> recent;

  _DashboardData({
    required this.customers,
    required this.totals,
    required this.balances,
    required this.todayBalances,
    required this.entries,
    required this.recent,
  });
}

class _DashboardBalanceHeader extends StatelessWidget {
  final bool hidden;
  final VoidCallback onToggle;

  const _DashboardBalanceHeader({required this.hidden, required this.onToggle});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(top: 4),
      child: Row(
        children: [
          Text(
            'الأرصدة',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: scheme.onSurface),
          ),
          const Spacer(),
          IconButton(
            tooltip: hidden ? 'إظهار الأرصدة' : 'إخفاء الأرصدة',
            onPressed: onToggle,
            visualDensity: VisualDensity.compact,
            icon: FaIcon(
              hidden ? FontAwesomeIcons.eyeSlash : FontAwesomeIcons.eye,
              size: 20,
              color: scheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}

class _SplitBalanceSection extends StatelessWidget {
  final List<CurrencyBalanceSplit> balances;
  final bool hidden;

  const _SplitBalanceSection({required this.balances, required this.hidden});

  Widget _box(
    BuildContext context,
    String title,
    bool positive,
    List<CurrencyBalanceSplit> items,
  ) {
    final color = positive
        ? const Color(0xFF168A63)
        : const Color(0xFFD04444);
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  FaIcon(
                    positive
                        ? FontAwesomeIcons.arrowDown
                        : FontAwesomeIcons.arrowUp,
                    color: color,
                    size: 19,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    title,
                    style: TextStyle(
                      color: color,
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              if (items.isEmpty)
                Text(
                  'لا يوجد',
                  style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 12),
                )
              else
                ...items.map(
                  (item) => Padding(
                    padding: const EdgeInsets.only(bottom: 7),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            currencyName(item.currency),
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        Text(
                          hidden ? '***' : money(positive ? item.credit : item.debit),
                          style: TextStyle(
                            color: color,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          currencySymbol(item.currency),
                          style: TextStyle(
                            fontSize: 10,
                            color: Theme.of(context).colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _box(context, 'لك', true, balances.where((e) => e.credit > 0).toList()),
        const SizedBox(width: 10),
        _box(context, 'عليك', false, balances.where((e) => e.debit > 0).toList()),
      ],
    );
  }
}

class _TodayBalancesSection extends StatelessWidget {
  final List<CurrencyBalanceSplit> balances;
  final bool hidden;
  const _TodayBalancesSection({required this.balances, required this.hidden});

  Widget _box(
    BuildContext context,
    String title,
    bool positive,
    List<CurrencyBalanceSplit> items,
  ) {
    final color = positive
        ? const Color(0xFF168A63)
        : const Color(0xFFD04444);

    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(13),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  FaIcon(
                    positive ? FontAwesomeIcons.arrowDown : FontAwesomeIcons.arrowUp,
                    color: color,
                    size: 15,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    title,
                    style: TextStyle(
                      color: color,
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 7),
              if (items.isEmpty)
                Text(
                  'لا يوجد',
                  style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 11),
                )
              else
                ...items.map(
                  (item) => Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            currencyName(item.currency),
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        Text(
                          hidden ? '***' : money(positive ? item.credit : item.debit),
                          style: TextStyle(
                            color: color,
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ordered = [...balances]
      ..sort((a, b) {
        const order = {'YER': 0, 'SAR': 1, 'USD': 2};
        final ai = order[a.currency] ?? 99;
        final bi = order[b.currency] ?? 99;
        if (ai != bi) return ai.compareTo(bi);
        return a.currency.compareTo(b.currency);
      });

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'أرصدة اليوم',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Theme.of(context).colorScheme.onSurface),
        ),
        const SizedBox(height: 3),
        Text(
          '${_arabicWeekday(DateTime.now().weekday)} • ${DateFormat('dd-MM-yyyy').format(DateTime.now())}',
          style: TextStyle(fontSize: 11, color: Theme.of(context).colorScheme.onSurfaceVariant),
        ),
        const SizedBox(height: 9),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _box(
              context,
              'لك اليوم',
              true,
              ordered.where((e) => e.credit > 0).toList(),
            ),
            const SizedBox(width: 10),
            _box(
              context,
              'عليك اليوم',
              false,
              ordered.where((e) => e.debit > 0).toList(),
            ),
          ],
        ),
      ],
    );
  }
}

String _arabicWeekday(int weekday) {
  const days = [
    'الاثنين',
    'الثلاثاء',
    'الأربعاء',
    'الخميس',
    'الجمعة',
    'السبت',
    'الأحد',
  ];
  return days[weekday - 1];
}

class _WelcomeCard extends StatelessWidget {
  final int customerCount;
  final VoidCallback onAdd;
  final VoidCallback onAddTransaction;

  const _WelcomeCard({
    required this.customerCount,
    required this.onAdd,
    required this.onAddTransaction,
  });

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF0756C9), Color(0xFF1D86F8)],
          begin: Alignment.bottomRight,
          end: Alignment.topLeft,
        ),
        borderRadius: BorderRadius.circular(26),
        boxShadow: const [
          BoxShadow(
            color: Color(0x220D6EFD),
            blurRadius: 20,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'مرحباً بك 👋',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 7),
                Text(
                  'لديك $customerCount عميل${customerCount == 1 ? '' : 'اً'} في دفتر الحسابات',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 13,
                  ),
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    FilledButton.icon(
                      onPressed: onAdd,
                      style: FilledButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: primary,
                        padding: const EdgeInsets.symmetric(horizontal: 13),
                      ),
                      icon: const FaIcon(FontAwesomeIcons.userPlus, size: 19),
                      label: Text('إضافة عميل'),
                    ),
                    OutlinedButton.icon(
                      onPressed: onAddTransaction,
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.white,
                        side: const BorderSide(color: Colors.white70),
                        padding: const EdgeInsets.symmetric(horizontal: 13),
                      ),
                      icon: const FaIcon(FontAwesomeIcons.creditCard, size: 19),
                      label: Text('إضافة عملية'),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Image.asset(
              'assets/hasabati_logo.png',
              width: 82,
              height: 82,
              fit: BoxFit.cover,
            ),
          ),
        ],
      ),
    );
  }
}

class CurrencyBalanceCard extends StatelessWidget {
  final CurrencyTotal item;

  const CurrencyBalanceCard({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    final color = currencyColor(item.currency);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(17),
        child: Row(
          children: [
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: color.withAlpha(22),
                borderRadius: BorderRadius.circular(16),
              ),
              child: FaIcon(FontAwesomeIcons.wallet, color: color),
            ),
            const SizedBox(width: 13),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    currencyName(item.currency),
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${item.transactions} عملية • ${item.customers} عميل',
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  money(item.balance),
                  style: TextStyle(
                    color: item.balance >= 0 ? color : Colors.red.shade700,
                    fontSize: 17,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                Text(
                  currencySymbol(item.currency),
                  style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 11),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              FaIcon(icon, color: Theme.of(context).colorScheme.primary),
              const SizedBox(height: 12),
              Text(title, style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: TextStyle(fontSize: 11, color: Theme.of(context).colorScheme.onSurfaceVariant),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CustomersPage extends StatefulWidget {
  final VoidCallback? onChanged;

  const CustomersPage({super.key, this.onChanged});

  @override
  State<CustomersPage> createState() => _CustomersPageState();
}

class _CustomersPageState extends State<CustomersPage> {
  String search = '';

  Future<List<Customer>> _load() =>
      AppDatabase.instance.customers(query: search);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
          child: TextField(
            textInputAction: TextInputAction.search,
            decoration: const InputDecoration(
              hintText: 'ابحث باسم العميل أو رقم الهاتف',
              prefixIcon: FaIcon(FontAwesomeIcons.magnifyingGlass),
            ),
            onChanged: (value) => setState(() => search = value),
          ),
        ),
        Expanded(
          child: FutureBuilder<List<Customer>>(
            future: _load(),
            builder: (context, snap) {
              if (snap.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snap.hasError) return _ErrorView(error: snap.error);
              final customers = snap.data!;
              if (customers.isEmpty) {
                return const _EmptyCard(
                  icon: FontAwesomeIcons.users,
                  text: 'لا يوجد عملاء. أضف أول عميل من زر +',
                );
              }
              return RefreshIndicator(
                onRefresh: () async => setState(() {}),
                child: ListView.separated(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 100),
                  itemCount: customers.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 7),
                  itemBuilder: (_, index) {
                    final customer = customers[index];
                    return CustomerTile(
                      customer: customer,
                      onTap: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => CustomerPage(customer: customer),
                          ),
                        );
                        setState(() {});
                        widget.onChanged?.call();
                      },
                    );
                  },
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class CustomerTile extends StatelessWidget {
  final Customer customer;
  final VoidCallback onTap;

  const CustomerTile({
    super.key,
    required this.customer,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<CustomerCurrencyBalance>>(
      future: AppDatabase.instance.customerCurrencyBalances(customer.id!),
      builder: (context, snap) {
        final balances = snap.data ?? [];
        return Card(
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(20),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 25,
                    backgroundColor:
                        Theme.of(context).colorScheme.primaryContainer,
                    child: Text(
                      customer.name.isEmpty
                          ? '?'
                          : customer.name.characters.first,
                      style: TextStyle(
                        fontWeight: FontWeight.w900,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                    ),
                  ),
                  const SizedBox(width: 13),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          customer.name,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        if (customer.phone.isNotEmpty) ...[
                          const SizedBox(height: 3),
                          Text(
                            customer.phone,
                            style: TextStyle(
                              fontSize: 11,
                              color: Theme.of(context).colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                        if (balances.isNotEmpty) ...[
                          const SizedBox(height: 7),
                          Wrap(
                            spacing: 6,
                            runSpacing: 5,
                            children: balances
                                .map(
                                  (b) => _BalanceChip(
                                    currency: b.currency,
                                    value: b.balance,
                                  ),
                                )
                                .toList(),
                          ),
                        ],
                      ],
                    ),
                  ),
                  FaIcon(FontAwesomeIcons.chevronLeft, color: Theme.of(context).colorScheme.onSurfaceVariant),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _BalanceChip extends StatelessWidget {
  final String currency;
  final double value;

  const _BalanceChip({required this.currency, required this.value});

  @override
  Widget build(BuildContext context) {
    final color = currencyColor(currency);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
        color: color.withAlpha(18),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        '${money(value)} ${currencySymbol(currency)}',
        style: TextStyle(
          color: value >= 0 ? color : Colors.red.shade700,
          fontSize: 11,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class CustomerSearchDelegate extends SearchDelegate<String?> {
  CustomerSearchDelegate()
      : super(searchFieldLabel: 'اسم العميل أو الهاتف');

  @override
  List<Widget>? buildActions(BuildContext context) => [
        if (query.isNotEmpty)
          IconButton(
            onPressed: () => query = '',
            icon: const FaIcon(FontAwesomeIcons.xmark),
          ),
      ];

  @override
  Widget? buildLeading(BuildContext context) => IconButton(
        onPressed: () => close(context, null),
        icon: const FaIcon(FontAwesomeIcons.arrowLeft),
      );

  @override
  Widget buildResults(BuildContext context) => _result();

  @override
  Widget buildSuggestions(BuildContext context) => _result();

  Widget _result() {
    return FutureBuilder<List<Customer>>(
      future: AppDatabase.instance.customers(query: query),
      builder: (context, snap) {
        final data = snap.data ?? [];
        return ListView(
          children: data
              .map(
                (c) => ListTile(
                  leading: CircleAvatar(child: Text(c.name.characters.first)),
                  title: Text(c.name),
                  subtitle: Text(c.phone),
                  onTap: () => close(context, c.name),
                ),
              )
              .toList(),
        );
      },
    );
  }
}

class CustomerPage extends StatefulWidget {
  final Customer customer;

  const CustomerPage({super.key, required this.customer});

  @override
  State<CustomerPage> createState() => _CustomerPageState();
}

class _CustomerPageState extends State<CustomerPage> {
  String currencyFilter = 'ALL';

  Future<List<Entry>> _load() =>
      AppDatabase.instance.entriesForCustomer(
        widget.customer.id!,
        currency: currencyFilter == 'ALL' ? null : currencyFilter,
      );

  Future<void> _edit() async {
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => CustomerDialog(customer: widget.customer),
    );
    if (saved == true) setState(() {});
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('حذف العميل'),
        content: Text(
          'سيتم حذف العميل وجميع عملياته المالية. هل تريد المتابعة؟',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text('حذف'),
          ),
        ],
      ),
    );
    if (ok == true) {
      await AppDatabase.instance.deleteCustomer(widget.customer.id!);
      if (mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.customer.name,
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
        actions: [
          IconButton(
            tooltip: 'طباعة تقرير العميل',
            onPressed: () => printCustomerReport(context, widget.customer),
            icon: const FaIcon(FontAwesomeIcons.print),
          ),
          IconButton(
            tooltip: 'تعديل',
            onPressed: _edit,
            icon: const FaIcon(FontAwesomeIcons.penToSquare),
          ),
          IconButton(
            tooltip: 'حذف',
            onPressed: _delete,
            icon: const FaIcon(FontAwesomeIcons.trashCan),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final saved = await showDialog<Entry>(
            context: context,
            builder: (_) => EntryDialog(customerId: widget.customer.id!),
          );
          if (saved != null && mounted) {
            setState(() {});
            await showEntryResultDialog(context, entry: saved, customerName: widget.customer.name, customerPhone: widget.customer.phone);
          }
        },
        icon: const FaIcon(FontAwesomeIcons.plus),
        label: Text('إضافة عملية'),
      ),
      body: FutureBuilder<List<CustomerCurrencyBalance>>(
        future: AppDatabase.instance.customerCurrencyBalances(
          widget.customer.id!,
        ),
        builder: (context, balanceSnap) {
          final balances = balanceSnap.data ?? [];
          return FutureBuilder<List<Entry>>(
            future: _load(),
            builder: (context, snap) {
              if (snap.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snap.hasError) return _ErrorView(error: snap.error);
              final entries = snap.data!;
              return ListView(
                padding: const EdgeInsets.fromLTRB(16, 6, 16, 105),
                children: [
                  _CustomerHeader(customer: widget.customer),
                  const SizedBox(height: 12),
                  if (balances.isNotEmpty) ...[
                    const _SectionTitle(
                      title: 'أرصدة العميل',
                      subtitle: 'كل عملة في رصيد مستقل',
                    ),
                    const SizedBox(height: 9),
                    Wrap(
                      spacing: 9,
                      runSpacing: 9,
                      children: balances
                          .map(
                            (b) => SizedBox(
                              width: (MediaQuery.sizeOf(context).width - 41) / 2,
                              child: _MiniBalanceCard(item: b),
                            ),
                          )
                          .toList(),
                    ),
                    const SizedBox(height: 18),
                  ],
                  const _SectionTitle(
                    title: 'سجل العمليات',
                    subtitle: 'يمكنك تصفية السجل حسب العملة',
                  ),
                  const SizedBox(height: 9),
                  _CurrencyFilter(
                    selected: currencyFilter,
                    onChanged: (v) => setState(() => currencyFilter = v),
                  ),
                  const SizedBox(height: 8),
                  if (entries.isEmpty)
                    const _EmptyCard(
                      icon: FontAwesomeIcons.receipt,
                      text: 'لا توجد عمليات بهذه العملة',
                    )
                  else
                    ...entries.map(
                      (e) => Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: TransactionTile(
                          item: EntryWithCustomer.fromEntry(
                            e,
                            widget.customer.name,
                          ),
                          onDeleted: () => setState(() {}),
                          onChanged: () => setState(() {}),
                        ),
                      ),
                    ),
                ],
              );
            },
          );
        },
      ),
    );
  }
}

class _CustomerHeader extends StatelessWidget {
  final Customer customer;

  const _CustomerHeader({required this.customer});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(17),
        child: Row(
          children: [
            CircleAvatar(
              radius: 30,
              backgroundColor: Theme.of(context).colorScheme.primaryContainer,
              child: Text(
                customer.name.isEmpty ? '?' : customer.name.characters.first,
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  color: Theme.of(context).colorScheme.primary,
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    customer.name,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  if (customer.phone.isNotEmpty)
                    Text(
                      customer.phone,
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                        fontSize: 12,
                      ),
                    ),
                  if (customer.address.isNotEmpty)
                    Text(
                      customer.address,
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                        fontSize: 12,
                      ),
                    ),
                  if (customer.note.isNotEmpty)
                    Text(
                      customer.note,
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                        fontSize: 12,
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MiniBalanceCard extends StatelessWidget {
  final CustomerCurrencyBalance item;

  const _MiniBalanceCard({required this.item});

  @override
  Widget build(BuildContext context) {
    final color = currencyColor(item.currency);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                FaIcon(FontAwesomeIcons.moneyBill, color: color, size: 20),
                const SizedBox(width: 7),
                Expanded(
                  child: Text(
                    currencyName(item.currency),
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              money(item.balance),
              style: TextStyle(
                color: item.balance >= 0 ? color : Colors.red.shade700,
                fontSize: 17,
                fontWeight: FontWeight.w900,
              ),
            ),
            Text(
              '${item.transactions} عملية',
              style: TextStyle(fontSize: 10, color: Theme.of(context).colorScheme.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }
}


class QuickEntryDialog extends StatefulWidget {
  const QuickEntryDialog({super.key});

  @override
  State<QuickEntryDialog> createState() => _QuickEntryDialogState();
}

class _QuickEntryDialogState extends State<QuickEntryDialog> {
  final form = GlobalKey<FormState>();
  final amount = TextEditingController();
  final description = TextEditingController();
  EntryType type = EntryType.credit;
  String currency = 'YER';
  int? customerId;
  List<Customer> customers = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    currency = appSettings.defaultCurrency;
    _loadCustomers();
  }

  Future<void> _loadCustomers() async {
    final data = await AppDatabase.instance.customers();
    if (!mounted) return;
    setState(() {
      customers = data;
      customerId = data.isEmpty ? null : data.first.id;
      loading = false;
    });
  }

  @override
  void dispose() {
    amount.dispose();
    description.dispose();
    super.dispose();
  }

  String? get _selectedCustomerName {
    for (final customer in customers) {
      if (customer.id == customerId) return customer.name;
    }
    return null;
  }

  Future<void> _pickCustomer() async {
    final selected = await showDialog<Customer>(
      context: context,
      builder: (_) => const CustomerPickerDialog(),
    );
    if (selected != null && mounted) {
      setState(() => customerId = selected.id);
    }
  }

  Future<void> _addCustomer() async {
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => const CustomerDialog(),
    );
    if (saved == true) await _loadCustomers();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(
        'إضافة عملية جديدة',
        style: TextStyle(fontWeight: FontWeight.w800),
      ),
      content: SizedBox(
        width: 430,
        child: loading
            ? const SizedBox(
                height: 120,
                child: Center(child: CircularProgressIndicator()),
              )
            : Form(
                key: form,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (customers.isEmpty)
                        Card(
                          color: Theme.of(context).colorScheme.primaryContainer,
                          child: ListTile(
                            leading: const FaIcon(FontAwesomeIcons.userPlus),
                            title: Text('لا يوجد عملاء'),
                            subtitle: Text('أضف عميلاً أولاً لتسجيل العملية'),
                            trailing: TextButton(
                              onPressed: _addCustomer,
                              child: Text('إضافة'),
                            ),
                          ),
                        )
                      else
                        Row(
                          children: [
                            Expanded(
                              child: InkWell(
                                borderRadius: BorderRadius.circular(16),
                                onTap: _pickCustomer,
                                child: InputDecorator(
                                  decoration: const InputDecoration(
                                    labelText: 'العميل',
                                    prefixIcon: FaIcon(FontAwesomeIcons.user),
                                    suffixIcon: FaIcon(FontAwesomeIcons.chevronDown),
                                  ),
                                  child: Text(
                                    _selectedCustomerName ?? 'اختر العميل',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      color: _selectedCustomerName == null
                                          ? Theme.of(context).colorScheme.onSurfaceVariant
                                          : Theme.of(context).colorScheme.onSurface,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            IconButton(
                              tooltip: 'إضافة عميل',
                              onPressed: _addCustomer,
                              icon: const FaIcon(FontAwesomeIcons.userPlus),
                            ),
                          ],
                        ),
                      const SizedBox(height: 12),
                      _EntryTypeSelector(
                        value: type,
                        onChanged: (v) => setState(() => type = v),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: amount,
                        autofocus: customers.isNotEmpty,
                        keyboardType: const TextInputType.numberWithOptions(
                          decimal: true,
                        ),
                        decoration: const InputDecoration(
                          labelText: 'المبلغ',
                          prefixIcon: FaIcon(FontAwesomeIcons.moneyBill),
                        ),
                        validator: (v) {
                          final n = double.tryParse(v?.trim() ?? '');
                          return n == null || n <= 0 ? 'أدخل مبلغاً صحيحاً' : null;
                        },
                      ),
                      const SizedBox(height: 8),
                      DropdownButtonFormField<String>(
                        value: currency,
                        decoration: const InputDecoration(
                          labelText: 'العملة',
                          prefixIcon: FaIcon(FontAwesomeIcons.moneyBillTransfer),
                        ),
                        items: const [
                          DropdownMenuItem(value: 'YER', child: Text('ريال يمني YER')),
                          DropdownMenuItem(value: 'SAR', child: Text('ريال سعودي SAR')),
                          DropdownMenuItem(value: 'USD', child: Text('دولار أمريكي USD')),
                        ],
                        onChanged: (v) {
                          if (v != null) setState(() => currency = v);
                        },
                      ),
                      const SizedBox(height: 8),
                      TextFormField(
                        controller: description,
                        maxLines: 2,
                        decoration: const InputDecoration(
                          labelText: 'البيان / الملاحظة',
                          prefixIcon: FaIcon(FontAwesomeIcons.noteSticky),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
      ),
      actions: [
        TextButton(
          onPressed: () { Navigator.of(context).pop(); },
          child: Text('إلغاء'),
        ),
        FilledButton.icon(
          style: FilledButton.styleFrom(
            backgroundColor: type == EntryType.credit
                ? const Color(0xFF2563EB)
                : const Color(0xFFD04444),
            foregroundColor: Colors.white,
          ),
          onPressed: customers.isEmpty ? null : _save,
          icon: const FaIcon(FontAwesomeIcons.check),
          label: Text('حفظ العملية'),
        ),
      ],
    );
  }

  Future<void> _save() async {
    if (!form.currentState!.validate() || customerId == null) return;
    final entry = Entry(
      customerId: customerId!,
      type: type,
      amount: double.parse(amount.text.trim()),
      currency: currency,
      description: description.text.trim(),
      date: nowText(),
    );
    final id = await AppDatabase.instance.insertEntry(entry);
    if (mounted) Navigator.pop(context, Entry(
      id: id, customerId: entry.customerId, type: entry.type, amount: entry.amount,
      currency: entry.currency, description: entry.description, date: entry.date,
    ));
  }

}

class _EntryTypeSelector extends StatelessWidget {
  final EntryType value;
  final ValueChanged<EntryType> onChanged;

  const _EntryTypeSelector({required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    const blue = Color(0xFF2563EB);
    const red = Color(0xFFD04444);
    Widget option({required EntryType type, required String label, required IconData icon}) {
      final selected = value == type;
      final color = type == EntryType.credit ? blue : red;
      return Expanded(
        child: InkWell(
          onTap: () => onChanged(type),
          borderRadius: BorderRadius.circular(18),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 10),
            decoration: BoxDecoration(
              color: selected ? color : color.withAlpha(18),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: color.withAlpha(selected ? 255 : 90), width: selected ? 1.5 : 1),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                FaIcon(icon, size: 20, color: selected ? Colors.white : color),
                const SizedBox(width: 7),
                Text(
                  label,
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    color: selected ? Colors.white : color,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Row(
      children: [
        option(type: EntryType.credit, label: 'له', icon: FontAwesomeIcons.arrowDown),
        const SizedBox(width: 8),
        option(type: EntryType.debit, label: 'عليه', icon: FontAwesomeIcons.arrowUp),
      ],
    );
  }
}

class CustomerPickerDialog extends StatefulWidget {
  const CustomerPickerDialog({super.key});

  @override
  State<CustomerPickerDialog> createState() => _CustomerPickerDialogState();
}

class _CustomerPickerDialogState extends State<CustomerPickerDialog> {
  final searchController = TextEditingController();
  String search = '';

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  Future<List<Customer>> _loadCustomers() {
    return AppDatabase.instance.customers(query: search);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(
        'اختيار العميل',
        style: TextStyle(fontWeight: FontWeight.w800),
      ),
      content: SizedBox(
        width: 430,
        height: 520,
        child: Column(
          children: [
            TextField(
              controller: searchController,
              autofocus: true,
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: 'ابحث باسم العميل أو رقم الهاتف',
                prefixIcon: const FaIcon(FontAwesomeIcons.magnifyingGlass),
                suffixIcon: search.isEmpty
                    ? null
                    : IconButton(
                        tooltip: 'مسح البحث',
                        onPressed: () {
                          searchController.clear();
                          setState(() => search = '');
                        },
                        icon: const FaIcon(FontAwesomeIcons.xmark),
                      ),
              ),
              onChanged: (value) => setState(() => search = value),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: FutureBuilder<List<Customer>>(
                future: _loadCustomers(),
                builder: (context, snap) {
                  if (snap.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (snap.hasError) {
                    return Center(
                      child: Text('تعذر تحميل العملاء: ${snap.error}'),
                    );
                  }
                  final customers = snap.data ?? const <Customer>[];
                  if (customers.isEmpty) {
                    return const Center(
                      child: _EmptyCard(
                        icon: FontAwesomeIcons.users,
                        text: 'لا يوجد عميل مطابق للبحث',
                      ),
                    );
                  }
                  return ListView.separated(
                    padding: const EdgeInsets.only(bottom: 8),
                    itemCount: customers.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 7),
                    itemBuilder: (_, index) {
                      final customer = customers[index];
                      return Material(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(16),
                          onTap: () => Navigator.of(context).pop(customer),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 12,
                            ),
                            child: Row(
                              children: [
                                CircleAvatar(
                                  radius: 22,
                                  backgroundColor: Theme.of(context)
                                      .colorScheme
                                      .primaryContainer,
                                  child: Icon(
                                    FontAwesomeIcons.user,
                                    color: Theme.of(context)
                                        .colorScheme
                                        .primary,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        customer.name,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          fontWeight: FontWeight.w800,
                                          fontSize: 15,
                                        ),
                                      ),
                                      if (customer.phone.trim().isNotEmpty)
                                        Padding(
                                          padding: const EdgeInsets.only(top: 3),
                                          child: Text(
                                            customer.phone,
                                            style: TextStyle(
                                              color: Theme.of(context).colorScheme.onSurfaceVariant,
                                              fontSize: 12,
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                                Icon(
                                  FontAwesomeIcons.chevronLeft,
                                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text('إلغاء'),
        ),
      ],
    );
  }
}

class EntryDialog extends StatefulWidget {
  final int customerId;
  final Entry? initialEntry;

  const EntryDialog({super.key, required this.customerId, this.initialEntry});

  @override
  State<EntryDialog> createState() => _EntryDialogState();
}

class _EntryDialogState extends State<EntryDialog> {
  final form = GlobalKey<FormState>();
  final amount = TextEditingController();
  final description = TextEditingController();
  EntryType type = EntryType.credit;
  String currency = 'YER';

  @override
  void initState() {
    super.initState();
    final e = widget.initialEntry;
    currency = e?.currency ?? appSettings.defaultCurrency;
    if (e != null) {
      type = e.type;
      currency = e.currency;
      amount.text = money(e.amount);
      description.text = e.description;
    }
  }

  @override
  void dispose() {
    amount.dispose();
    description.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(
        widget.initialEntry == null ? 'إضافة عملية' : 'تعديل العملية',
        style: TextStyle(fontWeight: FontWeight.w800),
      ),
      content: Form(
        key: form,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _EntryTypeSelector(
                value: type,
                onChanged: (v) => setState(() => type = v),
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: amount,
                autofocus: true,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: const InputDecoration(
                  labelText: 'المبلغ',
                  prefixIcon: FaIcon(FontAwesomeIcons.moneyBill),
                ),
                validator: (v) {
                  final n = double.tryParse(v?.trim() ?? '');
                  return n == null || n <= 0 ? 'أدخل مبلغاً صحيحاً' : null;
                },
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: currency,
                decoration: const InputDecoration(
                  labelText: 'العملة',
                  prefixIcon: FaIcon(FontAwesomeIcons.moneyBillTransfer),
                ),
                items: const [
                  DropdownMenuItem(
                    value: 'YER',
                    child: Text('ريال يمني YER'),
                  ),
                  DropdownMenuItem(
                    value: 'SAR',
                    child: Text('ريال سعودي SAR'),
                  ),
                  DropdownMenuItem(
                    value: 'USD',
                    child: Text('دولار أمريكي USD'),
                  ),
                ],
                onChanged: (v) {
                  if (v != null) setState(() => currency = v);
                },
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: description,
                maxLines: 2,
                decoration: const InputDecoration(
                  labelText: 'البيان / الملاحظة',
                  prefixIcon: FaIcon(FontAwesomeIcons.noteSticky),
                ),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () { Navigator.of(context).pop(); },
          child: Text('إلغاء'),
        ),
        FilledButton.icon(
          style: FilledButton.styleFrom(
            backgroundColor: type == EntryType.credit
                ? const Color(0xFF2563EB)
                : const Color(0xFFD04444),
            foregroundColor: Colors.white,
          ),
          onPressed: _save,
          icon: const FaIcon(FontAwesomeIcons.check),
          label: Text(widget.initialEntry == null ? 'حفظ' : 'حفظ التعديل'),
        ),
      ],
    );
  }

  Future<void> _save() async {
    if (!form.currentState!.validate()) return;
    final existing = widget.initialEntry;
    final entry = Entry(
      id: existing?.id,
      customerId: widget.customerId,
      type: type,
      amount: double.parse(amount.text.trim()),
      currency: currency,
      description: description.text.trim(),
      date: existing?.date ?? nowText(),
    );
    final id = existing == null
        ? await AppDatabase.instance.insertEntry(entry)
        : await AppDatabase.instance.updateEntry(entry).then((_) => existing.id!);
    if (mounted) Navigator.pop(context, Entry(
      id: id, customerId: entry.customerId, type: entry.type, amount: entry.amount,
      currency: entry.currency, description: entry.description, date: entry.date,
    ));
  }

}


class InvoicePage extends StatefulWidget {
  const InvoicePage({super.key});

  @override
  State<InvoicePage> createState() => _InvoicePageState();
}

class _InvoicePageState extends State<InvoicePage> {
  final form = GlobalKey<FormState>();
  final note = TextEditingController();
  final List<_InvoiceLineControllers> lines = [_InvoiceLineControllers()];
  List<Customer> customers = [];
  int? customerId;
  String currency = 'YER';
  String paymentType = 'cash';
  String invoiceNumber = '...';
  bool loading = true;
  bool saving = false;
  bool logoBusy = false;

  @override
  void initState() {
    super.initState();
    _prepare();
  }

  Future<void> _prepare() async {
    final cashId = await AppDatabase.instance.ensureCashCustomer();
    final data = await AppDatabase.instance.customers();
    final number = await AppDatabase.instance.nextInvoiceNumber(prefix: appSettings.invoicePrefix);
    if (!mounted) return;
    setState(() {
      customers = data;
      customerId = cashId;
      invoiceNumber = number;
      currency = appSettings.defaultCurrency;
      loading = false;
    });
  }

  @override
  void dispose() {
    note.dispose();
    for (final line in lines) {
      line.dispose();
    }
    super.dispose();
  }

  String? get _selectedCustomerName {
    for (final customer in customers) {
      if (customer.id == customerId) return customer.name;
    }
    return null;
  }

  Future<void> _pickCustomer() async {
    final selected = await showDialog<Customer>(
      context: context,
      builder: (_) => const CustomerPickerDialog(),
    );
    if (selected != null && mounted) {
      setState(() {
        customerId = selected.id;
        if (_isCashCustomer) paymentType = 'cash';
      });
    }
  }

  Future<void> _addCustomer() async {
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => const CustomerDialog(),
    );
    if (saved == true) {
      final data = await AppDatabase.instance.customers();
      if (!mounted) return;
      setState(() => customers = data);
    }
  }

  void _addLine() {
    setState(() => lines.add(_InvoiceLineControllers()));
  }

  void _removeLine(int index) {
    if (lines.length == 1) return;
    final line = lines.removeAt(index);
    line.dispose();
    setState(() {});
  }

  bool get _isCashCustomer {
    for (final customer in customers) {
      if (customer.id == customerId) return customer.name.trim() == 'نقد';
    }
    return false;
  }

  double _lineTotal(_InvoiceLineControllers line) {
    final qty = double.tryParse(line.quantity.text.trim()) ?? 0;
    final price = double.tryParse(line.price.text.trim()) ?? 0;
    return qty * price;
  }

  double get _grandTotal => lines.fold(0.0, (sum, line) => sum + _lineTotal(line));

  Future<void> _save() async {
    if (saving || customerId == null) return;
    if (!form.currentState!.validate()) return;
    for (final line in lines) {
      if (line.name.text.trim().isEmpty) {
        _showMessage('اكتب اسم الصنف في جميع الصفوف');
        return;
      }
      final qty = double.tryParse(line.quantity.text.trim()) ?? 0;
      final price = double.tryParse(line.price.text.trim()) ?? 0;
      if (qty <= 0 || price <= 0) {
        _showMessage('تحقق من الكمية والسعر في أصناف الفاتورة');
        return;
      }
    }

    setState(() => saving = true);
    final items = lines
        .map(
          (line) => InvoiceItem(
            invoiceId: 0,
            name: line.name.text.trim(),
            quantity: double.parse(line.quantity.text.trim()),
            price: double.parse(line.price.text.trim()),
          ),
        )
        .toList();

    try {
      final invoice = Invoice(
        invoiceNumber: invoiceNumber,
        customerId: customerId!,
        currency: currency,
        total: _grandTotal,
        note: note.text.trim(),
        date: nowText(),
        paymentType: _isCashCustomer ? 'cash' : paymentType,
      );
      final id = await AppDatabase.instance.insertInvoiceWithItems(invoice, items);
      if (mounted) Navigator.pop(context, Invoice(
        id: id, invoiceNumber: invoice.invoiceNumber, customerId: invoice.customerId,
        currency: invoice.currency, total: invoice.total, note: invoice.note,
        date: invoice.date, paymentType: invoice.paymentType,
      ));
    } catch (e) {
      if (!mounted) return;
      setState(() => saving = false);
      _showMessage('تعذر حفظ الفاتورة. حاول مرة أخرى.');
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'فاتورة جديدة',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        actions: [
          Padding(
            padding: const EdgeInsetsDirectional.only(end: 12),
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  invoiceNumber,
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.primary,
                    fontWeight: FontWeight.w900,
                    fontSize: 12,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      body: Form(
        key: form,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
          children: [
            _InvoiceHeaderCard(
              invoiceNumber: invoiceNumber,
              date: nowText(),
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(15),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'بيانات الفاتورة',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: FormField<int>(
                            initialValue: customerId,
                            validator: (_) => customerId == null ? 'اختر العميل' : null,
                            builder: (field) {
                              return Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  InkWell(
                                    borderRadius: BorderRadius.circular(12),
                                    onTap: _pickCustomer,
                                    child: InputDecorator(
                                      decoration: InputDecoration(
                                        labelText: 'العميل',
                                        prefixIcon: const FaIcon(FontAwesomeIcons.user),
                                        suffixIcon: const FaIcon(FontAwesomeIcons.chevronDown),
                                        errorText: field.errorText,
                                      ),
                                      child: Text(
                                        _selectedCustomerName ?? 'اختر العميل',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w600,
                                          color: _selectedCustomerName == null
                                              ? Theme.of(context).colorScheme.onSurfaceVariant
                                              : Theme.of(context).colorScheme.onSurface,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              );
                            },
                          ),
                        ),
                        IconButton(
                          tooltip: 'إضافة عميل',
                          onPressed: _addCustomer,
                          icon: const FaIcon(FontAwesomeIcons.userPlus),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    DropdownButtonFormField<String>(
                      value: currency,
                      decoration: const InputDecoration(
                        labelText: 'عملة الفاتورة',
                        prefixIcon: FaIcon(FontAwesomeIcons.moneyBillTransfer),
                      ),
                      items: const [
                        DropdownMenuItem(value: 'YER', child: Text('ريال يمني YER')),
                        DropdownMenuItem(value: 'SAR', child: Text('ريال سعودي SAR')),
                        DropdownMenuItem(value: 'USD', child: Text('دولار أمريكي USD')),
                      ],
                      onChanged: (v) {
                        if (v != null) setState(() => currency = v);
                      },
                    ),
                    if (!_isCashCustomer) ...[
                      const SizedBox(height: 12),
                      Text(
                        'طريقة السداد',
                        style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(height: 7),
                      SegmentedButton<String>(
                        segments: const [
                          ButtonSegment<String>(
                            value: 'cash',
                            icon: FaIcon(FontAwesomeIcons.moneyBill),
                            label: Text('نقد'),
                          ),
                          ButtonSegment<String>(
                            value: 'credit',
                            icon: FaIcon(FontAwesomeIcons.clock),
                            label: Text('آجل'),
                          ),
                        ],
                        selected: {paymentType},
                        onSelectionChanged: (value) {
                          setState(() => paymentType = value.first);
                        },
                      ),
                      if (paymentType == 'credit')
                        Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Text(
                            'سيتم تسجيل إجمالي الفاتورة على العميل كـ «عليه».',
                            style: TextStyle(
                              color: Colors.orange.shade800,
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 14, 12, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'أصناف الفاتورة',
                                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
                              ),
                              SizedBox(height: 3),
                              Text(
                                'أضف أي عدد من الأصناف واكتب السعر والكمية يدوياً',
                                style: TextStyle(fontSize: 11, color: Theme.of(context).colorScheme.onSurfaceVariant),
                              ),
                            ],
                          ),
                        ),
                        FilledButton.icon(
                          onPressed: _addLine,
                          icon: const FaIcon(FontAwesomeIcons.plus, size: 18),
                          label: Text('إضافة صنف'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Table(
                        defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                        columnWidths: const {
                          0: FixedColumnWidth(170),
                          1: FixedColumnWidth(85),
                          2: FixedColumnWidth(120),
                          3: FixedColumnWidth(120),
                          4: FixedColumnWidth(48),
                        },
                        border: TableBorder.all(
                          color: Theme.of(context).colorScheme.outlineVariant,
                          borderRadius: BorderRadius.all(Radius.circular(14)),
                        ),
                        children: [
                          TableRow(
                            decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainerHighest),
                            children: const [
                              _InvoiceTableHeader('الصنف'),
                              _InvoiceTableHeader('الكمية'),
                              _InvoiceTableHeader('السعر'),
                              _InvoiceTableHeader('الإجمالي'),
                              _InvoiceTableHeader(''),
                            ],
                          ),
                          ...List.generate(lines.length, (index) {
                            final line = lines[index];
                            return TableRow(
                              children: [
                                _InvoiceCell(
                                  child: TextField(
                                    controller: line.name,
                                    textInputAction: TextInputAction.next,
                                    decoration: const InputDecoration(
                                      hintText: 'اسم الصنف',
                                      border: InputBorder.none,
                                      filled: false,
                                    ),
                                    onChanged: (_) => setState(() {}),
                                  ),
                                ),
                                _InvoiceCell(
                                  child: TextField(
                                    controller: line.quantity,
                                    textInputAction: TextInputAction.next,
                                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                    textAlign: TextAlign.center,
                                    decoration: const InputDecoration(
                                      hintText: '1',
                                      border: InputBorder.none,
                                      filled: false,
                                    ),
                                    onChanged: (_) => setState(() {}),
                                  ),
                                ),
                                _InvoiceCell(
                                  child: TextField(
                                    controller: line.price,
                                    textInputAction: TextInputAction.done,
                                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                    textAlign: TextAlign.center,
                                    decoration: const InputDecoration(
                                      hintText: '0',
                                      border: InputBorder.none,
                                      filled: false,
                                    ),
                                    onChanged: (_) => setState(() {}),
                                  ),
                                ),
                                _InvoiceCell(
                                  child: Text(
                                    money(_lineTotal(line)),
                                    textAlign: TextAlign.center,
                                    style: TextStyle(fontWeight: FontWeight.w900),
                                  ),
                                ),
                                _InvoiceCell(
                                  child: IconButton(
                                    onPressed: lines.length == 1 ? null : () => _removeLine(index),
                                    icon: const FaIcon(FontAwesomeIcons.trashCan),
                                    color: Colors.red,
                                  ),
                                ),
                              ],
                            );
                          }),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                      decoration: BoxDecoration(
                        color: currencyColor(currency).withAlpha(15),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Row(
                        children: [
                          const Expanded(
                            child: Text(
                              'إجمالي الفاتورة',
                              style: TextStyle(fontWeight: FontWeight.w800),
                            ),
                          ),
                          Text(
                            '${money(_grandTotal)} ${currencySymbol(currency)}',
                            style: TextStyle(
                              color: currencyColor(currency),
                              fontSize: 17,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(15),
                child: TextFormField(
                  controller: note,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'ملاحظة الفاتورة',
                    hintText: 'اكتب أي ملاحظة إضافية هنا',
                    prefixIcon: FaIcon(FontAwesomeIcons.noteSticky),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: saving ? null : _save,
              style: FilledButton.styleFrom(
                minimumSize: const Size.fromHeight(54),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              icon: saving
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const FaIcon(FontAwesomeIcons.floppyDisk),
              label: Text(saving ? 'جارٍ الحفظ...' : 'حفظ الفاتورة'),
            ),
          ],
        ),
      ),
    );
  }
}

class _InvoiceLineControllers {
  final name = TextEditingController();
  final quantity = TextEditingController(text: '1');
  final price = TextEditingController();

  void dispose() {
    name.dispose();
    quantity.dispose();
    price.dispose();
  }
}

class _InvoiceTableHeader extends StatelessWidget {
  final String text;

  const _InvoiceTableHeader(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 12, fontWeight: FontWeight.w900),
      ),
    );
  }
}

class _InvoiceCell extends StatelessWidget {
  final Widget child;

  const _InvoiceCell({required this.child});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
      child: child,
    );
  }
}

class _InvoiceHeaderCard extends StatelessWidget {
  final String invoiceNumber;
  final String date;

  const _InvoiceHeaderCard({required this.invoiceNumber, required this.date});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF0756C9), Color(0xFF1D86F8)],
          begin: Alignment.bottomRight,
          end: Alignment.topLeft,
        ),
        borderRadius: BorderRadius.circular(22),
      ),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: Colors.white.withAlpha(30),
              borderRadius: BorderRadius.circular(15),
            ),
            child: const FaIcon(FontAwesomeIcons.receipt, color: Colors.white, size: 27),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'فاتورة مبيعات',
                  style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 4),
                Text(
                  'رقم الفاتورة: $invoiceNumber',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                ),
                Text(
                  'التاريخ: ${dateOnly(date)}',
                  style: TextStyle(color: Colors.white70, fontSize: 11),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class CustomerDialog extends StatefulWidget {
  final Customer? customer;

  const CustomerDialog({super.key, this.customer});

  @override
  State<CustomerDialog> createState() => _CustomerDialogState();
}

class _CustomerDialogState extends State<CustomerDialog> {
  final form = GlobalKey<FormState>();
  late final TextEditingController name;
  late final TextEditingController phone;
  late final TextEditingController address;
  late final TextEditingController note;

  @override
  void initState() {
    super.initState();
    final c = widget.customer;
    name = TextEditingController(text: c?.name ?? '');
    phone = TextEditingController(text: c?.phone ?? '');
    address = TextEditingController(text: c?.address ?? '');
    note = TextEditingController(text: c?.note ?? '');
  }

  @override
  void dispose() {
    name.dispose();
    phone.dispose();
    address.dispose();
    note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(
        widget.customer == null ? 'إضافة عميل جديد' : 'تعديل بيانات العميل',
        style: TextStyle(fontWeight: FontWeight.w800),
      ),
      content: Form(
        key: form,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: name,
                autofocus: true,
                decoration: const InputDecoration(
                  labelText: 'اسم العميل *',
                  prefixIcon: FaIcon(FontAwesomeIcons.user),
                ),
                validator: (v) =>
                    v!.trim().isEmpty ? 'أدخل اسم العميل' : null,
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: phone,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: 'رقم الهاتف',
                  prefixIcon: FaIcon(FontAwesomeIcons.phone),
                ),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: address,
                decoration: const InputDecoration(
                  labelText: 'العنوان',
                  prefixIcon: FaIcon(FontAwesomeIcons.locationDot),
                ),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: note,
                maxLines: 2,
                decoration: const InputDecoration(
                  labelText: 'ملاحظة',
                  prefixIcon: FaIcon(FontAwesomeIcons.noteSticky),
                ),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () { Navigator.of(context).pop(); },
          child: Text('إلغاء'),
        ),
        FilledButton.icon(
          onPressed: _save,
          icon: const FaIcon(FontAwesomeIcons.check),
          label: Text('حفظ'),
        ),
      ],
    );
  }

  Future<void> _save() async {
    if (!form.currentState!.validate()) return;
    final old = widget.customer;
    final customer = Customer(
      id: old?.id,
      name: name.text.trim(),
      phone: phone.text.trim(),
      address: address.text.trim(),
      note: note.text.trim(),
      createdAt: old?.createdAt ?? nowText(),
    );
    if (old == null) {
      await AppDatabase.instance.insertCustomer(customer);
    } else {
      await AppDatabase.instance.updateCustomer(customer);
    }
    if (mounted) Navigator.pop(context, true);
  }
}

class TransactionsPage extends StatefulWidget {
  const TransactionsPage({super.key});

  @override
  State<TransactionsPage> createState() => _TransactionsPageState();
}

class _TransactionsPageState extends State<TransactionsPage> {
  String currency = 'ALL';
  String type = 'ALL';
  String search = '';

  Future<_TransactionsData> _load() async {
    final entries = await AppDatabase.instance.allEntriesWithCustomers(
      currency: currency == 'ALL' ? null : currency,
      type: type == 'ALL' ? null : type,
      query: search,
    );
    final cashInvoices = type == 'ALL'
        ? await AppDatabase.instance.cashInvoicesWithCustomers(
            currency: currency == 'ALL' ? null : currency,
            query: search,
          )
        : <InvoiceWithCustomer>[];
    return _TransactionsData(entries: entries, cashInvoices: cashInvoices);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 9),
          child: TextField(
            decoration: const InputDecoration(
              hintText: 'ابحث في العمليات أو الفواتير أو أسماء العملاء',
              prefixIcon: FaIcon(FontAwesomeIcons.magnifyingGlass),
            ),
            onChanged: (v) => setState(() => search = v),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              Expanded(
                child: _SimpleDropdown(
                  value: currency,
                  items: const [
                    DropdownMenuItem(value: 'ALL', child: Text('كل العملات')),
                    DropdownMenuItem(value: 'YER', child: Text('ريال يمني')),
                    DropdownMenuItem(value: 'SAR', child: Text('ريال سعودي')),
                    DropdownMenuItem(value: 'USD', child: Text('دولار أمريكي')),
                  ],
                  onChanged: (v) => setState(() => currency = v),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _SimpleDropdown(
                  value: type,
                  items: const [
                    DropdownMenuItem(value: 'ALL', child: Text('كل العمليات')),
                    DropdownMenuItem(value: 'credit', child: Text('له + فواتير نقد')),
                    DropdownMenuItem(value: 'debit', child: Text('عليه')),
                  ],
                  onChanged: (v) => setState(() => type = v),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 9),
        Expanded(
          child: FutureBuilder<_TransactionsData>(
            future: _load(),
            builder: (context, snap) {
              if (snap.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snap.hasError) return _ErrorView(error: snap.error);
              final data = snap.data!;
              final total = data.entries.length + data.cashInvoices.length;
              if (total == 0) {
                return const _EmptyCard(
                  icon: FontAwesomeIcons.receipt,
                  text: 'لا توجد عمليات مطابقة',
                );
              }
              return RefreshIndicator(
                onRefresh: () async => setState(() {}),
                child: ListView.separated(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 100),
                  itemCount: total,
                  separatorBuilder: (_, __) => const SizedBox(height: 7),
                  itemBuilder: (_, i) {
                    if (i < data.entries.length) {
                      return TransactionTile(
                        item: data.entries[i],
                        onDeleted: () => setState(() {}),
                        onChanged: () => setState(() {}),
                      );
                    }
                    return CashInvoiceOperationTile(
                      item: data.cashInvoices[i - data.entries.length],
                    );
                  },
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _TransactionsData {
  final List<EntryWithCustomer> entries;
  final List<InvoiceWithCustomer> cashInvoices;

  const _TransactionsData({
    required this.entries,
    required this.cashInvoices,
  });
}

class CashInvoiceOperationTile extends StatelessWidget {
  final InvoiceWithCustomer item;

  const CashInvoiceOperationTile({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    final color = currencyColor(item.invoice.currency);
    return Card(
      child: ListTile(
        onTap: () async {
          await showInvoiceResultDialog(
            context,
            invoice: item.invoice,
            customerName: item.customerName,
            title: 'تفاصيل الفاتورة',
          );
        },
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        leading: Container(
          width: 43,
          height: 43,
          decoration: BoxDecoration(
            color: color.withAlpha(20),
            borderRadius: BorderRadius.circular(13),
          ),
          child: FaIcon(FontAwesomeIcons.cashRegister, color: color),
        ),
        title: Text(
          'فاتورة نقدية • ${money(item.invoice.total)} ${currencySymbol(item.invoice.currency)}',
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
        subtitle: Text(
          '${item.customerName} • رقم ${item.invoice.invoiceNumber}\n${dateOnly(item.invoice.date)}',
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
        isThreeLine: true,
        trailing: const Chip(
          avatar: FaIcon(FontAwesomeIcons.moneyBill, size: 17),
          label: Text('نقد'),
        ),
      ),
    );
  }
}

class _SimpleDropdown extends StatelessWidget {
  final String value;
  final List<DropdownMenuItem<String>> items;
  final ValueChanged<String> onChanged;

  const _SimpleDropdown({
    required this.value,
    required this.items,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      value: value,
      isExpanded: true,
      decoration: const InputDecoration(
        contentPadding: EdgeInsets.symmetric(horizontal: 13, vertical: 12),
      ),
      items: items,
      onChanged: (v) {
        if (v != null) onChanged(v);
      },
    );
  }
}

class _CurrencyFilter extends StatelessWidget {
  final String selected;
  final ValueChanged<String> onChanged;
  final bool includeAll;

  const _CurrencyFilter({
    required this.selected,
    required this.onChanged,
    this.includeAll = false,
  });

  @override
  Widget build(BuildContext context) {
    final values = [if (includeAll) 'ALL', 'YER', 'SAR', 'USD'];
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: values.map((value) {
          final active = value == selected;
          return Padding(
            padding: const EdgeInsets.only(left: 7),
            child: ChoiceChip(
              label: Text(value == 'ALL' ? 'الكل' : currencyName(value)),
              selected: active,
              onSelected: (_) => onChanged(value),
            ),
          );
        }).toList(),
      ),
    );
  }
}

class TransactionTile extends StatelessWidget {
  final EntryWithCustomer item;
  final bool compact;
  final VoidCallback? onDeleted;
  final VoidCallback? onChanged;

  const TransactionTile({
    super.key,
    required this.item,
    this.compact = false,
    this.onDeleted,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final positive = item.entry.type == EntryType.credit;
    final color = currencyColor(item.entry.currency);
    return Card(
      child: ListTile(
        onTap: () async {
          await showEntryResultDialog(
            context,
            entry: item.entry,
            customerName: item.customerName,
            title: 'تفاصيل العملية',
          );
        },
        contentPadding: EdgeInsets.symmetric(
          horizontal: compact ? 12 : 14,
          vertical: compact ? 3 : 6,
        ),
        leading: Container(
          width: 43,
          height: 43,
          decoration: BoxDecoration(
            color: (positive ? color : Colors.red).withAlpha(20),
            borderRadius: BorderRadius.circular(13),
          ),
          child: Icon(
            positive
                ? FontAwesomeIcons.arrowDown
                : FontAwesomeIcons.arrowUp,
            color: positive ? color : Colors.red.shade700,
          ),
        ),
        title: Text(
          '${positive ? 'له' : 'عليه'} • ${money(item.entry.amount)} ${currencySymbol(item.entry.currency)}',
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
        subtitle: Text(
          '${item.customerName} • ${item.entry.description.isEmpty ? 'بدون بيان' : item.entry.description}\n${dateOnly(item.entry.date)}',
          maxLines: compact ? 2 : 3,
          overflow: TextOverflow.ellipsis,
        ),
        isThreeLine: true,
        trailing: PopupMenuButton<String>(
          onSelected: (value) async {
            if (value == 'share') {
              await Share.share(_shareText());
            } else if (value == 'edit') {
              final saved = await showDialog<Entry>(
                context: context,
                builder: (_) => EntryDialog(
                  customerId: item.entry.customerId,
                  initialEntry: item.entry,
                ),
              );
              if (saved != null) {
                onChanged?.call();
                final customer = await AppDatabase.instance.customerNameById(saved.customerId) ?? item.customerName;
                if (context.mounted) await showEntryResultDialog(context, entry: saved, customerName: customer);
              }
            } else if (value == 'delete') {
              final ok = await _confirmDelete(context);
              if (ok) {
                await AppDatabase.instance.deleteEntry(item.entry.id!);
                onDeleted?.call();
              }
            }
          },
          itemBuilder: (_) => const [
            PopupMenuItem(
              value: 'edit',
              child: Text('تعديل العملية'),
            ),
            PopupMenuItem(
              value: 'share',
              child: Text('مشاركة العملية'),
            ),
            PopupMenuItem(
              value: 'delete',
              child: Text('حذف العملية'),
            ),
          ],
        ),
      ),
    );
  }

  String _shareText() {
    final businessName = appSettings.businessName.trim().isEmpty ? 'حساباتي' : appSettings.businessName.trim();
    final phone = appSettings.businessPhone.trim();
    final address = appSettings.businessAddress.trim();
    return '$businessName\n'
        '${address.isEmpty ? '' : 'العنوان: $address\n'}'
        '${phone.isEmpty ? '' : 'الهاتف: $phone\n'}'
        '\n'
        'العميل: ${item.customerName}\n'
        'العملية: ${item.entry.type.label}\n'
        'المبلغ: ${money(item.entry.amount)} ${currencyName(item.entry.currency)}\n'
        'البيان: ${item.entry.description.isEmpty ? 'بدون بيان' : item.entry.description}\n'
        'التاريخ: ${item.entry.date}';
  }

  Future<bool> _confirmDelete(BuildContext context) async {
    return await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            title: Text('حذف العملية'),
            content: Text('هل تريد حذف هذه العملية نهائياً؟'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: Text('إلغاء'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: Text('حذف'),
              ),
            ],
          ),
        ) ??
        false;
  }
}

class _InvoicePrintPage extends StatelessWidget {
  final Invoice invoice;
  final String customerName;
  final List<InvoiceItem> items;
  final Uint8List? logo;
  final bool firstPage;
  final bool lastPage;

  const _InvoicePrintPage({
    required this.invoice,
    required this.customerName,
    required this.items,
    required this.logo,
    required this.firstPage,
    required this.lastPage,
  });

  @override
  Widget build(BuildContext context) {
    final accent = invoice.paymentType == 'credit' ? const Color(0xFFD04444) : const Color(0xFF2563EB);
    final payment = invoice.paymentType == 'credit' ? 'آجل' : 'نقد';

    return _PdfReportPage(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _PdfBusinessHeader(
            logoBytes: logo,
            title: firstPage ? 'فاتورة ${invoice.invoiceNumber}' : 'فاتورة ${invoice.invoiceNumber} - متابعة',
          ),
          if (firstPage) ...[
            _pdfSectionTitle('بيانات الفاتورة'),
            _pdfInfoCard([
              _pdfInfoLine('رقم الفاتورة', invoice.invoiceNumber, bold: true),
              _pdfInfoLine('العميل', customerName, bold: true),
              _pdfInfoLine('التاريخ', dateOnly(invoice.date)),
              _pdfInfoLine('طريقة الدفع', payment, bold: true),
              _pdfInfoLine('العملة', currencyName(invoice.currency), bold: true),
            ]),
            _pdfSectionTitle('أصناف الفاتورة'),
          ] else ...[
            _pdfSectionTitle('أصناف الفاتورة - متابعة'),
          ],
          _pdfTable(
            headers: const ['الصنف', 'الكمية', 'السعر', 'الإجمالي'],
            flexes: const [4, 1, 2, 2],
            rows: items
                .map((item) => [
                      item.name,
                      money(item.quantity),
                      '${money(item.price)} ${currencySymbol(invoice.currency)}',
                      '${money(item.total)} ${currencySymbol(invoice.currency)}',
                    ])
                .toList(),
          ),
          if (lastPage) ...[
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: accent.withAlpha(18),
                border: Border.all(color: accent.withAlpha(80)),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text('إجمالي الفاتورة', style: _pdfText(size: 14, weight: FontWeight.w900)),
                  ),
                  Text(
                    '${money(invoice.total)} ${currencySymbol(invoice.currency)}',
                    style: _pdfText(size: 15, weight: FontWeight.w900, color: accent),
                  ),
                ],
              ),
            ),
            if (invoice.note.trim().isNotEmpty) ...[
              _pdfSectionTitle('ملاحظة'),
              _pdfInfoCard([Text(invoice.note.trim(), style: _pdfText(size: 10, weight: FontWeight.w600))]),
            ],
          ],
          const Spacer(),
          Container(
            padding: const EdgeInsets.only(top: 10),
            decoration: const BoxDecoration(border: Border(top: BorderSide(color: _pdfLine))),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('حساباتي • دفتر حساباتك', style: _pdfText(size: 9, color: _pdfMuted)),
                Text('فاتورة ${invoice.invoiceNumber}', style: _pdfText(size: 9, weight: FontWeight.w800, color: accent)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class InvoicesPage extends StatefulWidget {
  const InvoicesPage({super.key});

  @override
  State<InvoicesPage> createState() => _InvoicesPageState();
}

class _InvoicesPageState extends State<InvoicesPage> {
  String selectedCurrency = 'ALL';
  String search = '';

  Future<List<Invoice>> _load() async {
    final invoices = await AppDatabase.instance.invoices(
      currency: selectedCurrency == 'ALL' ? null : selectedCurrency,
    );
    final q = search.trim().toLowerCase();
    if (q.isEmpty) return invoices;
    final result = <Invoice>[];
    for (final invoice in invoices) {
      final customer = await AppDatabase.instance.customerNameById(invoice.customerId) ?? '';
      if (invoice.invoiceNumber.toLowerCase().contains(q) ||
          customer.toLowerCase().contains(q) ||
          invoice.note.toLowerCase().contains(q)) {
        result.add(invoice);
      }
    }
    return result;
  }

  Future<void> _openNewInvoice() async {
    final saved = await Navigator.push<Invoice>(
      context,
      MaterialPageRoute(builder: (_) => const InvoicePage()),
    );
    if (!mounted) return;
    if (saved != null) {
      setState(() {});
      final customer = await AppDatabase.instance.customerNameById(saved.customerId) ?? 'غير معروف';
      if (mounted) await showInvoiceResultDialog(context, invoice: saved, customerName: customer);
    }
  }

  Future<void> _showInvoice(Invoice invoice) async {
    final name = await AppDatabase.instance.customerNameById(invoice.customerId) ?? 'غير معروف';
    final items = await AppDatabase.instance.invoiceItems(invoice.id!);
    if (!mounted) return;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const BusinessInfoCard(compact: true),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        'الفاتورة ${invoice.invoiceNumber}',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                      ),
                    ),
                    Chip(
                      avatar: Icon(
                        invoice.paymentType == 'credit'
                            ? FontAwesomeIcons.clock
                            : FontAwesomeIcons.moneyBill,
                        size: 18,
                      ),
                      label: Text(invoice.paymentType == 'credit' ? 'آجل' : 'نقد'),
                    ),
                    IconButton(
                      tooltip: 'حذف الفاتورة',
                      onPressed: () async {
                        final ok = await showDialog<bool>(
                          context: context,
                          builder: (_) => AlertDialog(
                            title: Text('حذف الفاتورة'),
                            content: Text('هل تريد حذف الفاتورة ${invoice.invoiceNumber} نهائياً؟'),
                            actions: [
                              TextButton(onPressed: () => Navigator.pop(context, false), child: Text('إلغاء')),
                              FilledButton(onPressed: () => Navigator.pop(context, true), child: Text('حذف')),
                            ],
                          ),
                        ) ?? false;
                        if (ok) {
                          await AppDatabase.instance.deleteInvoice(invoice.id!);
                          if (context.mounted) Navigator.pop(context);
                          if (mounted) setState(() {});
                        }
                      },
                      icon: const FaIcon(FontAwesomeIcons.trashCan),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text('العميل: $name'),
                Text('التاريخ: ${dateOnly(invoice.date)}'),
                const SizedBox(height: 14),
                ...items.map(
                  (item) => Card(
                    margin: const EdgeInsets.only(bottom: 7),
                    child: ListTile(
                      title: Text(item.name, style: TextStyle(fontWeight: FontWeight.w800)),
                      subtitle: Text('${money(item.quantity)} × ${money(item.price)}'),
                      trailing: Text(
                        '${money(item.total)} ${currencySymbol(invoice.currency)}',
                        style: TextStyle(fontWeight: FontWeight.w900),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 7),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: currencyColor(invoice.currency).withAlpha(16),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    children: [
                      const Expanded(
                        child: Text('الإجمالي', style: TextStyle(fontWeight: FontWeight.w900)),
                      ),
                      Text(
                        '${money(invoice.total)} ${currencySymbol(invoice.currency)}',
                        style: TextStyle(
                          color: currencyColor(invoice.currency),
                          fontSize: 17,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                ),
                if (invoice.note.trim().isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Text('ملاحظة: ${invoice.note}'),
                ],
                if (invoice.paymentType == 'credit')
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Text(
                      'هذه الفاتورة مسجلة على العميل كـ «عليه».',
                      style: TextStyle(color: Colors.orange.shade800, fontWeight: FontWeight.w800),
                    ),
                  ),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: () => _printInvoice(invoice, name, items),
                    icon: const FaIcon(FontAwesomeIcons.print),
                    label: Text('طباعة الفاتورة'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _printInvoice(Invoice invoice, String customerName, List<InvoiceItem> items) async {
    try {
      await _runWithPrintWaiting<void>(context, () async {
        final logo = await _businessLogoBytes();
        await _precachePdfBusinessLogo(context, logo);
        final chunks = _pdfChunks(items, 8);
        final pages = <Widget>[];
        if (chunks.isEmpty) {
          pages.add(_InvoicePrintPage(
            invoice: invoice,
            customerName: customerName,
            items: const [],
            logo: logo,
            firstPage: true,
            lastPage: true,
          ));
        } else {
          for (var i = 0; i < chunks.length; i++) {
            pages.add(_InvoicePrintPage(
              invoice: invoice,
              customerName: customerName,
              items: chunks[i],
              logo: logo,
              firstPage: i == 0,
              lastPage: i == chunks.length - 1,
            ));
          }
        }
        final images = await _capturePdfPages(context, pages);
        final bytes = await _imagesToPdf(images);
        await Printing.layoutPdf(
          name: 'فاتورة_${invoice.invoiceNumber}',
          onLayout: (_) async => bytes,
        );
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذر طباعة الفاتورة: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder<List<Invoice>>(
        future: _load(),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) return _ErrorView(error: snap.error);
          final invoices = snap.data ?? <Invoice>[];
          return RefreshIndicator(
            onRefresh: () async => setState(() {}),
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
              children: [
                TextField(
                  decoration: const InputDecoration(
                    hintText: 'بحث برقم الفاتورة أو العميل أو الملاحظة',
                    prefixIcon: FaIcon(FontAwesomeIcons.magnifyingGlass),
                  ),
                  onChanged: (v) => setState(() => search = v),
                ),
                const SizedBox(height: 8),
                _CurrencyFilter(
                  selected: selectedCurrency,
                  onChanged: (v) => setState(() => selectedCurrency = v),
                  includeAll: true,
                ),
                const SizedBox(height: 12),
                if (invoices.isEmpty)
                  const _EmptyCard(
                    icon: FontAwesomeIcons.receipt,
                    text: 'لا توجد فواتير محفوظة حتى الآن',
                  )
                else
                  ...invoices.map(
                    (invoice) => Padding(
                      padding: const EdgeInsets.only(bottom: 9),
                      child: FutureBuilder<String?>(
                        future: AppDatabase.instance.customerNameById(invoice.customerId),
                        builder: (context, customerSnap) {
                          final customer = customerSnap.data ?? '...';
                          final credit = invoice.paymentType == 'credit';
                          return Card(
                            child: ListTile(
                              onTap: () => _showInvoice(invoice),
                              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                              leading: CircleAvatar(
                                backgroundColor: currencyColor(invoice.currency).withAlpha(18),
                                child: FaIcon(FontAwesomeIcons.receipt, color: currencyColor(invoice.currency)),
                              ),
                              title: Text(
                                invoice.invoiceNumber,
                                style: TextStyle(fontWeight: FontWeight.w900),
                              ),
                              subtitle: Text('$customer • ${dateOnly(invoice.date)} • ${credit ? 'آجل' : 'نقد'}'),
                              trailing: Text(
                                '${money(invoice.total)}\n${currencySymbol(invoice.currency)}',
                                textAlign: TextAlign.end,
                                style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  color: currencyColor(invoice.currency),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}



Widget _customerReportPage({
  required Uint8List? logo,
  required Customer customer,
  required List<CustomerCurrencyBalance> balances,
  required List<Entry> entries,
  required bool firstPage,
  required bool lastPage,
  required int totalEntries,
  required Map<String, List<double>> totals,
}) => _PdfReportPage(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _PdfBusinessHeader(logoBytes: logo, title: 'تقرير تفصيلي للعميل'),
          if (firstPage) ...[
            _pdfSectionTitle('بيانات العميل'),
            _pdfInfoCard([
              _pdfInfoLine('العميل', customer.name, bold: true),
              if (customer.phone.trim().isNotEmpty) _pdfInfoLine('الهاتف', customer.phone),
              if (customer.address.trim().isNotEmpty) _pdfInfoLine('العنوان', customer.address),
              if (customer.note.trim().isNotEmpty) _pdfInfoLine('ملاحظة', customer.note),
              _pdfInfoLine('تاريخ التقرير', DateFormat('yyyy-MM-dd HH:mm').format(DateTime.now())),
            ]),
            _pdfSectionTitle('الأرصدة حسب العملة'),
            _pdfTable(
              headers: const ['العملة', 'الرصيد', 'عدد العمليات'],
              flexes: const [3, 2, 2],
              rows: balances.map((b) => [currencyName(b.currency), '${money(b.balance)} ${currencySymbol(b.currency)}', '${b.transactions}']).toList(),
            ),
          ],
          _pdfSectionTitle(firstPage ? 'سجل العمليات' : 'سجل العمليات — متابعة'),
          if (entries.isEmpty)
            _pdfInfoCard([Text('لا توجد عمليات لهذا العميل.', style: _pdfText(size: 11, color: _pdfMuted))])
          else
            _pdfTable(
              headers: const ['التاريخ', 'النوع', 'العملة', 'المبلغ', 'البيان'],
              flexes: const [2, 1, 2, 2, 3],
              rows: entries.map((e) => [dateOnly(e.date), e.type == EntryType.credit ? 'له' : 'عليه', currencyName(e.currency), '${money(e.amount)} ${currencySymbol(e.currency)}', e.description.isEmpty ? 'بدون بيان' : e.description]).toList(),
              rowColors: entries.map((e) => e.type == EntryType.credit ? const Color(0xFF2563EB) : const Color(0xFFD04444)).toList(),
            ),
          if (lastPage) ...[
            _pdfSectionTitle('الإجمالي'),
            _pdfTotalsCard(totals: totals),
          ],
          const Spacer(),
          Container(
            padding: const EdgeInsets.only(top: 10),
            decoration: const BoxDecoration(border: Border(top: BorderSide(color: _pdfLine))),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('حساباتي • دفتر حساباتك', style: _pdfText(size: 9, color: _pdfMuted)),
              Text('إجمالي العمليات: $totalEntries', style: _pdfText(size: 9, weight: FontWeight.w800)),
            ]),
          ),
        ],
      ),
    );

Map<String, List<double>> _buildEntryTotals(List<Entry> entries) {
  final totals = <String, List<double>>{};
  for (final entry in entries) {
    final item = totals.putIfAbsent(entry.currency, () => [0.0, 0.0]);
    if (entry.type == EntryType.credit) {
      item[0] += entry.amount;
    } else {
      item[1] += entry.amount;
    }
  }
  return totals;
}

Map<String, List<double>> _buildEntryWithCustomerTotals(List<EntryWithCustomer> entries) {
  return _buildEntryTotals(entries.map((item) => item.entry).toList());
}

Widget _statementReportPage({
  required Uint8List? logo,
  required String currency,
  required CurrencyTotal? total,
  required List<EntryWithCustomer> entries,
  required bool lastPage,
  required Map<String, List<double>> totals,
}) => _PdfReportPage(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _PdfBusinessHeader(logoBytes: logo, title: 'كشف حساب - ${currencyName(currency)}'),
          const SizedBox(height: 12),
          _pdfInfoCard([
            _pdfInfoLine('تاريخ التقرير', DateFormat('yyyy-MM-dd HH:mm').format(DateTime.now())),
            _pdfInfoLine('الرصيد', '${money(total?.balance ?? 0)} ${currencySymbol(currency)}', bold: true),
          ]),
          _pdfSectionTitle('سجل العمليات'),
          if (entries.isEmpty)
            _pdfInfoCard([Text('لا توجد عمليات.', style: _pdfText(size: 11, color: _pdfMuted))])
          else
            _pdfTable(
              headers: const ['التاريخ', 'العميل', 'البيان', 'النوع', 'المبلغ'],
              flexes: const [2, 2, 3, 1, 2],
              rows: entries.map((e) => [dateOnly(e.entry.date), e.customerName, e.entry.description.isEmpty ? 'بدون بيان' : e.entry.description, e.entry.type == EntryType.credit ? 'له' : 'عليه', '${money(e.entry.amount)} ${currencySymbol(e.entry.currency)}']).toList(),
              rowColors: entries.map((e) => e.entry.type == EntryType.credit ? const Color(0xFF2563EB) : const Color(0xFFD04444)).toList(),
            ),
          if (lastPage) ...[
            _pdfSectionTitle('الإجمالي'),
            _pdfTotalsCard(totals: totals),
          ],
          const Spacer(),
          Container(
            padding: const EdgeInsets.only(top: 10),
            decoration: const BoxDecoration(border: Border(top: BorderSide(color: _pdfLine))),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('حساباتي • دفتر حساباتك', style: _pdfText(size: 9, color: _pdfMuted)),
              Text('عدد العمليات: ${entries.length}', style: _pdfText(size: 9, weight: FontWeight.w800)),
            ]),
          ),
        ],
      ),
    );

Future<void> printCustomerReport(BuildContext context, Customer customer) async {
  try {
    await _runWithPrintWaiting<void>(context, () async {
      final entries = await AppDatabase.instance.entriesForCustomer(customer.id!);
      final balances = await AppDatabase.instance.customerCurrencyBalances(customer.id!);
      final logo = await _businessLogoBytes();
      await _precachePdfBusinessLogo(context, logo);
      final chunks = _pdfChunks(entries, 9);
      final entryTotals = _buildEntryTotals(entries);
      final pages = <Widget>[];
      if (chunks.isEmpty) {
        pages.add(_customerReportPage(logo: logo, customer: customer, balances: balances, entries: const [], firstPage: true, lastPage: true, totalEntries: 0, totals: entryTotals));
      } else {
        for (var i = 0; i < chunks.length; i++) {
          pages.add(_customerReportPage(logo: logo, customer: customer, balances: balances, entries: chunks[i], firstPage: i == 0, lastPage: i == chunks.length - 1, totalEntries: entries.length, totals: entryTotals));
        }
      }
      final images = await _capturePdfPages(context, pages);
      final bytes = await _imagesToPdf(images);
      await Printing.layoutPdf(name: 'تقرير_${customer.name}', onLayout: (_) async => bytes);
    });
  } catch (e) {
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر طباعة تقرير العميل: $e')));
  }
}

Future<void> exportAccountStatementPdf(BuildContext context, String currency) async {
  try {
    await _runWithPrintWaiting<void>(context, () async {
      final entries = await AppDatabase.instance.allEntriesWithCustomers(currency: currency);
      final totals = await AppDatabase.instance.currencyTotals();
      CurrencyTotal? total;
      for (final item in totals) {
        if (item.currency == currency) {
          total = item;
          break;
        }
      }
      final logo = await _businessLogoBytes();
      await _precachePdfBusinessLogo(context, logo);
      final chunks = _pdfChunks(entries, 13);
      final entryTotals = _buildEntryWithCustomerTotals(entries);
      final pages = <Widget>[];
      if (chunks.isEmpty) {
        pages.add(_statementReportPage(logo: logo, currency: currency, total: total, entries: const [], lastPage: true, totals: entryTotals));
      } else {
        for (final chunk in chunks) {
          pages.add(_statementReportPage(logo: logo, currency: currency, total: total, entries: chunk, lastPage: chunk == chunks.last, totals: entryTotals));
        }
      }
      final images = await _capturePdfPages(context, pages);
      final bytes = await _imagesToPdf(images);
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/hasabati_statement_${currency}_${DateTime.now().millisecondsSinceEpoch}.pdf');
      await file.writeAsBytes(bytes, flush: true);
      await Share.shareXFiles([XFile(file.path, mimeType: 'application/pdf')], text: 'كشف حساب - ${currencyName(currency)}');
    });
  } catch (e) {
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر إنشاء كشف PDF: $e')));
  }
}


class BackupPage extends StatefulWidget {
  const BackupPage({super.key});
  @override
  State<BackupPage> createState() => _BackupPageState();
}

class _BackupPageState extends State<BackupPage> {
  bool busy = false;

  Future<void> _backup() async {
    if (busy) return;
    setState(() => busy = true);
    try {
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/hasabati_backup_${DateFormat('yyyyMMdd_HHmmss').format(DateTime.now())}.db');
      await AppDatabase.instance.createBackup(file.path);
      await Share.shareXFiles([XFile(file.path, mimeType: 'application/octet-stream')], text: 'نسخة احتياطية من حساباتي');
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر إنشاء النسخة الاحتياطية: $e')));
    } finally { if (mounted) setState(() => busy = false); }
  }

  Future<void> _restore() async {
    if (busy) return;
    final result = await FilePicker.platform.pickFiles(type: FileType.any, withData: false);
    if (result == null || result.files.single.path == null) return;
    final path = result.files.single.path!;
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('استعادة النسخة الاحتياطية'),
        content: Text('سيتم استبدال البيانات الحالية بالنسخة المختارة. تأكد من اختيار ملف حساباتي الصحيح. هل تريد المتابعة؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: Text('استعادة')),
        ],
      ),
    ) ?? false;
    if (!confirm) return;
    setState(() => busy = true);
    try {
      await AppDatabase.instance.restoreBackup(path);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تمت استعادة النسخة الاحتياطية بنجاح')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر استعادة النسخة: $e')));
    } finally { if (mounted) setState(() => busy = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('النسخ الاحتياطي', style: TextStyle(fontWeight: FontWeight.w900))),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const FaIcon(FontAwesomeIcons.cloudArrowUp, size: 42),
        const SizedBox(height: 12),
        Text('احفظ بيانات حساباتي بأمان', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        const SizedBox(height: 7),
        Text('يمكنك إنشاء نسخة من قاعدة البيانات ومشاركتها أو حفظها، ثم استعادتها لاحقاً على نفس التطبيق.'),
        const SizedBox(height: 18),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: busy ? null : _backup, icon: const FaIcon(FontAwesomeIcons.database), label: Text(busy ? 'جاري المعالجة...' : 'إنشاء ومشاركة نسخة احتياطية'))),
        const SizedBox(height: 8),
        SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: busy ? null : _restore, icon: const FaIcon(FontAwesomeIcons.rotateLeft), label: Text('استعادة نسخة احتياطية'))),
      ]))),
      const SizedBox(height: 12),
      const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('نصيحة: احتفظ بنسخة احتياطية بعد العمليات المهمة، ويفضل حفظها في Google Drive أو Telegram أو جهاز آخر.'))),
    ]),
  );
}


DateTime? _parseStoredDate(String value) {
  return DateTime.tryParse(value.replaceFirst(' ', 'T'));
}

Future<void> _printAdvancedReport(BuildContext context, {
  required String type,
  required DateTime from,
  required DateTime to,
  String? currency,
}) async {
  try {
    await _runWithPrintWaiting<void>(context, () async {
      final logo = await _businessLogoBytes();
      await _precachePdfBusinessLogo(context, logo);
      final fromDate = DateTime(from.year, from.month, from.day);
      final toDate = DateTime(to.year, to.month, to.day, 23, 59, 59, 999);
      final currencyFilter = currency == null || currency == 'ALL' ? null : currency;

      final entries = (await AppDatabase.instance.allEntriesWithCustomers(currency: currencyFilter))
          .where((e) {
            final d = _parseStoredDate(e.entry.date);
            return d != null && !d.isBefore(fromDate) && !d.isAfter(toDate);
          }).toList();

      final invoices = (await AppDatabase.instance.invoices(currency: currencyFilter))
          .where((i) {
            final d = _parseStoredDate(i.date);
            return d != null && !d.isBefore(fromDate) && !d.isAfter(toDate);
          }).toList();

      final customerNames = <int, String>{};
      for (final e in entries) customerNames[e.entry.customerId] = e.customerName;
      for (final i in invoices) {
        customerNames[i.customerId] = await AppDatabase.instance.customerNameById(i.customerId) ?? 'غير معروف';
      }

      final pages = <Widget>[];
      if (type == 'activity') {
        final totals = _buildEntryWithCustomerTotals(entries);
        final chunks = _pdfChunks(entries, 12);
        if (chunks.isEmpty) {
          pages.add(_advancedActivityPage(logo: logo, entries: const [], totals: totals, from: fromDate, to: toDate, lastPage: true));
        } else {
          for (var i = 0; i < chunks.length; i++) {
            pages.add(_advancedActivityPage(logo: logo, entries: chunks[i], totals: totals, from: fromDate, to: toDate, lastPage: i == chunks.length - 1));
          }
        }
      } else if (type == 'invoices') {
        final chunks = _pdfChunks(invoices, 8);
        final invoiceTotals = <String, double>{};
        for (final i in invoices) invoiceTotals[i.currency] = (invoiceTotals[i.currency] ?? 0) + i.total;
        if (chunks.isEmpty) {
          pages.add(_advancedInvoicesPage(logo: logo, invoices: const [], customerNames: customerNames, totals: invoiceTotals, from: fromDate, to: toDate, lastPage: true));
        } else {
          for (var i = 0; i < chunks.length; i++) {
            pages.add(_advancedInvoicesPage(logo: logo, invoices: chunks[i], customerNames: customerNames, totals: invoiceTotals, from: fromDate, to: toDate, lastPage: i == chunks.length - 1));
          }
        }
      } else {
        final customers = await AppDatabase.instance.customers();
        final customerMap = {for (final c in customers) c.id!: c};
        final grouped = <String, List<double>>{};
        final counts = <String, int>{};
        for (final e in entries) {
          final key = '${e.entry.customerId}|${e.entry.currency}';
          final item = grouped.putIfAbsent(key, () => [0.0, 0.0]);
          if (e.entry.type == EntryType.credit) {
            item[0] += e.entry.amount;
          } else {
            item[1] += e.entry.amount;
          }
          counts[key] = (counts[key] ?? 0) + 1;
        }
        final rows = <CustomerCurrencyReportRow>[];
        for (final item in grouped.entries) {
          final parts = item.key.split('|');
          final customerId = int.tryParse(parts.first);
          if (customerId == null) continue;
          final c = customerMap[customerId];
          if (c == null) continue;
          final currencyCode = parts.last;
          final values = item.value;
          rows.add(CustomerCurrencyReportRow(
            customerId: customerId,
            customerName: c.name,
            phone: c.phone,
            currency: currencyCode,
            balance: values[0] - values[1],
            transactions: counts[item.key] ?? 0,
          ));
        }
        rows.sort((a,b) => b.balance.abs().compareTo(a.balance.abs()));
        pages.add(_advancedReceivablesPage(logo: logo, rows: rows, from: fromDate, to: toDate, currency: currencyFilter));
      }

      final images = await _capturePdfPages(context, pages);
      final bytes = await _imagesToPdf(images);
      await Printing.layoutPdf(
        name: 'تقرير_متقدم_${DateFormat('yyyyMMdd').format(fromDate)}_${DateFormat('yyyyMMdd').format(toDate)}',
        onLayout: (_) async => bytes,
      );
    });
  } catch (e) {
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر إنشاء التقرير: $e')));
  }
}

Widget _advancedActivityPage({required Uint8List? logo, required List<EntryWithCustomer> entries, required Map<String,List<double>> totals, required DateTime from, required DateTime to, required bool lastPage}) => _PdfReportPage(
  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    _PdfBusinessHeader(logoBytes: logo, title: 'تقرير حركة الحسابات'),
    _pdfSectionTitle('الفترة'),
    _pdfInfoCard([_pdfInfoLine('من', DateFormat('yyyy-MM-dd').format(from)), _pdfInfoLine('إلى', DateFormat('yyyy-MM-dd').format(to)), _pdfInfoLine('عدد العمليات', '${entries.length}', bold: true)]),
    _pdfSectionTitle('سجل الحركة'),
    if (entries.isEmpty) _pdfInfoCard([Text('لا توجد عمليات خلال الفترة المحددة.', style: _pdfText(size: 11, color: _pdfMuted))]) else _pdfTable(
      headers: const ['التاريخ','العميل','النوع','العملة','المبلغ','البيان'],
      flexes: const [2,2,1,2,2,3],
      rows: entries.map((e)=>[dateOnly(e.entry.date),e.customerName,e.entry.type.label,currencyName(e.entry.currency),'${money(e.entry.amount)} ${currencySymbol(e.entry.currency)}',e.entry.description.isEmpty?'بدون بيان':e.entry.description]).toList(),
      rowColors: entries.map((e)=>e.entry.type==EntryType.credit?const Color(0xFF2563EB):const Color(0xFFD04444)).toList(),
    ),
    if (lastPage) ...[_pdfSectionTitle('الإجماليات'), _pdfTotalsCard(totals: totals)],
    const Spacer(), _pdfFooter('تقرير حركة الحسابات')
  ]),
);

Widget _advancedInvoicesPage({required Uint8List? logo, required List<Invoice> invoices, required Map<int,String> customerNames, required Map<String,double> totals, required DateTime from, required DateTime to, required bool lastPage}) => _PdfReportPage(
  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    _PdfBusinessHeader(logoBytes: logo, title: 'تقرير الفواتير والمبيعات'),
    _pdfSectionTitle('الفترة'),
    _pdfInfoCard([_pdfInfoLine('من', DateFormat('yyyy-MM-dd').format(from)), _pdfInfoLine('إلى', DateFormat('yyyy-MM-dd').format(to)), _pdfInfoLine('عدد الفواتير', '${invoices.length}', bold: true)]),
    _pdfSectionTitle('سجل الفواتير'),
    if (invoices.isEmpty) _pdfInfoCard([Text('لا توجد فواتير خلال الفترة المحددة.', style: _pdfText(size: 11, color: _pdfMuted))]) else _pdfTable(
      headers: const ['التاريخ','الفاتورة','العميل','الدفع','العملة','الإجمالي'],
      flexes: const [2,2,3,1,2,2],
      rows: invoices.map((i)=>[dateOnly(i.date),i.invoiceNumber,customerNames[i.customerId]??'غير معروف',i.paymentType=='credit'?'آجل':'نقد',currencyName(i.currency),'${money(i.total)} ${currencySymbol(i.currency)}']).toList(),
      rowColors: invoices.map((i)=>i.paymentType=='credit'?const Color(0xFFD04444):const Color(0xFF2563EB)).toList(),
    ),
    if (lastPage) ...[
      _pdfSectionTitle('إجمالي المبيعات حسب العملة'),
      ...totals.entries.map((e)=>_pdfInfoCard([_pdfInfoLine(currencyName(e.key), '${money(e.value)} ${currencySymbol(e.key)}', bold: true)])),
    ],
    const Spacer(), _pdfFooter('تقرير الفواتير والمبيعات')
  ]),
);

Widget _advancedReceivablesPage({required Uint8List? logo, required List<CustomerCurrencyReportRow> rows, required DateTime from, required DateTime to, required String? currency}) => _PdfReportPage(
  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    _PdfBusinessHeader(logoBytes: logo, title: 'تقرير أرصدة العملاء خلال الفترة'),
    _pdfSectionTitle('بيانات التقرير'),
    _pdfInfoCard([_pdfInfoLine('من', DateFormat('yyyy-MM-dd').format(from)), _pdfInfoLine('إلى', DateFormat('yyyy-MM-dd').format(to)), _pdfInfoLine('العملة', currency == null ? 'كل العملات' : currencyName(currency)), _pdfInfoLine('عدد العملاء', '${rows.length}', bold: true)]),
    _pdfSectionTitle('أرصدة العملاء'),
    if (rows.isEmpty) _pdfInfoCard([Text('لا توجد أرصدة عملاء.', style: _pdfText(size: 11, color: _pdfMuted))]) else _pdfTable(
      headers: const ['العميل','الهاتف','العملة','الرصيد','العمليات'],
      flexes: const [3,2,2,2,1],
      rows: rows.map((r)=>[r.customerName,r.phone.isEmpty?'—':r.phone,currencyName(r.currency),'${money(r.balance)} ${currencySymbol(r.currency)}','${r.transactions}']).toList(),
      rowColors: rows.map((r)=>r.balance>=0?const Color(0xFF2563EB):const Color(0xFFD04444)).toList(),
    ),
    const Spacer(), _pdfFooter('تقرير أرصدة العملاء')
  ]),
);

Widget _pdfFooter(String title) => Container(
  padding: const EdgeInsets.only(top: 10),
  decoration: const BoxDecoration(border: Border(top: BorderSide(color: _pdfLine))),
  child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
    Text('حساباتي • دفتر حساباتك', style: _pdfText(size: 9, color: _pdfMuted)),
    Text(title, style: _pdfText(size: 9, weight: FontWeight.w800, color: _pdfBlue)),
  ]),
);

Future<void> _pickAdvancedReport(BuildContext context, String type, String title, String currency) async {
  final now = DateTime.now();
  DateTimeRange? range = await showDateRangePicker(
    context: context,
    firstDate: DateTime(now.year - 5),
    lastDate: DateTime(now.year + 1),
    initialDateRange: DateTimeRange(start: DateTime(now.year, now.month, 1), end: now),
    helpText: 'اختر فترة التقرير',
    cancelText: 'إلغاء',
    confirmText: 'متابعة',
    saveText: 'حفظ',
    locale: const Locale('ar'),
  );
  if (range == null || !context.mounted) return;
  await _printAdvancedReport(context, type: type, from: range.start, to: range.end, currency: currency);
}

class ReportsPage extends StatefulWidget {
  const ReportsPage({super.key});

  @override
  State<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends State<ReportsPage> {
  String selectedCurrency = 'YER';

  Future<_ReportData> _load() async {
    final currencies = await AppDatabase.instance.currencyTotals();
    final customers = await AppDatabase.instance.customerCurrencyReport(
      currency: selectedCurrency,
    );
    final entries = await AppDatabase.instance.allEntriesWithCustomers(
      currency: selectedCurrency,
    );
    return _ReportData(
      currencies: currencies,
      customers: customers,
      entries: entries,
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<_ReportData>(
      future: _load(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) return _ErrorView(error: snap.error);
        final data = snap.data!;
        CurrencyTotal? current;
        for (final item in data.currencies) {
          if (item.currency == selectedCurrency) {
            current = item;
            break;
          }
        }

        return RefreshIndicator(
          onRefresh: () async => setState(() {}),
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 6, 16, 100),
            children: [
              const BusinessInfoCard(compact: true),
              const SizedBox(height: 12),
              const _SectionTitle(
                title: 'التقارير المالية',
                subtitle: 'اختر العملة لعرض تقرير مستقل عنها',
              ),
              const SizedBox(height: 8),
              _CurrencyFilter(
                selected: selectedCurrency,
                onChanged: (v) {
                  if (v != 'ALL') setState(() => selectedCurrency = v);
                },
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () => exportAccountStatementPdf(context, selectedCurrency),
                  icon: const FaIcon(FontAwesomeIcons.filePdf),
                  label: Text('تصدير كشف الحساب PDF ومشاركته'),
                ),
              ),
              const SizedBox(height: 12),
              if (current != null) CurrencyBalanceCard(item: current),
              const SizedBox(height: 18),
              const _SectionTitle(
                title: 'التقارير المتقدمة',
                subtitle: 'تقارير احترافية حسب الفترة والعملة',
              ),
              const SizedBox(height: 8),
              _AdvancedReportTile(
                icon: FontAwesomeIcons.arrowsUpDown,
                title: 'تقرير حركة الحسابات',
                subtitle: 'جميع عمليات له وعليه خلال فترة محددة',
                color: const Color(0xFF5068A0),
                onTap: () => _pickAdvancedReport(context, 'activity', 'تقرير حركة الحسابات', selectedCurrency),
              ),
              _AdvancedReportTile(
                icon: FontAwesomeIcons.receipt,
                title: 'تقرير الفواتير والمبيعات',
                subtitle: 'إجمالي الفواتير حسب الفترة والعملة',
                color: const Color(0xFF2563EB),
                onTap: () => _pickAdvancedReport(context, 'invoices', 'تقرير الفواتير والمبيعات', selectedCurrency),
              ),
              _AdvancedReportTile(
                icon: FontAwesomeIcons.users,
                title: 'تقرير أرصدة العملاء',
                subtitle: 'أرصدة العملاء ومديونياتهم خلال الفترة',
                color: const Color(0xFFD04444),
                onTap: () => _pickAdvancedReport(context, 'receivables', 'تقرير أرصدة العملاء', selectedCurrency),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: _ReportStat(
                      title: 'له',
                      value: money(
                        data.entries
                            .where((e) => e.entry.type == EntryType.credit)
                            .fold(0.0, (s, e) => s + e.entry.amount),
                      ),
                      icon: FontAwesomeIcons.arrowDown,
                      color: Colors.green,
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: _ReportStat(
                      title: 'عليه',
                      value: money(
                        data.entries
                            .where((e) => e.entry.type == EntryType.debit)
                            .fold(0.0, (s, e) => s + e.entry.amount),
                      ),
                      icon: FontAwesomeIcons.arrowUp,
                      color: Colors.red,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              const _SectionTitle(
                title: 'أرصدة العملاء',
                subtitle: 'الرصيد لكل عميل بهذه العملة فقط',
              ),
              const SizedBox(height: 8),
              if (data.customers.isEmpty)
                const _EmptyCard(
                  icon: FontAwesomeIcons.users,
                  text: 'لا توجد بيانات لهذه العملة',
                )
              else
                ...data.customers.map(
                  (row) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Card(
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor:
                              currencyColor(selectedCurrency).withAlpha(20),
                          child: Text(
                            row.customerName.isEmpty
                                ? '?'
                                : row.customerName.characters.first,
                            style: TextStyle(
                              color: currencyColor(selectedCurrency),
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                        title: Text(
                          row.customerName,
                          style: TextStyle(fontWeight: FontWeight.w800),
                        ),
                        subtitle: Text('${row.transactions} عملية'),
                        trailing: Text(
                          '${money(row.balance)} ${currencySymbol(selectedCurrency)}',
                          style: TextStyle(
                            fontWeight: FontWeight.w900,
                            color: row.balance >= 0
                                ? currencyColor(selectedCurrency)
                                : Colors.red.shade700,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              const SizedBox(height: 16),
              const _SectionTitle(
                title: 'آخر عمليات التقرير',
                subtitle: 'منفصلة حسب العملة المختارة',
              ),
              const SizedBox(height: 8),
              ...data.entries.take(15).map(
                    (e) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: TransactionTile(item: e, compact: true),
                    ),
                  ),
              if (data.entries.length > 15)
                Center(
                  child: Text(
                    'تم عرض أحدث 15 عملية',
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.primary,
                      fontSize: 12,
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}




class _DebtAlertsSummaryCard extends StatelessWidget {
  const _DebtAlertsSummaryCard();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<CustomerDebtAlert>>(
      future: AppDatabase.instance.customerDebtAlerts(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const SizedBox(height: 74, child: Center(child: CircularProgressIndicator()));
        }
        if (snap.hasError) return const SizedBox.shrink();
        final debts = snap.data ?? const <CustomerDebtAlert>[];
        return Card(
          margin: EdgeInsets.zero,
          child: InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DebtAlertsPage())),
            child: Padding(
              padding: const EdgeInsets.all(15),
              child: Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: const Color(0xFFD04444).withAlpha(18),
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: const FaIcon(FontAwesomeIcons.bell, color: Color(0xFFD04444)),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('تنبيهات الديون', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                        const SizedBox(height: 3),
                        Text(
                          debts.isEmpty ? 'لا توجد مبالغ مستحقة حاليًا' : '${debts.length} عميل لديهم مبالغ مستحقة',
                          style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  if (debts.isNotEmpty)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(color: const Color(0xFFD04444), borderRadius: BorderRadius.circular(20)),
                      child: Text('${debts.length}', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
                    )
                  else
                    const FaIcon(FontAwesomeIcons.chevronLeft),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

String _formatReminderDate(String value) {
  final date = DateTime.tryParse(value);
  if (date == null) return value;
  return DateFormat('dd-MM-yyyy').format(date);
}

class DebtAlertsPage extends StatefulWidget {
  const DebtAlertsPage({super.key});

  @override
  State<DebtAlertsPage> createState() => _DebtAlertsPageState();
}

class _DebtAlertsPageState extends State<DebtAlertsPage> {
  String currency = 'ALL';

  Future<List<CustomerDebtAlert>> _load() async {
    final debts = await AppDatabase.instance.customerDebtAlerts(
      currency: currency == 'ALL' ? null : currency,
    );
    final now = DateTime.now();
    final active = <CustomerDebtAlert>[];
    for (final item in debts) {
      final reminder = await AppDatabase.instance.debtReminder(
        item.customerId,
        item.currency,
      );
      if (reminder != null) {
        final date = DateTime.tryParse(
          '${reminder.reminderDate} ${reminder.reminderTime}'.replaceFirst(' ', 'T'),
        );
        if (date != null && !date.isAfter(now)) {
          await appNotifications.cancelDebtReminder(
            customerId: item.customerId,
            currency: item.currency,
          );
          await AppDatabase.instance.deleteDebtReminder(
            item.customerId,
            item.currency,
          );
        }
      }
      active.add(item);
    }
    return active;
  }

  String _normalizePhone(String phone) {
    var value = phone.replaceAll(RegExp(r'[^0-9+]'), '');
    if (value.startsWith('+')) return value.substring(1);
    if (value.startsWith('00967')) return value.substring(2);
    if (value.startsWith('967')) return value;
    if (value.startsWith('0')) return '967${value.substring(1)}';
    if (value.startsWith('7') && value.length >= 9) return '967$value';
    return value;
  }

  String _message(CustomerDebtAlert item) => 'السلام عليكم ${item.customerName}\n\nنود تذكيركم بأن المبلغ المستحق عليكم هو ${money(item.debt)} ${currencySymbol(item.currency)}.\n\nشاكرين لكم تعاونكم.\n${appSettings.businessName}';

  Future<void> _setReminder(CustomerDebtAlert item) async {
    final current = await AppDatabase.instance.debtReminder(item.customerId, item.currency);
    final now = DateTime.now();
    final currentDate = current == null ? now.add(const Duration(days: 1)) : (DateTime.tryParse(current.reminderDate) ?? now.add(const Duration(days: 1)));
    final initialDate = DateTime(currentDate.year, currentDate.month, currentDate.day);
    final pickedDate = await showDatePicker(
      context: context,
      initialDate: initialDate.isBefore(DateTime(now.year, now.month, now.day)) ? DateTime(now.year, now.month, now.day) : initialDate,
      firstDate: DateTime(now.year, now.month, now.day),
      lastDate: DateTime(now.year + 10),
      helpText: 'اختر يوم التذكير',
      cancelText: 'إلغاء',
      confirmText: 'التالي',
      locale: const Locale('ar'),
    );
    if (pickedDate == null || !mounted) return;

    final currentParts = (current?.reminderTime ?? '09:00').split(':');
    final initialTime = TimeOfDay(
      hour: int.tryParse(currentParts.isNotEmpty ? currentParts[0] : '') ?? 9,
      minute: int.tryParse(currentParts.length > 1 ? currentParts[1] : '') ?? 0,
    );
    final pickedTime = await showTimePicker(
      context: context,
      initialTime: initialTime,
      helpText: 'اختر وقت التذكير',
      cancelText: 'إلغاء',
      confirmText: 'حفظ',
      hourLabelText: 'الساعة',
      minuteLabelText: 'الدقيقة',
      builder: (context, child) => MediaQuery(
        data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: true),
        child: child!,
      ),
    );
    if (pickedTime == null || !mounted) return;

    final scheduledLocal = DateTime(
      pickedDate.year,
      pickedDate.month,
      pickedDate.day,
      pickedTime.hour,
      pickedTime.minute,
    );
    if (!scheduledLocal.isAfter(DateTime.now())) {
      _error('اختر وقتًا قادمًا، لأن وقت التذكير المحدد قد مضى');
      return;
    }

    final date = DateFormat('yyyy-MM-dd').format(pickedDate);
    final time = '${pickedTime.hour.toString().padLeft(2, '0')}:${pickedTime.minute.toString().padLeft(2, '0')}';
    final reminder = DebtReminder(
      customerId: item.customerId,
      currency: item.currency,
      reminderDate: date,
      reminderTime: time,
    );
    await AppDatabase.instance.upsertDebtReminder(reminder);
    await appNotifications.scheduleDebtReminder(reminder: reminder, customerName: item.customerName, debt: item.debt);
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم ضبط التذكير ليوم $date الساعة $time')));
    setState(() {});
  }

  Future<void> _deleteReminder(CustomerDebtAlert item) async {
    await appNotifications.cancelDebtReminder(customerId: item.customerId, currency: item.currency);
    await AppDatabase.instance.deleteDebtReminder(item.customerId, item.currency);
    if (mounted) {
      setState(() {});
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم مسح التذكير')));
    }
  }

  Future<void> _share(CustomerDebtAlert item) async => Share.share(_message(item), subject: 'تذكير بالمبلغ المستحق');

  Future<void> _sms(CustomerDebtAlert item) async {
    final phone = _normalizePhone(item.phone);
    if (phone.isEmpty) return _error('لا يوجد رقم هاتف لهذا العميل');
    try {
      await sendDirectSMS(phone: phone, message: _message(item));
    } catch (_) {
      _error('تعذر فتح الرسائل');
    }
  }

  Future<void> _whatsappChooser(CustomerDebtAlert item) async {
    final phone = _normalizePhone(item.phone);
    if (phone.isEmpty) return _error('لا يوجد رقم هاتف لهذا العميل');

    // افتح رابط واتساب مباشرة بدون نافذة اختيار داخل التطبيق.
    // إذا كان أكثر من تطبيق واتساب (واتساب العادي وواتساب الأعمال)
    // مثبتًا ولم يكن أحدهما محددًا كتطبيق افتراضي، سيعرض Android
    // اختيار التطبيق المناسب تلقائيًا.
    final text = Uri.encodeComponent(_message(item));
    final uri = Uri.parse('whatsapp://send?phone=$phone&text=$text');

    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      _error('تعذر فتح واتساب، تأكد من تثبيت واتساب أو واتساب الأعمال');
    }
  }

  void _error(String message) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('تنبيهات الديون', style: TextStyle(fontWeight: FontWeight.w900))),
      body: FutureBuilder<List<CustomerDebtAlert>>(
        future: _load(),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snap.hasError) return _ErrorView(error: snap.error);
          final debts = snap.data ?? const <CustomerDebtAlert>[];
          final currencies = <String>{'ALL', ...debts.map((e) => e.currency)}.toList();
          return RefreshIndicator(
            onRefresh: () async => setState(() {}),
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 110),
              children: [
                Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFFD04444).withAlpha(15), borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFD04444).withAlpha(35))), child: Row(children: [const FaIcon(FontAwesomeIcons.triangleExclamation, color: Color(0xFFD04444), size: 30), const SizedBox(width: 12), Expanded(child: Text('العملاء الذين لديهم رصيد مستحق عليهم فقط', style: TextStyle(fontWeight: FontWeight.w800, color: Theme.of(context).colorScheme.onSurface)))])),
                const SizedBox(height: 12),
                if (currencies.length > 1) Wrap(spacing: 8, children: currencies.map((c) => ChoiceChip(label: Text(c == 'ALL' ? 'كل العملات' : currencyName(c)), selected: currency == c, onSelected: (_) => setState(() => currency = c))).toList()),
                const SizedBox(height: 12),
                if (debts.isEmpty)
                  const _EmptyCard(icon: FontAwesomeIcons.circleCheck, text: 'ممتاز، لا توجد ديون مستحقة حاليًا')
                else
                  ...debts.map((item) => Card(
                    margin: const EdgeInsets.only(bottom: 9),
                    child: Padding(
                      padding: const EdgeInsets.all(13),
                      child: Column(children: [
                        Row(children: [
                          CircleAvatar(backgroundColor: const Color(0xFFD04444).withAlpha(18), child: Text(item.customerName.isEmpty ? '?' : item.customerName.characters.first, style: TextStyle(color: Color(0xFFD04444), fontWeight: FontWeight.w900))),
                          const SizedBox(width: 10),
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(item.customerName, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)), if (item.phone.isNotEmpty) Text(item.phone, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 12))])),
                          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text('المستحق', style: TextStyle(fontSize: 11, color: Theme.of(context).colorScheme.onSurfaceVariant)), Text('${money(item.debt)} ${currencySymbol(item.currency)}', style: TextStyle(color: Color(0xFFD04444), fontWeight: FontWeight.w900, fontSize: 16))]),
                        ]),
                        const SizedBox(height: 8),
                        FutureBuilder<DebtReminder?>(
                          future: AppDatabase.instance.debtReminder(item.customerId, item.currency),
                          builder: (_, r) {
                            final reminder = r.data;
                            if (reminder == null) return const SizedBox.shrink();
                            return Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Expanded(
                                  child: Text(
                                    'التذكير: ${_formatReminderDate(reminder.reminderDate)} • ${reminder.reminderTime}',
                                    textAlign: TextAlign.right,
                                    style: TextStyle(color: Theme.of(context).colorScheme.primary, fontSize: 12, fontWeight: FontWeight.w800),
                                  ),
                                ),
                                IconButton(
                                  tooltip: 'مسح التذكير',
                                  visualDensity: VisualDensity.compact,
                                  onPressed: () => _deleteReminder(item),
                                  icon: const FaIcon(FontAwesomeIcons.trashCan, size: 20),
                                ),
                              ],
                            );
                          },
                        ),
                        const SizedBox(height: 8),
                        Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                          IconButton(tooltip: 'تذكير', onPressed: () => _setReminder(item), icon: const FaIcon(FontAwesomeIcons.bell)),
                          IconButton(tooltip: 'مشاركة', onPressed: () => _share(item), icon: const FaIcon(FontAwesomeIcons.shareNodes)),
                          IconButton(tooltip: 'رسالة SMS', onPressed: () => _sms(item), icon: const FaIcon(FontAwesomeIcons.commentSms)),
                          IconButton(tooltip: 'واتساب', onPressed: () => _whatsappChooser(item), icon: const FaIcon(FontAwesomeIcons.whatsapp)),
                        ]),
                      ]),
                    ),
                  )),
              ],
            ),
          );
        },
      ),
    );
  }
}

class NotificationsPage extends StatefulWidget {
  const NotificationsPage({super.key});

  @override
  State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  @override
  void initState() {
    super.initState();
    appNotifications.markAllRead();
  }

  @override
  Widget build(BuildContext context) {
    final items = appNotifications.history;
    return Scaffold(
      appBar: AppBar(
        title: Text('الإشعارات', style: TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          IconButton(
            tooltip: 'مسح الإشعارات',
            onPressed: items.isEmpty
                ? null
                : () async {
                    await appNotifications.clearHistory();
                    if (mounted) setState(() {});
                  },
            icon: const FaIcon(FontAwesomeIcons.trashCan),
          ),
        ],
      ),
      body: items.isEmpty
          ? const _EmptyCard(icon: FontAwesomeIcons.bell, text: 'لا توجد إشعارات حاليًا')
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 30),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (_, i) {
                final item = items[i];
                final date = DateTime.tryParse(item['date'] ?? '');
                return Card(
                  child: ListTile(
                    leading: Container(width: 44, height: 44, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary.withAlpha(18), borderRadius: BorderRadius.circular(14)), child: FaIcon(FontAwesomeIcons.bell, color: Theme.of(context).colorScheme.primary)),
                    title: Text(item['title'] ?? '', style: TextStyle(fontWeight: FontWeight.w900)),
                    subtitle: Text('${item['body'] ?? ''}\n${date == null ? '' : dateOnly(date.toIso8601String())}'),
                    isThreeLine: true,
                  ),
                );
              },
            ),
    );
  }
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late final TextEditingController name;
  late final TextEditingController phone;
  late final TextEditingController address;
  late final TextEditingController invoicePrefix;
  String currency = 'YER';
  bool saving = false;
  bool logoBusy = false;

  @override
  void initState() {
    super.initState();
    name = TextEditingController(text: appSettings.businessName);
    phone = TextEditingController(text: appSettings.businessPhone);
    address = TextEditingController(text: appSettings.businessAddress);
    invoicePrefix = TextEditingController(text: appSettings.invoicePrefix);
    currency = appSettings.defaultCurrency;
  }

  @override
  void dispose() {
    name.dispose();
    phone.dispose();
    address.dispose();
    invoicePrefix.dispose();
    super.dispose();
  }


  Future<void> _pickLogo() async {
    if (logoBusy) return;
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['png', 'jpg', 'jpeg'],
      withData: false,
    );
    if (result == null || result.files.single.path == null) return;
    setState(() => logoBusy = true);
    try {
      await appSettings.setBusinessLogo(result.files.single.path!);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ شعار النشاط')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر حفظ الشعار: $e')));
    } finally {
      if (mounted) setState(() => logoBusy = false);
    }
  }

  Future<void> _removeLogo() async {
    await appSettings.removeBusinessLogo();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حذف شعار النشاط')));
  }

  Future<void> _saveProfile() async {
    if (saving) return;
    setState(() => saving = true);
    await appSettings.saveProfile(
      name: name.text,
      phone: phone.text,
      address: address.text,
    );
    await appSettings.setInvoicePrefix(invoicePrefix.text);
    if (!mounted) return;
    setState(() => saving = false);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم حفظ إعدادات النشاط بنجاح')),
    );
  }

  Widget _sectionTitle(String title, IconData icon) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 18, 4, 10),
        child: Row(
          children: [
            FaIcon(icon, size: 20, color: Theme.of(context).colorScheme.primary),
            const SizedBox(width: 8),
            Text(title, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 32),
        children: [
          _sectionTitle('بيانات النشاط', FontAwesomeIcons.store),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        Container(
                          width: 96,
                          height: 96,
                          decoration: BoxDecoration(
                            color: scheme.primary.withAlpha(14),
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(color: scheme.outlineVariant),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(22),
                            child: appSettings.businessLogoPath.isNotEmpty && File(appSettings.businessLogoPath).existsSync()
                                ? Image.file(File(appSettings.businessLogoPath), fit: BoxFit.cover)
                                : FaIcon(FontAwesomeIcons.image, size: 40, color: scheme.primary),
                          ),
                        ),
                        Positioned(
                          bottom: -6,
                          right: -6,
                          child: Material(
                            color: scheme.primary,
                            shape: const CircleBorder(),
                            child: InkWell(
                              customBorder: const CircleBorder(),
                              onTap: logoBusy ? null : _pickLogo,
                              child: Padding(
                                padding: const EdgeInsets.all(9),
                                child: logoBusy
                                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                                    : const FaIcon(FontAwesomeIcons.camera, size: 18, color: Colors.white),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text('شعار النشاط', style: TextStyle(fontWeight: FontWeight.w900)),
                  const SizedBox(height: 4),
                  Text('يظهر الشعار تلقائيًا في العمليات والتقارير والفواتير', style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant), textAlign: TextAlign.center),
                  const SizedBox(height: 8),
                  if (appSettings.businessLogoPath.isNotEmpty)
                    TextButton.icon(onPressed: _removeLogo, icon: const FaIcon(FontAwesomeIcons.trashCan), label: Text('حذف الشعار')),
                  TextField(
                    controller: name,
                    textInputAction: TextInputAction.next,
                    decoration: const InputDecoration(
                      labelText: 'اسم النشاط',
                      hintText: 'مثال: متجر أبو سام',
                      prefixIcon: FaIcon(FontAwesomeIcons.building),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: phone,
                    keyboardType: TextInputType.phone,
                    textInputAction: TextInputAction.next,
                    decoration: const InputDecoration(
                      labelText: 'رقم الهاتف',
                      prefixIcon: FaIcon(FontAwesomeIcons.phone),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: address,
                    maxLines: 2,
                    decoration: const InputDecoration(
                      labelText: 'العنوان',
                      prefixIcon: FaIcon(FontAwesomeIcons.locationDot),
                    ),
                  ),
                ],
              ),
            ),
          ),
          _sectionTitle('الفواتير والعملات', FontAwesomeIcons.receipt),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  DropdownButtonFormField<String>(
                    value: currency,
                    decoration: const InputDecoration(
                      labelText: 'العملة الافتراضية',
                      prefixIcon: FaIcon(FontAwesomeIcons.moneyBill),
                    ),
                    items: const [
                      DropdownMenuItem(value: 'YER', child: Text('ريال يمني YER')),
                      DropdownMenuItem(value: 'SAR', child: Text('ريال سعودي SAR')),
                      DropdownMenuItem(value: 'USD', child: Text('دولار أمريكي USD')),
                    ],
                    onChanged: (value) async {
                      if (value == null) return;
                      setState(() => currency = value);
                      await appSettings.setDefaultCurrency(value);
                    },
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: invoicePrefix,
                    textDirection: ui.TextDirection.ltr,
                    decoration: const InputDecoration(
                      labelText: 'بادئة رقم الفاتورة',
                      hintText: 'INV-',
                      prefixIcon: FaIcon(FontAwesomeIcons.tag),
                      helperText: 'مثال: INV-000001 أو فات-000001',
                    ),
                  ),
                ],
              ),
            ),
          ),
          _sectionTitle('المظهر', FontAwesomeIcons.palette),
          Card(
            child: SwitchListTile.adaptive(
              value: appSettings.darkMode,
              onChanged: (value) => appSettings.setDarkMode(value),
              secondary: Icon(
                appSettings.darkMode ? FontAwesomeIcons.moon : FontAwesomeIcons.sun,
                color: scheme.primary,
              ),
              title: Text('الوضع الداكن', style: TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text(appSettings.darkMode ? 'الوضع الداكن مفعل' : 'الوضع الفاتح مفعل'),
            ),
          ),
          _sectionTitle('البيانات', FontAwesomeIcons.database),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const FaIcon(FontAwesomeIcons.database),
                  title: Text('النسخ الاحتياطي'),
                  subtitle: Text('حفظ نسخة من قاعدة بيانات التطبيق'),
                  trailing: const FaIcon(FontAwesomeIcons.chevronLeft),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const BackupPage()),
                  ),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const FaIcon(FontAwesomeIcons.chartLine),
                  title: Text('التقارير وكشف الحساب'),
                  subtitle: Text('عرض ملخص وتقارير الحسابات'),
                  trailing: const FaIcon(FontAwesomeIcons.chevronLeft),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const ReportsPage()),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: saving ? null : _saveProfile,
            icon: saving
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const FaIcon(FontAwesomeIcons.floppyDisk),
            label: Text(saving ? 'جاري الحفظ...' : 'حفظ إعدادات النشاط'),
          ),
          const SizedBox(height: 10),
          Center(
            child: Text(
              'الإعدادات تحفظ على هذا الجهاز ولا تحتاج إلى إنترنت.',
              style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 12),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }
}

class AboutAppPage extends StatefulWidget {
  const AboutAppPage({super.key});

  @override
  State<AboutAppPage> createState() => _AboutAppPageState();
}

class _AboutAppPageState extends State<AboutAppPage> {
  late final Future<PackageInfo> _packageInfo = PackageInfo.fromPlatform();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('حول التطبيق')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 30),
        children: [
          Center(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(30),
              child: Image.asset(
                'assets/hasabati_logo.png',
                width: 150,
                height: 150,
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(height: 22),
          const Center(
            child: Text(
              'حساباتي',
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900),
            ),
          ),
          const SizedBox(height: 6),
          Center(
            child: Text(
              'دفتر حساباتك',
              style: TextStyle(fontSize: 15, color: Theme.of(context).colorScheme.onSurfaceVariant),
            ),
          ),
          const SizedBox(height: 22),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: [
                  ListTile(
                    leading: FaIcon(FontAwesomeIcons.tableCellsLarge),
                    title: Text('اسم التطبيق'),
                    subtitle: Text('حساباتي'),
                  ),
                  Divider(),
                  ListTile(
                    leading: FaIcon(FontAwesomeIcons.circleCheck),
                    title: Text('الإصدار'),
                    subtitle: FutureBuilder<PackageInfo>(
                      future: _packageInfo,
                      builder: (context, snapshot) {
                        if (snapshot.connectionState == ConnectionState.waiting) {
                          return Text('جاري التحميل...');
                        }
                        if (snapshot.hasError || !snapshot.hasData) {
                          return Text('غير متاح');
                        }
                        final info = snapshot.data!;
                        final build = info.buildNumber.trim();
                        final version = info.version.trim();
                        return Text(build.isEmpty ? version : '$version+$build');
                      },
                    ),
                  ),
                  Divider(),
                  ListTile(
                    leading: FaIcon(FontAwesomeIcons.code),
                    title: Text('عن مبرمج التطبيق'),
                    subtitle: Text('تم برمجة هذا التطبيق بواسطة\nأبوسام للتصميم والإعلان\n"سليمان الخميسي"'),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Center(
            child: Text(
              'يعمل التطبيق محلياً بدون الحاجة إلى اتصال بالإنترنت.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
            ),
          ),
        ],
      ),
    );
  }
}

class PrivacyPolicyPage extends StatelessWidget {
  const PrivacyPolicyPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('سياسة الخصوصية')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 30),
        children: const [
          _PrivacySection(title: 'البيانات المحلية', text: 'يتم حفظ العملاء والعمليات والفواتير على جهازك داخل قاعدة بيانات محلية.'),
          _PrivacySection(title: 'عدم مشاركة البيانات', text: 'لا يقوم التطبيق بإرسال بيانات العملاء أو الفواتير إلى خادم خارجي.'),
          _PrivacySection(title: 'الإنترنت', text: 'يمكن استخدام التطبيق لإدارة حساباتك وفواتيرك بدون اتصال بالإنترنت.'),
          _PrivacySection(title: 'مسؤولية المستخدم', text: 'أنت مسؤول عن حماية جهازك ونسخ بيانات التطبيق احتياطياً عند الحاجة.'),
        ],
      ),
    );
  }
}

class _PrivacySection extends StatelessWidget {
  final String title;
  final String text;
  const _PrivacySection({required this.title, required this.text});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
            const SizedBox(height: 7),
            Text(text, style: TextStyle(height: 1.6, color: Theme.of(context).colorScheme.onSurfaceVariant)),
          ]),
        ),
      ),
    );
  }
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final bool selected;
  final VoidCallback onTap;

  const _DrawerItem({
    required this.icon,
    required this.title,
    required this.onTap,
    this.selected = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = selected
        ? Theme.of(context).colorScheme.primary
        : Theme.of(context).colorScheme.onSurface;
    return ListTile(
      leading: FaIcon(icon, color: color),
      title: Text(
        title,
        style: TextStyle(
          color: color,
          fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
          fontSize: 15,
        ),
      ),
      selected: selected,
      selectedTileColor:
          Theme.of(context).colorScheme.primary.withAlpha(18),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      onTap: onTap,
    );
  }
}

class _AdvancedReportTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;
  const _AdvancedReportTile({required this.icon, required this.title, required this.subtitle, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      leading: CircleAvatar(backgroundColor: color.withAlpha(18), child: FaIcon(icon, color: color)),
      title: Text(title, style: TextStyle(fontWeight: FontWeight.w900)),
      subtitle: Text(subtitle),
      trailing: FaIcon(FontAwesomeIcons.filePdf, color: color),
    ),
  );
}

class _ReportData {
  final List<CurrencyTotal> currencies;
  final List<CustomerCurrencyReportRow> customers;
  final List<EntryWithCustomer> entries;

  _ReportData({
    required this.currencies,
    required this.customers,
    required this.entries,
  });
}

class _ReportStat extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final Color color;

  const _ReportStat({
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Row(
          children: [
            CircleAvatar(
              radius: 21,
              backgroundColor: color.withAlpha(20),
              child: FaIcon(icon, color: color, size: 20),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                  const SizedBox(height: 3),
                  Text(
                    value,
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      color: color,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final String subtitle;

  const _SectionTitle({
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                subtitle,
                style: TextStyle(
                  fontSize: 11,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _EmptyCard extends StatelessWidget {
  final IconData icon;
  final String text;

  const _EmptyCard({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 18),
        child: Column(
          children: [
            FaIcon(icon, size: 42, color: Theme.of(context).colorScheme.onSurfaceVariant),
            const SizedBox(height: 8),
            Text(
              text,
              textAlign: TextAlign.center,
              style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final Object? error;

  const _ErrorView({this.error});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Text(
          'حدث خطأ أثناء تحميل البيانات.\n${error ?? ''}',
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
