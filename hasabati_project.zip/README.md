# حساباتي

تطبيق Flutter عربي لإدارة حسابات العملاء والعمليات المالية محلياً.

## البناء على GitHub Actions

1. ارفع المشروع إلى مستودع GitHub.
2. افتح تبويب **Actions**.
3. اختر **Build Android APK**.
4. اضغط **Run workflow**.
5. بعد نجاح البناء افتح الـArtifacts وحمّل:
   `hasabati-release-apk`

تم ضبط المشروع ليستخدم Android NDK `28.2.13676358` وGradle `8.11.1` وFlutter `3.38.1`.
